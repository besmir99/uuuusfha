import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import LandingPage from './components/Landing/LandingPage';
import Navigation from './components/Layout/Navigation';
import ClientDashboard from './components/Dashboard/ClientDashboard';
import BarberDashboard from './components/Dashboard/BarberDashboard';
import AdminDashboard from './components/Dashboard/AdminDashboard';
import EnhancedBookingFlow from './components/Appointments/EnhancedBookingFlow';
import BarberCard from './components/Barbers/BarberCard';
import SalonCard from './components/Salons/SalonCard';
import LocationSearch from './components/Location/LocationSearch';
import AnalyticsDashboard from './components/Analytics/AnalyticsDashboard';
import NotificationCenter from './components/Notifications/NotificationCenter';
import AppointmentCalendar from './components/Calendar/AppointmentCalendar';
import ReviewSystem from './components/Reviews/ReviewSystem';
import AppointmentCard from './components/Appointments/AppointmentCard';
import AdminScheduleManager from './components/Admin/ScheduleManager';
import SalonManager from './components/Admin/SalonManager';
import ImprovedBookingFlow from './components/Booking/ImprovedBookingFlow';
import { mockBarbers } from './data/mockData';
import { mockSalons } from './data/salonData';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [bookingMode, setBookingMode] = useState<'individual' | 'salon'>('salon');

  // Show landing page if user is not logged in
  if (!user) {
    return <LandingPage onLogin={() => {}} />;
  }

  const handleBookingComplete = () => {
    // Navigate to appointments view after successful booking
    setCurrentView('appointments');
  };

  const handleBookingCancel = () => {
    // Navigate back to dashboard when booking is cancelled
    setCurrentView('dashboard');
  };

  const renderMainContent = () => {
    switch (currentView) {
      case 'dashboard':
        if (user.role === 'client') return <ClientDashboard />;
        if (user.role === 'barber') return <BarberDashboard />;
        if (user.role === 'admin') return <AdminDashboard />;
        break;
      
      case 'book':
        return (
          <div className="space-y-8">
            <ImprovedBookingFlow 
              onBookingComplete={handleBookingComplete}
              onCancel={handleBookingCancel}
              selectedCity={selectedLocation}
            />
          </div>
        );
      
      case 'barbers':
        return (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Find Barbers & Salons</h1>
              <p className="text-slate-600 mt-2">Discover talented professionals and premium salons in your area</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1">
                <LocationSearch 
                  onLocationSelect={setSelectedLocation}
                  currentLocation={selectedLocation}
                />
              </div>
              
              <div className="lg:col-span-3">
                <div className="flex flex-wrap gap-4 mb-6">
                  <select className="px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>All Services</option>
                    <option>Haircut</option>
                    <option>Beard Trim</option>
                    <option>Hair Coloring</option>
                  </select>
                  
                  <select className="px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>Sort by Rating</option>
                    <option>Sort by Price</option>
                    <option>Sort by Distance</option>
                  </select>

                  <div className="flex bg-slate-100 rounded-xl p-1">
                    <button className="px-4 py-2 bg-white text-blue-600 rounded-lg font-medium shadow-sm">
                      Salons
                    </button>
                    <button className="px-4 py-2 text-slate-600 rounded-lg font-medium hover:text-slate-900">
                      Individual
                    </button>
                  </div>
                </div>
                
                <div className="space-y-8">
                  {/* Salons Section */}
                  <div>
                    <h2 className="text-xl font-semibold text-slate-900 mb-4">Premium Salons</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {mockSalons.slice(0, 4).map((salon) => (
                        <SalonCard
                          key={salon.id}
                          salon={salon}
                          onBookNow={() => {
                            setBookingMode('salon');
                            setCurrentView('book');
                          }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Individual Barbers Section */}
                  <div>
                    <h2 className="text-xl font-semibold text-slate-900 mb-4">Individual Barbers</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {mockBarbers.slice(0, 4).map((barber) => (
                        <BarberCard
                          key={barber.id}
                          barber={barber}
                          onBookNow={() => {
                            setBookingMode('individual');
                            setCurrentView('book');
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'appointments':
        if (user.role === 'client') {
          // Get user's bookings from localStorage
          const userBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
          const hasBookings = userBookings.length > 0;

          return (
            <div className="space-y-8">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">My Appointments</h1>
                <p className="text-slate-600 mt-2">Manage your upcoming and past appointments</p>
              </div>
              
              {hasBookings ? (
                <div className="space-y-6">
                  {userBookings.map((booking: any) => (
                    <AppointmentCard
                      key={booking.id}
                      appointment={{
                        id: booking.id,
                        client_id: user.id,
                        salon_id: booking.salonId || 'salon-1',
                        barber_id: booking.barberId,
                        service_id: booking.serviceId,
                        appointment_date: booking.date,
                        appointment_time: booking.time,
                        end_time: booking.endTime || booking.time,
                        status: booking.status === 'approved' ? 'confirmed' : booking.status,
                        notes: booking.notes,
                        total_price: 25,
                        payment_status: 'pending',
                        created_at: booking.createdAt,
                        updated_at: booking.createdAt
                      }}
                      onAppointmentUpdate={() => {
                        // Refresh appointments list
                        window.location.reload();
                      }}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">📅</span>
                    </div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No appointments yet</h3>
                    <p className="text-slate-600 mb-6">Book your first appointment to get started</p>
                    <button
                      onClick={() => setCurrentView('book')}
                      className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
                    >
                      Book Appointment
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        } else {
          return <AppointmentCalendar />;
        }
      
      case 'analytics':
        return <AnalyticsDashboard userRole={user.role as 'barber' | 'admin'} />;
      
      case 'salon-manager':
        if (user.role === 'barber') {
          // For demo, assume barber with ID '2' manages salon-1
          const managedSalonId = user.id === '2' ? 'salon-1' : 'salon-2';
          return <SalonManager salonId={managedSalonId} />;
        }
        break;
      
      case 'notifications':
        return <NotificationCenter />;
      
      case 'reviews':
        return <ReviewSystem barberId={user.role === 'barber' ? user.id : undefined} userRole={user.role} />;
      
      case 'schedule':
        if (user.role === 'admin') {
          return <AdminScheduleManager />;
        }
        break;
      
      case 'profile':
        return (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">My Profile</h1>
              <p className="text-slate-600 mt-2">Manage your account settings and preferences</p>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
              <div className="max-w-md">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-2xl">
                      {user.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900">{user.name}</h3>
                    <p className="text-slate-600">{user.email}</p>
                    <p className="text-sm text-slate-500 capitalize">{user.role}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Full Name</label>
                    <input
                      type="text"
                      value={user.name}
                      className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={user.email}
                      className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Phone</label>
                    <input
                      type="tel"
                      value={user.phone}
                      className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200">
                    Update Profile
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        if (user.role === 'client') return <ClientDashboard />;
        if (user.role === 'barber') return <BarberDashboard />;
        if (user.role === 'admin') return <AdminDashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Navigation currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 lg:ml-0 p-8 transition-all duration-500">
        {renderMainContent()}
      </main>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;