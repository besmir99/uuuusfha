// Database Schema Types and Relationships

export interface DatabaseUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  password_hash: string;
  role: 'client' | 'barber' | 'admin';
  gender?: 'male' | 'female' | 'other';
  avatar_url?: string;
  is_active: boolean;
  email_verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface DatabaseCity {
  id: string;
  name: string;
  name_albanian: string;
  region: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  population: number;
  is_active: boolean;
  created_at: string;
}

export interface DatabaseSalon {
  id: string;
  name: string;
  description: string;
  address: string;
  city_id: string; // Foreign key to cities table
  coordinates: {
    lat: number;
    lng: number;
  };
  phone: string;
  email?: string;
  website?: string;
  rating: number;
  total_reviews: number;
  business_hours: BusinessHours;
  amenities: string[];
  images: string[];
  owner_id?: string; // Foreign key to users table (barber who owns salon)
  is_active: boolean;
  verified: boolean;
  created_at: string;
  updated_at: string;
  
  // Relationships
  city?: DatabaseCity;
  owner?: DatabaseUser;
  barbers?: DatabaseBarber[];
  services?: DatabaseService[];
  appointments?: DatabaseAppointment[];
  reviews?: DatabaseReview[];
}

export interface DatabaseBarber {
  id: string;
  user_id: string; // Foreign key to users table
  salon_id: string; // Foreign key to salons table
  bio: string;
  specialties: string[];
  experience_years: number;
  rating: number;
  total_reviews: number;
  hourly_rate?: number;
  commission_rate?: number;
  is_active: boolean;
  verified: boolean;
  created_at: string;
  updated_at: string;
  
  // Relationships
  user?: DatabaseUser;
  salon?: DatabaseSalon;
  services?: DatabaseService[];
  appointments?: DatabaseAppointment[];
  reviews?: DatabaseReview[];
}

export interface DatabaseService {
  id: string;
  salon_id: string; // Foreign key to salons table
  name: string;
  description: string;
  price: number;
  duration_minutes: number;
  category: string;
  target_gender: 'male' | 'female' | 'unisex';
  required_experience_years?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  
  // Relationships
  salon?: DatabaseSalon;
  barber_services?: DatabaseBarberService[];
  appointments?: DatabaseAppointment[];
}

export interface DatabaseBarberService {
  id: string;
  barber_id: string; // Foreign key to barbers table
  service_id: string; // Foreign key to services table
  is_available: boolean;
  custom_price?: number; // Override salon price if needed
  created_at: string;
  
  // Relationships
  barber?: DatabaseBarber;
  service?: DatabaseService;
}

export interface DatabaseAppointment {
  id: string;
  client_id: string; // Foreign key to users table
  salon_id: string; // Foreign key to salons table
  barber_id: string; // Foreign key to barbers table
  service_id: string; // Foreign key to services table
  appointment_date: string; // YYYY-MM-DD
  appointment_time: string; // HH:MM
  end_time: string; // Calculated: appointment_time + service.duration_minutes
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled_by_client' | 'cancelled_by_barber' | 'no_show';
  notes?: string;
  total_price: number;
  payment_status: 'pending' | 'paid' | 'refunded';
  payment_method?: 'cash' | 'card' | 'online';
  cancellation_reason?: string;
  cancelled_at?: string;
  cancelled_by?: string; // user_id who cancelled
  created_at: string;
  updated_at: string;
  
  // Relationships
  client?: DatabaseUser;
  salon?: DatabaseSalon;
  barber?: DatabaseBarber;
  service?: DatabaseService;
  review?: DatabaseReview;
}

export interface DatabaseReview {
  id: string;
  appointment_id: string; // Foreign key to appointments table
  client_id: string; // Foreign key to users table
  salon_id: string; // Foreign key to salons table
  barber_id: string; // Foreign key to barbers table
  rating: number; // 1-5
  comment?: string;
  is_verified: boolean;
  is_public: boolean;
  helpful_count: number;
  created_at: string;
  updated_at: string;
  
  // Relationships
  appointment?: DatabaseAppointment;
  client?: DatabaseUser;
  salon?: DatabaseSalon;
  barber?: DatabaseBarber;
}

export interface DatabaseNotification {
  id: string;
  user_id: string; // Foreign key to users table
  type: 'appointment_confirmed' | 'appointment_reminder' | 'appointment_cancelled' | 'review_request' | 'system_update';
  title: string;
  message: string;
  data?: Record<string, any>; // JSON data for notification context
  is_read: boolean;
  created_at: string;
  
  // Relationships
  user?: DatabaseUser;
}

// Database Relationships Summary:
/*
1. Users (1) → Barbers (1) - One user can be one barber
2. Salons (1) → Barbers (many) - One salon has many barbers
3. Salons (1) → Services (many) - One salon offers many services
4. Barbers (many) ↔ Services (many) - Many-to-many through barber_services
5. Cities (1) → Salons (many) - One city has many salons
6. Appointments link: Client (1) + Salon (1) + Barber (1) + Service (1)
7. Reviews link: Appointment (1) + Client (1) + Salon (1) + Barber (1)
8. Users (1) → Notifications (many) - One user has many notifications
*/

export interface BusinessHours {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

export interface DaySchedule {
  is_open: boolean;
  open_time: string;
  close_time: string;
}

// Database Indexes for Performance:
/*
CREATE INDEX idx_appointments_client_id ON appointments(client_id);
CREATE INDEX idx_appointments_barber_id ON appointments(barber_id);
CREATE INDEX idx_appointments_salon_id ON appointments(salon_id);
CREATE INDEX idx_appointments_date_time ON appointments(appointment_date, appointment_time);
CREATE INDEX idx_appointments_status ON appointments(status);
CREATE INDEX idx_barbers_salon_id ON barbers(salon_id);
CREATE INDEX idx_services_salon_id ON services(salon_id);
CREATE INDEX idx_reviews_salon_id ON reviews(salon_id);
CREATE INDEX idx_reviews_barber_id ON reviews(barber_id);
CREATE INDEX idx_salons_city_id ON salons(city_id);
CREATE INDEX idx_salons_coordinates ON salons USING GIST(coordinates);
*/