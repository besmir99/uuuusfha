// Scheduling and Slot Management Types

export interface TimeSlot {
  id: string;
  start_time: string; // HH:MM format
  end_time: string; // HH:MM format
  is_available: boolean;
  is_reserved: boolean; // Reserved but not yet approved
  reservation_expires_at?: string; // ISO timestamp when reservation expires
  appointment_id?: string; // If booked
  status: 'available' | 'reserved' | 'booked' | 'blocked' | 'break';
  blocked_reason?: string; // 'lunch_break' | 'vacation' | 'personal' | 'maintenance'
}

export interface BarberSchedule {
  id: string;
  barber_id: string;
  date: string; // YYYY-MM-DD
  working_hours: {
    start: string; // HH:MM
    end: string; // HH:MM
  };
  breaks: BreakPeriod[];
  is_working: boolean;
  time_slots: TimeSlot[];
  created_at: string;
  updated_at: string;
}

export interface BreakPeriod {
  id: string;
  start_time: string; // HH:MM
  end_time: string; // HH:MM
  type: 'lunch' | 'coffee' | 'personal' | 'maintenance';
  title: string;
  is_recurring: boolean; // If this break happens every day
}

export interface BarberAvailability {
  barber_id: string;
  working_days: string[]; // ['monday', 'tuesday', ...]
  default_working_hours: {
    start: string;
    end: string;
  };
  default_breaks: BreakPeriod[];
  vacation_days: string[]; // ['2025-07-04', '2025-07-05']
  custom_schedules: BarberSchedule[]; // Override default for specific dates
  time_zone: string;
  slot_duration: number; // minutes (e.g., 30)
  buffer_time: number; // minutes between appointments
}

export interface SalonScheduleSettings {
  salon_id: string;
  default_working_hours: {
    start: string;
    end: string;
  };
  default_working_days: string[];
  default_slot_duration: number; // minutes
  default_buffer_time: number; // minutes
  advance_booking_limit: number; // days
  cancellation_policy_hours: number; // hours (e.g., 3)
  auto_confirm_appointments: boolean;
  reservation_timeout_minutes: number; // How long slots stay reserved
}

export interface SlotReservation {
  id: string;
  slot_id: string;
  barber_id: string;
  client_id: string;
  service_id: string;
  reserved_at: string; // ISO timestamp
  expires_at: string; // ISO timestamp
  status: 'active' | 'expired' | 'converted' | 'cancelled';
}

export interface ScheduleConflict {
  type: 'double_booking' | 'break_overlap' | 'outside_hours' | 'vacation_day';
  message: string;
  conflicting_appointment_id?: string;
  suggested_alternatives?: TimeSlot[];
}

// Utility types for schedule management
export interface ScheduleQuery {
  barber_id: string;
  date: string;
  service_duration: number;
  client_gender?: 'male' | 'female' | 'other';
}

export interface AvailableSlot {
  start_time: string;
  end_time: string;
  duration: number;
  is_recommended: boolean; // Based on barber's peak hours, etc.
  price_modifier?: number; // Peak/off-peak pricing
}