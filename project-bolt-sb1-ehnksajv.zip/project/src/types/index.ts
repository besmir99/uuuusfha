export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'client' | 'barber' | 'admin';
  gender?: 'male' | 'female' | 'other';
  avatar?: string;
  createdAt: string;
}

export interface Client extends User {
  role: 'client';
  bookingHistory: Appointment[];
}

export interface Salon {
  id: string;
  name: string;
  address: string;
  city: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  rating: number;
  totalReviews: number;
  businessHours: BusinessHours;
  amenities: string[];
  images: string[];
  description: string;
  phone: string;
  isActive: boolean;
  createdAt: string;
}

export interface Barber extends User {
  role: 'barber';
  salonId: string;
  bio: string;
  specialties: string[];
  rating: number;
  totalReviews: number;
  experience: number; // years of experience
  isActive: boolean;
  availableServices: string[]; // service IDs they can perform
}

export interface Admin extends User {
  role: 'admin';
  permissions: string[];
}

export interface Service {
  id: string;
  salonId: string;
  title: string;
  description: string;
  price: number;
  duration: number; // in minutes
  category: string;
  targetGender: 'male' | 'female' | 'unisex';
  isActive?: boolean;
  requiredExperience?: number; // minimum years of experience required
}

export interface Appointment {
  id: string;
  clientId: string;
  salonId: string;
  barberId: string;
  serviceId: string;
  date: string;
  time: string;
  status: 'pending' | 'approved' | 'declined' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
  client?: Client;
  barber?: Barber;
  salon?: Salon;
  service?: Service;
}

export interface Review {
  id: string;
  clientId: string;
  salonId: string;
  barberId: string;
  appointmentId: string;
  rating: number;
  comment: string;
  date: string;
  client?: Client;
}

export interface BusinessHours {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

export interface DaySchedule {
  isOpen: boolean;
  openTime: string;
  closeTime: string;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: RegisterData) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  phone: string;
  role: 'client' | 'barber';
  gender?: 'male' | 'female' | 'other';
  bio?: string;
  location?: string;
}

export interface BookingData {
  salonId: string;
  barberId: string;
  serviceId: string;
  date: string;
  time: string;
  notes?: string;
}