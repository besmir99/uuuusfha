import { DatabaseAppointment } from '../types/database';

export interface CancellationResult {
  canCancel: boolean;
  reason?: string;
  hoursUntilAppointment?: number;
}

/**
 * Check if an appointment can be cancelled based on the 3-hour rule
 */
export const canCancelAppointment = (appointment: DatabaseAppointment): CancellationResult => {
  const now = new Date();
  const appointmentDateTime = new Date(`${appointment.appointment_date}T${appointment.appointment_time}:00`);
  
  // Calculate hours until appointment
  const timeDifference = appointmentDateTime.getTime() - now.getTime();
  const hoursUntilAppointment = timeDifference / (1000 * 60 * 60);
  
  // Check if appointment is in the past
  if (hoursUntilAppointment < 0) {
    return {
      canCancel: false,
      reason: 'Cannot cancel past appointments',
      hoursUntilAppointment: Math.abs(hoursUntilAppointment)
    };
  }
  
  // Check if appointment is already cancelled or completed
  if (['cancelled_by_client', 'cancelled_by_barber', 'completed', 'no_show'].includes(appointment.status)) {
    return {
      canCancel: false,
      reason: `Appointment is already ${appointment.status.replace('_', ' ')}`,
      hoursUntilAppointment
    };
  }
  
  // Check 3-hour rule
  const CANCELLATION_HOURS_LIMIT = 3;
  if (hoursUntilAppointment < CANCELLATION_HOURS_LIMIT) {
    return {
      canCancel: false,
      reason: `You can only cancel appointments at least ${CANCELLATION_HOURS_LIMIT} hours in advance`,
      hoursUntilAppointment
    };
  }
  
  return {
    canCancel: true,
    hoursUntilAppointment
  };
};

/**
 * Get cancellation deadline for an appointment (3 hours before)
 */
export const getCancellationDeadline = (appointment: DatabaseAppointment): Date => {
  const appointmentDateTime = new Date(`${appointment.appointment_date}T${appointment.appointment_time}:00`);
  return new Date(appointmentDateTime.getTime() - (3 * 60 * 60 * 1000)); // 3 hours before
};

/**
 * Check if current time is within cancellation window
 */
export const isWithinCancellationWindow = (appointment: DatabaseAppointment): boolean => {
  const now = new Date();
  const cancellationDeadline = getCancellationDeadline(appointment);
  return now <= cancellationDeadline;
};

/**
 * Get time remaining until cancellation deadline
 */
export const getTimeUntilCancellationDeadline = (appointment: DatabaseAppointment): string => {
  const now = new Date();
  const cancellationDeadline = getCancellationDeadline(appointment);
  const timeDifference = cancellationDeadline.getTime() - now.getTime();
  const hoursRemaining = timeDifference / (1000 * 60 * 60);
  
  if (hoursRemaining <= 0) {
    return 'Cancellation deadline has passed';
  }
  
  return formatTimeUntilAppointment(hoursRemaining);
};

/**
 * Format time remaining until appointment
 */
export const formatTimeUntilAppointment = (hoursUntilAppointment: number): string => {
  if (hoursUntilAppointment < 1) {
    const minutes = Math.floor(hoursUntilAppointment * 60);
    return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
  } else if (hoursUntilAppointment < 24) {
    const hours = Math.floor(hoursUntilAppointment);
    const minutes = Math.floor((hoursUntilAppointment - hours) * 60);
    return `${hours} hour${hours !== 1 ? 's' : ''} ${minutes > 0 ? `${minutes} min` : ''}`;
  } else {
    const days = Math.floor(hoursUntilAppointment / 24);
    const hours = Math.floor(hoursUntilAppointment % 24);
    return `${days} day${days !== 1 ? 's' : ''} ${hours > 0 ? `${hours} hour${hours !== 1 ? 's' : ''}` : ''}`;
  }
};

/**
 * Cancel an appointment with proper logging
 */
export const cancelAppointment = async (
  appointmentId: string, 
  userId: string, 
  reason?: string
): Promise<{ success: boolean; message: string }> => {
  try {
    // In a real app, this would be an API call
    const appointment = getAppointmentById(appointmentId);
    
    if (!appointment) {
      return { success: false, message: 'Appointment not found' };
    }
    
    const cancellationCheck = canCancelAppointment(appointment);
    
    if (!cancellationCheck.canCancel) {
      return { success: false, message: cancellationCheck.reason || 'Cannot cancel appointment' };
    }
    
    // Update appointment status
    const updatedAppointment: Partial<DatabaseAppointment> = {
      status: 'cancelled_by_client',
      cancellation_reason: reason,
      cancelled_at: new Date().toISOString(),
      cancelled_by: userId,
      updated_at: new Date().toISOString()
    };
    
    // In a real app, this would update the database
    updateAppointmentInStorage(appointmentId, updatedAppointment);
    
    // Create notification for barber
    createCancellationNotification(appointment, userId, reason);
    
    return { 
      success: true, 
      message: 'Appointment cancelled successfully. The barber has been notified.' 
    };
    
  } catch (error) {
    console.error('Error cancelling appointment:', error);
    return { success: false, message: 'Failed to cancel appointment. Please try again.' };
  }
};

/**
 * Get appointment by ID (mock function - replace with actual database query)
 */
const getAppointmentById = (appointmentId: string): DatabaseAppointment | null => {
  // In a real app, this would query the database
  const appointments = JSON.parse(localStorage.getItem('userBookings') || '[]');
  return appointments.find((apt: any) => apt.id === appointmentId) || null;
};

/**
 * Update appointment in storage (mock function - replace with actual database update)
 */
const updateAppointmentInStorage = (appointmentId: string, updates: Partial<DatabaseAppointment>) => {
  const appointments = JSON.parse(localStorage.getItem('userBookings') || '[]');
  const updatedAppointments = appointments.map((apt: any) => 
    apt.id === appointmentId ? { ...apt, ...updates } : apt
  );
  localStorage.setItem('userBookings', JSON.stringify(updatedAppointments));
};

/**
 * Create notification for cancellation (mock function)
 */
const createCancellationNotification = (
  appointment: DatabaseAppointment, 
  cancelledBy: string, 
  reason?: string
) => {
  // In a real app, this would create a notification in the database
  console.log('Notification created:', {
    type: 'appointment_cancelled',
    appointmentId: appointment.id,
    cancelledBy,
    reason
  });
};

/**
 * Check if appointment can be modified (reschedule, etc.)
 */
export const canModifyAppointment = (appointment: DatabaseAppointment): boolean => {
  const cancellationCheck = canCancelAppointment(appointment);
  return cancellationCheck.canCancel;
};

/**
 * Validate appointment time slot availability
 */
export const isTimeSlotAvailable = (
  barberId: string,
  date: string,
  startTime: string,
  endTime: string
): boolean => {
  // Get existing appointments for the barber on that date
  const existingAppointments = JSON.parse(localStorage.getItem('userBookings') || '[]')
    .filter((apt: any) => 
      apt.barberId === barberId && 
      apt.date === date &&
      !['cancelled_by_client', 'cancelled_by_barber'].includes(apt.status)
    );
  
  // Check for time conflicts
  return !existingAppointments.some((apt: any) => {
    const aptStart = apt.time;
    const aptEnd = apt.endTime || apt.time;
    
    // Check if times overlap
    return (startTime < aptEnd && endTime > aptStart);
  });
};

/**
 * Reserve a time slot temporarily (prevents double booking)
 */
export const reserveTimeSlot = (
  barberId: string,
  date: string,
  startTime: string,
  endTime: string,
  clientId: string
): { success: boolean; reservationId?: string; message: string } => {
  
  // Check if slot is available
  if (!isTimeSlotAvailable(barberId, date, startTime, endTime)) {
    return {
      success: false,
      message: 'Time slot is no longer available'
    };
  }
  
  // Create temporary reservation
  const reservationId = `res_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const reservation = {
    id: reservationId,
    barberId,
    date,
    startTime,
    endTime,
    clientId,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString() // 15 minutes
  };
  
  // Store reservation
  const reservations = JSON.parse(localStorage.getItem('timeSlotReservations') || '[]');
  reservations.push(reservation);
  localStorage.setItem('timeSlotReservations', JSON.stringify(reservations));
  
  // Auto-expire reservation after 15 minutes
  setTimeout(() => {
    expireReservation(reservationId);
  }, 15 * 60 * 1000);
  
  return {
    success: true,
    reservationId,
    message: 'Time slot reserved for 15 minutes'
  };
};

/**
 * Expire a time slot reservation
 */
const expireReservation = (reservationId: string) => {
  const reservations = JSON.parse(localStorage.getItem('timeSlotReservations') || '[]');
  const updatedReservations = reservations.filter((res: any) => res.id !== reservationId);
  localStorage.setItem('timeSlotReservations', JSON.stringify(updatedReservations));
};

/**
 * Clean up expired reservations
 */
export const cleanupExpiredReservations = () => {
  const now = new Date();
  const reservations = JSON.parse(localStorage.getItem('timeSlotReservations') || '[]');
  const activeReservations = reservations.filter((res: any) => 
    new Date(res.expiresAt) > now
  );
  localStorage.setItem('timeSlotReservations', JSON.stringify(activeReservations));
};

// Auto-cleanup expired reservations every minute
setInterval(cleanupExpiredReservations, 60 * 1000);