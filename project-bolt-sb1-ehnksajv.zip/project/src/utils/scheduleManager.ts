import { 
  BarberSchedule, 
  TimeSlot, 
  BarberAvailability, 
  SlotReservation, 
  ScheduleConflict,
  ScheduleQuery,
  AvailableSlot,
  BreakPeriod
} from '../types/scheduling';
import { DatabaseAppointment } from '../types/database';

export class ScheduleManager {
  private static RESERVATION_TIMEOUT = 15; // minutes
  private static SLOT_DURATION = 30; // minutes
  private static BUFFER_TIME = 10; // minutes between appointments

  /**
   * Get available time slots for a barber on a specific date
   */
  static getAvailableSlots(query: ScheduleQuery): AvailableSlot[] {
    const { barber_id, date, service_duration } = query;
    
    // Get barber's schedule for the date
    const schedule = this.getBarberSchedule(barber_id, date);
    if (!schedule || !schedule.is_working) {
      return [];
    }

    // Get existing appointments for the date
    const existingAppointments = this.getAppointmentsForDate(barber_id, date);
    
    // Get reserved slots (pending appointments)
    const reservedSlots = this.getReservedSlots(barber_id, date);
    
    // Generate all possible time slots
    const allSlots = this.generateTimeSlots(
      schedule.working_hours.start,
      schedule.working_hours.end,
      service_duration
    );
    
    // Filter out unavailable slots
    const availableSlots = allSlots.filter(slot => {
      // Check if slot conflicts with existing appointments
      const hasAppointmentConflict = existingAppointments.some(apt => 
        this.timesOverlap(slot.start_time, slot.end_time, apt.appointment_time, apt.end_time)
      );
      
      // Check if slot conflicts with reserved slots
      const hasReservationConflict = reservedSlots.some(reservation => 
        this.timesOverlap(slot.start_time, slot.end_time, reservation.start_time, reservation.end_time)
      );
      
      // Check if slot conflicts with breaks
      const hasBreakConflict = schedule.breaks.some(breakPeriod =>
        this.timesOverlap(slot.start_time, slot.end_time, breakPeriod.start_time, breakPeriod.end_time)
      );
      
      return !hasAppointmentConflict && !hasReservationConflict && !hasBreakConflict;
    });
    
    return availableSlots.map(slot => ({
      ...slot,
      is_recommended: this.isRecommendedTime(slot.start_time),
      price_modifier: this.getPriceModifier(slot.start_time)
    }));
  }

  /**
   * Reserve a time slot temporarily (prevents double booking)
   */
  static async reserveSlot(
    barber_id: string,
    date: string,
    start_time: string,
    end_time: string,
    client_id: string,
    service_id: string
  ): Promise<{ success: boolean; reservation_id?: string; message: string }> {
    
    // Check if slot is still available
    const conflicts = this.checkSlotConflicts(barber_id, date, start_time, end_time);
    if (conflicts.length > 0) {
      return {
        success: false,
        message: `Slot no longer available: ${conflicts[0].message}`
      };
    }
    
    // Create reservation
    const reservation: SlotReservation = {
      id: this.generateId(),
      slot_id: `${barber_id}-${date}-${start_time}`,
      barber_id,
      client_id,
      service_id,
      reserved_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + this.RESERVATION_TIMEOUT * 60 * 1000).toISOString(),
      status: 'active'
    };
    
    // Store reservation (in real app, this would be in database)
    this.storeReservation(reservation);
    
    // Set timeout to auto-expire reservation
    setTimeout(() => {
      this.expireReservation(reservation.id);
    }, this.RESERVATION_TIMEOUT * 60 * 1000);
    
    return {
      success: true,
      reservation_id: reservation.id,
      message: `Slot reserved for ${this.RESERVATION_TIMEOUT} minutes`
    };
  }

  /**
   * Convert reservation to confirmed appointment
   */
  static async confirmReservation(
    reservation_id: string,
    appointment_data: Partial<DatabaseAppointment>
  ): Promise<{ success: boolean; appointment_id?: string; message: string }> {
    
    const reservation = this.getReservation(reservation_id);
    if (!reservation || reservation.status !== 'active') {
      return {
        success: false,
        message: 'Reservation not found or expired'
      };
    }
    
    // Check if reservation hasn't expired
    if (new Date() > new Date(reservation.expires_at)) {
      this.expireReservation(reservation_id);
      return {
        success: false,
        message: 'Reservation has expired'
      };
    }
    
    // Create confirmed appointment
    const appointment: DatabaseAppointment = {
      id: this.generateId(),
      client_id: reservation.client_id,
      salon_id: appointment_data.salon_id || '',
      barber_id: reservation.barber_id,
      service_id: reservation.service_id,
      appointment_date: appointment_data.appointment_date || '',
      appointment_time: appointment_data.appointment_time || '',
      end_time: appointment_data.end_time || '',
      status: 'pending',
      total_price: appointment_data.total_price || 0,
      payment_status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...appointment_data
    };
    
    // Store appointment and mark reservation as converted
    this.storeAppointment(appointment);
    this.updateReservationStatus(reservation_id, 'converted');
    
    return {
      success: true,
      appointment_id: appointment.id,
      message: 'Appointment confirmed successfully'
    };
  }

  /**
   * Check for scheduling conflicts
   */
  static checkSlotConflicts(
    barber_id: string,
    date: string,
    start_time: string,
    end_time: string
  ): ScheduleConflict[] {
    const conflicts: ScheduleConflict[] = [];
    
    // Check existing appointments
    const existingAppointments = this.getAppointmentsForDate(barber_id, date);
    const appointmentConflict = existingAppointments.find(apt =>
      this.timesOverlap(start_time, end_time, apt.appointment_time, apt.end_time)
    );
    
    if (appointmentConflict) {
      conflicts.push({
        type: 'double_booking',
        message: 'Time slot conflicts with existing appointment',
        conflicting_appointment_id: appointmentConflict.id
      });
    }
    
    // Check reserved slots
    const reservedSlots = this.getReservedSlots(barber_id, date);
    const reservationConflict = reservedSlots.find(reservation =>
      this.timesOverlap(start_time, end_time, reservation.start_time, reservation.end_time)
    );
    
    if (reservationConflict) {
      conflicts.push({
        type: 'double_booking',
        message: 'Time slot is currently reserved by another client'
      });
    }
    
    // Check barber schedule
    const schedule = this.getBarberSchedule(barber_id, date);
    if (!schedule || !schedule.is_working) {
      conflicts.push({
        type: 'outside_hours',
        message: 'Barber is not working on this date'
      });
    } else {
      // Check working hours
      if (start_time < schedule.working_hours.start || end_time > schedule.working_hours.end) {
        conflicts.push({
          type: 'outside_hours',
          message: 'Time slot is outside working hours'
        });
      }
      
      // Check breaks
      const breakConflict = schedule.breaks.find(breakPeriod =>
        this.timesOverlap(start_time, end_time, breakPeriod.start_time, breakPeriod.end_time)
      );
      
      if (breakConflict) {
        conflicts.push({
          type: 'break_overlap',
          message: `Time slot conflicts with ${breakConflict.title}`
        });
      }
    }
    
    return conflicts;
  }

  /**
   * Update barber's schedule for a specific date
   */
  static updateBarberSchedule(
    barber_id: string,
    date: string,
    schedule_update: Partial<BarberSchedule>
  ): { success: boolean; message: string } {
    
    // Check for conflicts with existing appointments
    if (schedule_update.working_hours || schedule_update.breaks) {
      const existingAppointments = this.getAppointmentsForDate(barber_id, date);
      
      for (const appointment of existingAppointments) {
        if (schedule_update.working_hours) {
          const { start, end } = schedule_update.working_hours;
          if (appointment.appointment_time < start || appointment.end_time > end) {
            return {
              success: false,
              message: `Cannot update schedule: conflicts with appointment at ${appointment.appointment_time}`
            };
          }
        }
        
        if (schedule_update.breaks) {
          const breakConflict = schedule_update.breaks.find(breakPeriod =>
            this.timesOverlap(
              appointment.appointment_time,
              appointment.end_time,
              breakPeriod.start_time,
              breakPeriod.end_time
            )
          );
          
          if (breakConflict) {
            return {
              success: false,
              message: `Cannot add break: conflicts with appointment at ${appointment.appointment_time}`
            };
          }
        }
      }
    }
    
    // Update schedule
    const currentSchedule = this.getBarberSchedule(barber_id, date);
    const updatedSchedule: BarberSchedule = {
      ...currentSchedule,
      ...schedule_update,
      updated_at: new Date().toISOString()
    };
    
    this.storeBarberSchedule(updatedSchedule);
    
    return {
      success: true,
      message: 'Schedule updated successfully'
    };
  }

  /**
   * Block time slots for breaks, vacation, etc.
   */
  static blockTimeSlots(
    barber_id: string,
    date: string,
    start_time: string,
    end_time: string,
    reason: string,
    title: string
  ): { success: boolean; message: string } {
    
    // Check for conflicts with existing appointments
    const existingAppointments = this.getAppointmentsForDate(barber_id, date);
    const conflict = existingAppointments.find(apt =>
      this.timesOverlap(start_time, end_time, apt.appointment_time, apt.end_time)
    );
    
    if (conflict) {
      return {
        success: false,
        message: `Cannot block time: conflicts with appointment at ${conflict.appointment_time}`
      };
    }
    
    // Add break to schedule
    const schedule = this.getBarberSchedule(barber_id, date);
    if (schedule) {
      const newBreak: BreakPeriod = {
        id: this.generateId(),
        start_time,
        end_time,
        type: reason as any,
        title,
        is_recurring: false
      };
      
      schedule.breaks.push(newBreak);
      this.storeBarberSchedule(schedule);
    }
    
    return {
      success: true,
      message: 'Time slots blocked successfully'
    };
  }

  /**
   * Clean up expired reservations
   */
  static cleanupExpiredReservations(): void {
    const now = new Date();
    const reservations = this.getAllReservations();
    
    reservations.forEach(reservation => {
      if (reservation.status === 'active' && new Date(reservation.expires_at) < now) {
        this.expireReservation(reservation.id);
      }
    });
  }

  // Private helper methods
  private static timesOverlap(
    start1: string,
    end1: string,
    start2: string,
    end2: string
  ): boolean {
    return start1 < end2 && end1 > start2;
  }

  private static generateTimeSlots(
    start_time: string,
    end_time: string,
    service_duration: number
  ): AvailableSlot[] {
    const slots: AvailableSlot[] = [];
    const startMinutes = this.timeToMinutes(start_time);
    const endMinutes = this.timeToMinutes(end_time);
    
    for (let minutes = startMinutes; minutes + service_duration <= endMinutes; minutes += this.SLOT_DURATION) {
      const slotStart = this.minutesToTime(minutes);
      const slotEnd = this.minutesToTime(minutes + service_duration);
      
      slots.push({
        start_time: slotStart,
        end_time: slotEnd,
        duration: service_duration,
        is_recommended: false
      });
    }
    
    return slots;
  }

  private static timeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  private static minutesToTime(minutes: number): string {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
  }

  private static isRecommendedTime(time: string): boolean {
    const hour = parseInt(time.split(':')[0]);
    // Recommend mid-morning and early afternoon slots
    return (hour >= 10 && hour <= 11) || (hour >= 14 && hour <= 15);
  }

  private static getPriceModifier(time: string): number {
    const hour = parseInt(time.split(':')[0]);
    // Peak hours (Friday evening, Saturday) might have higher prices
    if (hour >= 17 || hour <= 9) {
      return 1.1; // 10% premium for early/late slots
    }
    return 1.0;
  }

  private static generateId(): string {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
  }

  // Mock storage methods (replace with actual database calls)
  private static getBarberSchedule(barber_id: string, date: string): BarberSchedule | null {
    const schedules = JSON.parse(localStorage.getItem('barberSchedules') || '{}');
    return schedules[`${barber_id}-${date}`] || this.createDefaultSchedule(barber_id, date);
  }

  private static createDefaultSchedule(barber_id: string, date: string): BarberSchedule {
    const dayOfWeek = new Date(date).getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    
    return {
      id: this.generateId(),
      barber_id,
      date,
      working_hours: {
        start: isWeekend ? '10:00' : '09:00',
        end: isWeekend ? '18:00' : '17:00'
      },
      breaks: [
        {
          id: this.generateId(),
          start_time: '12:00',
          end_time: '13:00',
          type: 'lunch',
          title: 'Lunch Break',
          is_recurring: true
        }
      ],
      is_working: dayOfWeek !== 0, // Not working on Sundays
      time_slots: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  }

  private static storeBarberSchedule(schedule: BarberSchedule): void {
    const schedules = JSON.parse(localStorage.getItem('barberSchedules') || '{}');
    schedules[`${schedule.barber_id}-${schedule.date}`] = schedule;
    localStorage.setItem('barberSchedules', JSON.stringify(schedules));
  }

  private static getAppointmentsForDate(barber_id: string, date: string): DatabaseAppointment[] {
    const appointments = JSON.parse(localStorage.getItem('userBookings') || '[]');
    return appointments.filter((apt: DatabaseAppointment) => 
      apt.barber_id === barber_id && 
      apt.appointment_date === date &&
      !['cancelled_by_client', 'cancelled_by_barber'].includes(apt.status)
    );
  }

  private static getReservedSlots(barber_id: string, date: string): any[] {
    const reservations = JSON.parse(localStorage.getItem('slotReservations') || '[]');
    return reservations
      .filter((res: SlotReservation) => 
        res.barber_id === barber_id && 
        res.slot_id.includes(date) &&
        res.status === 'active' &&
        new Date(res.expires_at) > new Date()
      )
      .map((res: SlotReservation) => {
        const [, , start_time] = res.slot_id.split('-');
        return {
          start_time,
          end_time: this.minutesToTime(this.timeToMinutes(start_time) + 30), // Assume 30min slots
          reservation_id: res.id
        };
      });
  }

  private static storeReservation(reservation: SlotReservation): void {
    const reservations = JSON.parse(localStorage.getItem('slotReservations') || '[]');
    reservations.push(reservation);
    localStorage.setItem('slotReservations', JSON.stringify(reservations));
  }

  private static getReservation(reservation_id: string): SlotReservation | null {
    const reservations = JSON.parse(localStorage.getItem('slotReservations') || '[]');
    return reservations.find((res: SlotReservation) => res.id === reservation_id) || null;
  }

  private static expireReservation(reservation_id: string): void {
    this.updateReservationStatus(reservation_id, 'expired');
  }

  private static updateReservationStatus(reservation_id: string, status: SlotReservation['status']): void {
    const reservations = JSON.parse(localStorage.getItem('slotReservations') || '[]');
    const updatedReservations = reservations.map((res: SlotReservation) =>
      res.id === reservation_id ? { ...res, status } : res
    );
    localStorage.setItem('slotReservations', JSON.stringify(updatedReservations));
  }

  private static getAllReservations(): SlotReservation[] {
    return JSON.parse(localStorage.getItem('slotReservations') || '[]');
  }

  private static storeAppointment(appointment: DatabaseAppointment): void {
    const appointments = JSON.parse(localStorage.getItem('userBookings') || '[]');
    appointments.push(appointment);
    localStorage.setItem('userBookings', JSON.stringify(appointments));
  }
}

// Auto-cleanup expired reservations every minute
setInterval(() => {
  ScheduleManager.cleanupExpiredReservations();
}, 60 * 1000);