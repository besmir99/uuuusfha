import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar, Clock, User, DollarSign } from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  client: string;
  time: string;
  duration: number;
  price: number;
  status: 'pending' | 'approved' | 'completed' | 'cancelled';
}

const AppointmentCalendar: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const events: Record<string, CalendarEvent[]> = {
    '2024-01-20': [
      { id: '1', title: 'Classic Haircut', client: 'John Smith', time: '10:00', duration: 45, price: 35, status: 'approved' },
      { id: '2', title: 'Beard Trim', client: 'Mike Johnson', time: '14:30', duration: 30, price: 20, status: 'pending' }
    ],
    '2024-01-22': [
      { id: '3', title: 'Hair Wash & Cut', client: 'Sarah Wilson', time: '11:00', duration: 60, price: 45, status: 'approved' },
      { id: '4', title: 'Hair Coloring', client: 'Emma Davis', time: '15:00', duration: 120, price: 80, status: 'completed' }
    ]
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const formatDateKey = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const getEventsForDate = (date: Date | null) => {
    if (!date) return [];
    return events[formatDateKey(date)] || [];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const days = getDaysInMonth(currentDate);
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Calendar className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Appointment Calendar</h2>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => navigateMonth('prev')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
              <h3 className="text-lg font-semibold text-gray-900 min-w-[140px] text-center">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h3>
              <button
                onClick={() => navigateMonth('next')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar Grid */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-7 gap-1 mb-4">
              {dayNames.map(day => (
                <div key={day} className="p-3 text-center text-sm font-medium text-gray-600">
                  {day}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {days.map((day, index) => {
                if (!day) {
                  return <div key={index} className="p-3 h-20"></div>;
                }
                
                const dayEvents = getEventsForDate(day);
                const isSelected = selectedDate && formatDateKey(day) === formatDateKey(selectedDate);
                const isToday = formatDateKey(day) === formatDateKey(new Date());
                
                return (
                  <button
                    key={index}
                    onClick={() => setSelectedDate(day)}
                    className={`p-3 h-20 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 relative ${
                      isSelected ? 'bg-blue-50 border-blue-300' : ''
                    } ${isToday ? 'ring-2 ring-blue-500' : ''}`}
                  >
                    <div className="text-sm font-medium text-gray-900">
                      {day.getDate()}
                    </div>
                    {dayEvents.length > 0 && (
                      <div className="absolute bottom-1 left-1 right-1">
                        <div className="flex space-x-1">
                          {dayEvents.slice(0, 2).map((event, i) => (
                            <div
                              key={i}
                              className={`w-2 h-2 rounded-full ${
                                event.status === 'approved' ? 'bg-green-500' :
                                event.status === 'pending' ? 'bg-yellow-500' :
                                event.status === 'completed' ? 'bg-blue-500' :
                                'bg-red-500'
                              }`}
                            />
                          ))}
                          {dayEvents.length > 2 && (
                            <div className="text-xs text-gray-500">+{dayEvents.length - 2}</div>
                          )}
                        </div>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Event Details */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {selectedDate 
                ? `Events for ${selectedDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}`
                : 'Select a date'
              }
            </h3>
            
            <div className="space-y-4">
              {selectedDate && getEventsForDate(selectedDate).length > 0 ? (
                getEventsForDate(selectedDate).map((event) => (
                  <div key={event.id} className="p-4 border border-gray-200 rounded-xl hover:shadow-md transition-shadow duration-200">
                    <div className="flex items-start justify-between mb-3">
                      <h4 className="font-semibold text-gray-900">{event.title}</h4>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor(event.status)}`}>
                        {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                      </span>
                    </div>
                    
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4" />
                        <span>{event.client}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4" />
                        <span>{event.time} ({event.duration} min)</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <DollarSign className="w-4 h-4" />
                        <span>${event.price}</span>
                      </div>
                    </div>
                    
                    {event.status === 'pending' && (
                      <div className="flex space-x-2 mt-3">
                        <button className="flex-1 px-3 py-2 bg-green-100 text-green-700 text-sm font-medium rounded-lg hover:bg-green-200 transition-colors duration-200">
                          Accept
                        </button>
                        <button className="flex-1 px-3 py-2 bg-red-100 text-red-700 text-sm font-medium rounded-lg hover:bg-red-200 transition-colors duration-200">
                          Decline
                        </button>
                      </div>
                    )}
                  </div>
                ))
              ) : selectedDate ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No appointments scheduled</p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Click on a date to view appointments</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppointmentCalendar;