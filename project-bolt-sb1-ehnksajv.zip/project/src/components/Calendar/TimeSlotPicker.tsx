import React, { useState, useEffect } from 'react';
import { Clock, AlertCircle, CheckCircle, XCircle, Coffee, Utensils, User, Calendar } from 'lucide-react';
import { ScheduleManager } from '../../utils/scheduleManager';
import { AvailableSlot, ScheduleConflict } from '../../types/scheduling';

interface TimeSlotPickerProps {
  barberId: string;
  selectedDate: string;
  serviceDuration: number;
  onSlotSelect: (slot: AvailableSlot) => void;
  selectedSlot?: AvailableSlot | null;
  clientGender?: 'male' | 'female' | 'other';
}

const TimeSlotPicker: React.FC<TimeSlotPickerProps> = ({
  barberId,
  selectedDate,
  serviceDuration,
  onSlotSelect,
  selectedSlot,
  clientGender
}) => {
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([]);
  const [loading, setLoading] = useState(false);
  const [conflicts, setConflicts] = useState<ScheduleConflict[]>([]);
  const [reservedSlot, setReservedSlot] = useState<string | null>(null);

  useEffect(() => {
    if (barberId && selectedDate && serviceDuration) {
      loadAvailableSlots();
    }
  }, [barberId, selectedDate, serviceDuration]);

  const loadAvailableSlots = async () => {
    setLoading(true);
    try {
      const slots = ScheduleManager.getAvailableSlots({
        barber_id: barberId,
        date: selectedDate,
        service_duration: serviceDuration,
        client_gender: clientGender
      });
      setAvailableSlots(slots);
    } catch (error) {
      console.error('Error loading available slots:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSlotClick = async (slot: AvailableSlot) => {
    // Check for conflicts before allowing selection
    const slotConflicts = ScheduleManager.checkSlotConflicts(
      barberId,
      selectedDate,
      slot.start_time,
      slot.end_time
    );

    if (slotConflicts.length > 0) {
      setConflicts(slotConflicts);
      return;
    }

    setConflicts([]);
    onSlotSelect(slot);
  };

  const getSlotStatus = (slot: AvailableSlot) => {
    if (selectedSlot && selectedSlot.start_time === slot.start_time) {
      return 'selected';
    }
    if (reservedSlot === slot.start_time) {
      return 'reserved';
    }
    return 'available';
  };

  const getSlotClassName = (slot: AvailableSlot) => {
    const status = getSlotStatus(slot);
    const baseClasses = 'p-4 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 cursor-pointer';
    
    switch (status) {
      case 'selected':
        return `${baseClasses} border-blue-500 bg-blue-50 shadow-lg`;
      case 'reserved':
        return `${baseClasses} border-yellow-500 bg-yellow-50 shadow-md`;
      default:
        if (slot.is_recommended) {
          return `${baseClasses} border-green-300 bg-green-50 hover:border-green-500 hover:bg-green-100`;
        }
        return `${baseClasses} border-gray-300 bg-white hover:border-blue-300 hover:bg-blue-50`;
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getTimeOfDayLabel = (time: string) => {
    const hour = parseInt(time.split(':')[0]);
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  };

  const groupSlotsByTimeOfDay = (slots: AvailableSlot[]) => {
    const groups: { [key: string]: AvailableSlot[] } = {
      Morning: [],
      Afternoon: [],
      Evening: []
    };

    slots.forEach(slot => {
      const timeOfDay = getTimeOfDayLabel(slot.start_time);
      groups[timeOfDay].push(slot);
    });

    return groups;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-gray-600">Loading available times...</span>
      </div>
    );
  }

  if (availableSlots.length === 0) {
    return (
      <div className="text-center py-12">
        <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No Available Times</h3>
        <p className="text-gray-600 mb-4">
          No time slots are available for the selected date and service duration.
        </p>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 max-w-md mx-auto">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-yellow-800">Suggestions:</p>
              <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                <li>• Try a different date</li>
                <li>• Choose a shorter service</li>
                <li>• Contact the salon directly</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const groupedSlots = groupSlotsByTimeOfDay(availableSlots);

  return (
    <div className="space-y-6">
      {/* Conflicts Display */}
      {conflicts.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-start space-x-3">
            <XCircle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-red-800 mb-2">Scheduling Conflicts</h4>
              <ul className="space-y-1">
                {conflicts.map((conflict, index) => (
                  <li key={index} className="text-sm text-red-700">
                    • {conflict.message}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Time Slots by Time of Day */}
      {Object.entries(groupedSlots).map(([timeOfDay, slots]) => {
        if (slots.length === 0) return null;

        return (
          <div key={timeOfDay} className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                {timeOfDay === 'Morning' && <Coffee className="w-4 h-4 text-white" />}
                {timeOfDay === 'Afternoon' && <Utensils className="w-4 h-4 text-white" />}
                {timeOfDay === 'Evening' && <Clock className="w-4 h-4 text-white" />}
              </div>
              <h3 className="text-lg font-semibold text-gray-900">{timeOfDay}</h3>
              <div className="flex-1 h-px bg-gray-200"></div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {slots.map((slot, index) => (
                <button
                  key={`${slot.start_time}-${index}`}
                  onClick={() => handleSlotClick(slot)}
                  className={getSlotClassName(slot)}
                >
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-1 mb-2">
                      <Clock className="w-4 h-4 text-gray-600" />
                      <span className="font-semibold text-gray-900">
                        {formatTime(slot.start_time)}
                      </span>
                    </div>
                    
                    <div className="text-xs text-gray-600 mb-2">
                      {slot.duration} min
                    </div>

                    {/* Status Indicators */}
                    <div className="flex items-center justify-center space-x-1">
                      {slot.is_recommended && (
                        <div className="flex items-center space-x-1 text-xs text-green-600">
                          <CheckCircle className="w-3 h-3" />
                          <span>Recommended</span>
                        </div>
                      )}
                      
                      {slot.price_modifier && slot.price_modifier > 1 && (
                        <div className="text-xs text-orange-600">
                          +{Math.round((slot.price_modifier - 1) * 100)}%
                        </div>
                      )}
                    </div>

                    {/* Selection Indicator */}
                    {getSlotStatus(slot) === 'selected' && (
                      <div className="mt-2 flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        );
      })}

      {/* Legend */}
      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <h4 className="font-semibold text-gray-900 mb-3">Legend</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-50 border-2 border-green-300 rounded"></div>
            <span className="text-gray-700">Recommended</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-blue-50 border-2 border-blue-500 rounded"></div>
            <span className="text-gray-700">Selected</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-yellow-50 border-2 border-yellow-500 rounded"></div>
            <span className="text-gray-700">Reserved</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-white border-2 border-gray-300 rounded"></div>
            <span className="text-gray-700">Available</span>
          </div>
        </div>
      </div>

      {/* Booking Policy */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="font-semibold text-blue-800 mb-2">Booking Policy</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Time slots are reserved for 15 minutes during booking</li>
              <li>• Appointments must be cancelled at least 3 hours in advance</li>
              <li>• Recommended times offer the best availability</li>
              <li>• Peak hours may have premium pricing</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimeSlotPicker;