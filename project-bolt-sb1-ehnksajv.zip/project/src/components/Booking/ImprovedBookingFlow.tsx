import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, CreditCard, Check, ArrowLeft, Users, AlertCircle, MapPin, Star, Phone } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { 
  kosovoSalons, 
  kosovoBarbers, 
  kosovoServices,
  getKosovoSalonsByCity,
  getKosovoBarbersBySalon,
  getKosovoServicesByGenderAndSalon,
  getAvailableKosovoBarbers,
  KosovoSalon,
  KosovoBarber,
  KosovoService
} from '../../data/kosovoSalonData';
import { ScheduleManager } from '../../utils/scheduleManager';
import { AvailableSlot } from '../../types/scheduling';
import TimeSlotPicker from '../Calendar/TimeSlotPicker';

interface ImprovedBookingFlowProps {
  onBookingComplete?: () => void;
  onCancel?: () => void;
  selectedCity?: string;
}

const ImprovedBookingFlow: React.FC<ImprovedBookingFlowProps> = ({ 
  onBookingComplete, 
  onCancel, 
  selectedCity 
}) => {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSalon, setSelectedSalon] = useState<KosovoSalon | null>(null);
  const [selectedBarber, setSelectedBarber] = useState<KosovoBarber | null>(null);
  const [selectedService, setSelectedService] = useState<KosovoService | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState<AvailableSlot | null>(null);
  const [bookingNotes, setBookingNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reservationId, setReservationId] = useState<string | null>(null);

  const steps = [
    { number: 1, title: 'Choose Salon', icon: MapPin },
    { number: 2, title: 'Select Barber', icon: User },
    { number: 3, title: 'Pick Service', icon: CreditCard },
    { number: 4, title: 'Date & Time', icon: Calendar },
    { number: 5, title: 'Confirm', icon: Check },
  ];

  const nextWeekDates = Array.from({ length: 14 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date;
  });

  // Auto-reserve slot when selected
  useEffect(() => {
    if (selectedSlot && selectedBarber && selectedService && selectedDate && !reservationId) {
      handleSlotReservation();
    }
  }, [selectedSlot, selectedBarber, selectedService, selectedDate]);

  const handleSlotReservation = async () => {
    if (!selectedSlot || !selectedBarber || !selectedService || !user) return;

    try {
      const result = await ScheduleManager.reserveSlot(
        selectedBarber.id,
        selectedDate,
        selectedSlot.start_time,
        selectedSlot.end_time,
        user.id,
        selectedService.id
      );

      if (result.success && result.reservation_id) {
        setReservationId(result.reservation_id);
      } else {
        alert(result.message);
        setSelectedSlot(null);
      }
    } catch (error) {
      console.error('Error reserving slot:', error);
      alert('Failed to reserve time slot. Please try again.');
      setSelectedSlot(null);
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleConfirmBooking = async () => {
    if (!selectedSalon || !selectedBarber || !selectedService || !selectedDate || !selectedSlot || !reservationId) {
      alert('Please complete all booking details');
      return;
    }

    setIsSubmitting(true);

    try {
      // Calculate end time
      const startTime = selectedSlot.start_time;
      const endTime = calculateEndTime(startTime, selectedService.duration);

      // Confirm the reservation as an appointment
      const result = await ScheduleManager.confirmReservation(reservationId, {
        salon_id: selectedSalon.id,
        appointment_date: selectedDate,
        appointment_time: startTime,
        end_time: endTime,
        total_price: selectedService.price,
        notes: bookingNotes
      });

      if (result.success) {
        // Store in localStorage for demo
        const existingBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
        const newBooking = {
          id: result.appointment_id,
          clientId: user.id,
          salonId: selectedSalon.id,
          barberId: selectedBarber.id,
          serviceId: selectedService.id,
          date: selectedDate,
          time: startTime,
          endTime: endTime,
          status: 'pending',
          notes: bookingNotes,
          createdAt: new Date().toISOString(),
        };
        existingBookings.push(newBooking);
        localStorage.setItem('userBookings', JSON.stringify(existingBookings));

        alert(`🎉 Booking confirmed! 

Your appointment at ${selectedSalon.name} with ${selectedBarber.name} for ${selectedService.name} has been scheduled for ${new Date(selectedDate).toLocaleDateString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })} at ${startTime}.

The salon will review your request and confirm the appointment within 24 hours.`);

        // Reset form
        resetForm();
        
        if (onBookingComplete) {
          onBookingComplete();
        }
      } else {
        alert(result.message);
      }
    } catch (error) {
      alert('Sorry, there was an error processing your booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setCurrentStep(1);
    setSelectedSalon(null);
    setSelectedBarber(null);
    setSelectedService(null);
    setSelectedDate('');
    setSelectedSlot(null);
    setBookingNotes('');
    setReservationId(null);
  };

  const calculateEndTime = (startTime: string, durationMinutes: number): string => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60);
    const endMins = totalMinutes % 60;
    return `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1: return selectedSalon !== null;
      case 2: return selectedBarber !== null;
      case 3: return selectedService !== null;
      case 4: return selectedDate !== '' && selectedSlot !== null;
      case 5: return true;
      default: return false;
    }
  };

  const getGenderIcon = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male': return '👨';
      case 'female': return '👩';
      case 'unisex': return '👥';
      default: return '👤';
    }
  };

  const getGenderColor = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'female': return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'unisex': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return renderSalonSelection();
      case 2:
        return renderBarberSelection();
      case 3:
        return renderServiceSelection();
      case 4:
        return renderDateTimeSelection();
      case 5:
        return renderConfirmation();
      default:
        return null;
    }
  };

  const renderSalonSelection = () => {
    const filteredSalons = selectedCity 
      ? getKosovoSalonsByCity(selectedCity)
      : kosovoSalons.filter(salon => salon.isActive);

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Choose Your Salon
          {selectedCity && (
            <span className="text-lg font-normal text-gray-600 ml-2">
              in {selectedCity}
            </span>
          )}
        </h2>
        
        {filteredSalons.length === 0 ? (
          <div className="text-center py-12">
            <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No salons available</h3>
            <p className="text-gray-600">
              {selectedCity 
                ? `No salons found in ${selectedCity}. Try selecting a different city.`
                : 'No salons currently available. Please try again later.'
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSalons.map((salon) => (
              <div
                key={salon.id}
                onClick={() => setSelectedSalon(salon)}
                className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                  selectedSalon?.id === salon.id
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                }`}
              >
                <div className="flex items-start space-x-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {salon.name.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 text-lg">{salon.name}</h3>
                    <div className="flex items-center space-x-1 mt-1">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(salon.rating) 
                                ? 'text-yellow-400 fill-current' 
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {salon.rating} ({salon.totalReviews} reviews)
                      </span>
                    </div>
                    <div className="flex items-center space-x-1 mt-1">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{salon.address}</span>
                    </div>
                    <div className="flex items-center space-x-1 mt-1">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{salon.phone}</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm mb-4">{salon.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {salon.amenities.slice(0, 4).map((amenity) => (
                    <span
                      key={amenity}
                      className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                    >
                      {amenity}
                    </span>
                  ))}
                  {salon.amenities.length > 4 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                      +{salon.amenities.length - 4} more
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-600 font-medium">
                    {getKosovoBarbersBySalon(salon.id).length} barbers available
                  </span>
                  {selectedSalon?.id === salon.id && (
                    <div className="flex items-center space-x-2 text-blue-600">
                      <Check className="w-4 h-4" />
                      <span className="text-sm font-medium">Selected</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderBarberSelection = () => {
    if (!selectedSalon) return null;
    
    const availableBarbers = getKosovoBarbersBySalon(selectedSalon.id);

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Select Your Barber
          <span className="text-lg font-normal text-gray-600 ml-2">
            at {selectedSalon.name}
          </span>
        </h2>
        
        {availableBarbers.length === 0 ? (
          <div className="text-center py-12">
            <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No barbers available</h3>
            <p className="text-gray-600">
              This salon doesn't have any available barbers at the moment.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {availableBarbers.map((barber) => (
              <div
                key={barber.id}
                onClick={() => setSelectedBarber(barber)}
                className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                  selectedBarber?.id === barber.id
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                }`}
              >
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {barber.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 flex items-center space-x-2">
                      <span>{barber.name}</span>
                      <span className="text-lg">{barber.gender === 'male' ? '👨‍💼' : '👩‍💼'}</span>
                    </h3>
                    <div className="flex items-center space-x-1 mt-1">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(barber.rating) 
                                ? 'text-yellow-400 fill-current' 
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {barber.rating} ({barber.totalReviews} reviews)
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      {barber.experience} years experience
                    </p>
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm mb-3">{barber.bio}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {barber.specialties.map((specialty) => (
                    <span
                      key={specialty}
                      className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-600 font-medium">
                    {barber.availableServices.length} services available
                  </span>
                  {selectedBarber?.id === barber.id && (
                    <div className="flex items-center space-x-2 text-blue-600">
                      <Check className="w-4 h-4" />
                      <span className="text-sm font-medium">Selected</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderServiceSelection = () => {
    if (!selectedSalon || !selectedBarber) return null;

    const availableServices = getKosovoServicesByGenderAndSalon(selectedSalon.id, user?.gender || 'other')
      .filter(service => selectedBarber.availableServices.includes(service.id));

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Select a Service
          <span className="text-lg font-normal text-gray-600 ml-2">
            with {selectedBarber.name}
          </span>
        </h2>
        
        {availableServices.length === 0 ? (
          <div className="text-center py-12">
            <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No services available</h3>
            <p className="text-gray-600">
              This barber doesn't offer services matching your preferences.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {availableServices.map((service) => (
              <div
                key={service.id}
                onClick={() => setSelectedService(service)}
                className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                  selectedService?.id === service.id
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 text-lg flex items-center space-x-2">
                      <span>{getGenderIcon(service.targetGender)}</span>
                      <span>{service.name}</span>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getGenderColor(service.targetGender)}`}>
                        {service.targetGender === 'unisex' ? 'For Everyone' : `For ${service.targetGender}s`}
                      </span>
                    </h3>
                    <p className="text-gray-600 mt-2">{service.description}</p>
                    <div className="flex items-center space-x-4 mt-3">
                      <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full">
                        {service.category}
                      </span>
                      <span className="flex items-center text-sm text-gray-500">
                        <Clock className="w-4 h-4 mr-1" />
                        {service.duration} min
                      </span>
                      {service.requiredExperience && (
                        <span className="text-sm text-gray-500">
                          Requires {service.requiredExperience}+ years exp.
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-right ml-6">
                    <p className="text-2xl font-bold text-gray-900">€{service.price}</p>
                    {selectedService?.id === service.id && (
                      <div className="mt-2 flex items-center space-x-2 text-blue-600">
                        <Check className="w-4 h-4" />
                        <span className="text-sm font-medium">Selected</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderDateTimeSelection = () => {
    if (!selectedBarber || !selectedService) return null;

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Pick Date & Time</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Date Selection */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Select Date</h3>
            <div className="space-y-2">
              {nextWeekDates.map((date) => {
                const dateStr = date.toISOString().split('T')[0];
                const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
                const dayMonth = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                
                return (
                  <button
                    key={dateStr}
                    onClick={() => {
                      setSelectedDate(dateStr);
                      setSelectedSlot(null);
                      setReservationId(null);
                    }}
                    className={`w-full p-3 border-2 rounded-xl text-left transition-all duration-200 ${
                      selectedDate === dateStr
                        ? 'border-blue-500 bg-blue-50 shadow-lg'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium text-gray-900">{dayName}</p>
                        <p className="text-sm text-gray-600">{dayMonth}</p>
                      </div>
                      {selectedDate === dateStr && (
                        <Check className="w-4 h-4 text-blue-600" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slot Selection */}
          <div className="lg:col-span-2">
            {selectedDate ? (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900">Available Times</h3>
                  {reservationId && (
                    <div className="flex items-center space-x-2 text-sm text-green-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>Slot reserved for 15 minutes</span>
                    </div>
                  )}
                </div>
                <TimeSlotPicker
                  barberId={selectedBarber.id}
                  selectedDate={selectedDate}
                  serviceDuration={selectedService.duration}
                  onSlotSelect={setSelectedSlot}
                  selectedSlot={selectedSlot}
                  clientGender={user?.gender}
                />
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Please select a date first</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderConfirmation = () => {
    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Confirm Your Booking</h2>
        
        <div className="bg-gray-50 rounded-xl p-6 mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Booking Summary</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Salon:</span>
              <span className="font-medium text-gray-900">{selectedSalon?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Address:</span>
              <span className="font-medium text-gray-900">{selectedSalon?.address}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Barber:</span>
              <span className="font-medium text-gray-900">{selectedBarber?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Service:</span>
              <span className="font-medium text-gray-900 flex items-center space-x-2">
                <span>{getGenderIcon(selectedService?.targetGender || 'unisex')}</span>
                <span>{selectedService?.name}</span>
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Date:</span>
              <span className="font-medium text-gray-900">
                {selectedDate && new Date(selectedDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Time:</span>
              <span className="font-medium text-gray-900">
                {selectedSlot?.start_time} - {selectedSlot?.end_time}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duration:</span>
              <span className="font-medium text-gray-900">{selectedService?.duration} minutes</span>
            </div>
            <div className="border-t border-gray-200 pt-3 mt-3">
              <div className="flex justify-between">
                <span className="text-lg font-semibold text-gray-900">Total:</span>
                <span className="text-lg font-bold text-gray-900">€{selectedService?.price}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Special Notes (Optional)
          </label>
          <textarea
            value={bookingNotes}
            onChange={(e) => setBookingNotes(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Any special requests or notes..."
          />
        </div>

        {reservationId && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <div className="flex items-start space-x-3">
              <Check className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Time Slot Reserved</h4>
                <p className="text-sm text-green-700">
                  Your selected time slot is temporarily reserved. Complete your booking to confirm the appointment.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="bg-blue-50 rounded-xl p-6 mb-6">
          <h4 className="font-semibold text-blue-900 mb-2">Booking Policy</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Cancellations must be made at least 3 hours in advance</li>
            <li>• Late arrivals may result in shortened service time</li>
            <li>• Payment is due at the time of service</li>
            <li>• Your booking will be confirmed by the salon within 24 hours</li>
            <li>• Reserved time slots are protected from double booking</li>
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          {onCancel && (
            <button
              onClick={onCancel}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Book Appointment</h1>
            <p className="text-gray-600 mt-1">
              Find the perfect salon and barber in Kosovo
              {selectedCity && (
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-sm rounded-full">
                  📍 {selectedCity}
                </span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = currentStep === step.number;
            const isCompleted = currentStep > step.number;
            
            return (
              <div key={step.number} className="flex items-center">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-200 ${
                  isActive ? 'border-blue-500 bg-blue-500 text-white scale-110' :
                  isCompleted ? 'border-green-500 bg-green-500 text-white' :
                  'border-gray-300 bg-white text-gray-500'
                }`}>
                  {isCompleted ? <Check className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                </div>
                <div className="ml-3">
                  <p className={`text-sm font-medium transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    Step {step.number}
                  </p>
                  <p className={`text-xs transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-4 transition-colors duration-500 ${
                    isCompleted ? 'bg-green-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        {renderStepContent()}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t border-gray-200 mt-8">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            Back
          </button>
          
          {currentStep < steps.length ? (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleConfirmBooking}
              disabled={isSubmitting || !canProceed() || !reservationId}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl hover:from-green-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Check className="w-5 h-5" />
                  <span>Confirm Booking</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImprovedBookingFlow;