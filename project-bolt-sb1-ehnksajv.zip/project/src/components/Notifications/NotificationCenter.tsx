import React, { useState } from 'react';
import { Bell, Check, X, Calendar, Star, AlertCircle, Info, Eye, CheckCircle, XCircle, Clock, User } from 'lucide-react';

interface Notification {
  id: string;
  type: 'booking' | 'review' | 'reminder' | 'system';
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  actionRequired?: boolean;
  appointmentData?: {
    clientName: string;
    serviceName: string;
    date: string;
    time: string;
    price: number;
    notes?: string;
  };
}

const NotificationCenter: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'booking',
      title: 'New Booking Request',
      message: 'Sarah Johnson wants to book a haircut for tomorrow at 2:00 PM',
      time: '5 minutes ago',
      isRead: false,
      actionRequired: true,
      appointmentData: {
        clientName: 'Sarah Johnson',
        serviceName: 'Women\'s Hair Cut & Style',
        date: '2024-01-26',
        time: '14:00',
        price: 35,
        notes: 'First time client, prefers layered cut'
      }
    },
    {
      id: '2',
      type: 'booking',
      title: 'Booking Request',
      message: 'Mike Chen wants to book a beard trim for Friday at 10:30 AM',
      time: '1 hour ago',
      isRead: false,
      actionRequired: true,
      appointmentData: {
        clientName: 'Mike Chen',
        serviceName: 'Premium Beard Trim',
        date: '2024-01-26',
        time: '10:30',
        price: 15,
        notes: 'Regular client, usual style'
      }
    },
    {
      id: '3',
      type: 'review',
      title: 'New Review Received',
      message: 'Emma Davis left you a 5-star review: "Excellent service!"',
      time: '2 hours ago',
      isRead: false
    },
    {
      id: '4',
      type: 'reminder',
      title: 'Upcoming Appointment',
      message: 'Reminder: John Smith appointment in 30 minutes',
      time: '30 minutes ago',
      isRead: true
    },
    {
      id: '5',
      type: 'system',
      title: 'Profile Updated',
      message: 'Your business hours have been successfully updated',
      time: '1 day ago',
      isRead: true
    }
  ]);

  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleAcceptBooking = (id: string) => {
    setNotifications(prev => prev.map(n => 
      n.id === id ? { ...n, actionRequired: false, isRead: true } : n
    ));
    alert('Booking request accepted! The client has been notified.');
  };

  const handleDeclineBooking = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    alert('Booking request declined. The client has been notified.');
  };

  const viewNotificationDetails = (notification: Notification) => {
    setSelectedNotification(notification);
    setShowDetailsModal(true);
    markAsRead(notification.id);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'booking':
        return <Calendar className="w-5 h-5 text-vibrant-blue" />;
      case 'review':
        return <Star className="w-5 h-5 text-warning" />;
      case 'reminder':
        return <AlertCircle className="w-5 h-5 text-warning" />;
      case 'system':
        return <Info className="w-5 h-5 text-success" />;
      default:
        return <Bell className="w-5 h-5 text-slate-600" />;
    }
  };

  const getNotificationBg = (type: string) => {
    switch (type) {
      case 'booking':
        return 'bg-blue-50';
      case 'review':
        return 'bg-yellow-50';
      case 'reminder':
        return 'bg-orange-50';
      case 'system':
        return 'bg-green-50';
      default:
        return 'bg-slate-50';
    }
  };

  return (
    <>
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Header with animated bell */}
        <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className={`p-3 rounded-xl bg-gradient-to-br from-vibrant-blue to-indigo-purple ${unreadCount > 0 ? 'animate-pulse' : ''}`}>
                  <Bell className="w-6 h-6 text-white" />
                </div>
                {unreadCount > 0 && (
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-error text-white text-xs rounded-full flex items-center justify-center font-semibold animate-bounce">
                    {unreadCount}
                  </div>
                )}
              </div>
              <div>
                <h2 className="text-xl font-semibold text-slate-900">Notifications</h2>
                <p className="text-sm text-slate-600">
                  {unreadCount > 0 ? `${unreadCount} unread messages` : 'All caught up!'}
                </p>
              </div>
            </div>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-vibrant-blue hover:text-blue-700 font-medium text-sm px-4 py-2 rounded-lg hover:bg-blue-50 transition-all duration-200 border border-blue-200"
              >
                Mark all as read
              </button>
            )}
          </div>
        </div>

        <div className="max-h-96 overflow-y-auto">
          {notifications.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {notifications.map((notification, index) => (
                <div
                  key={notification.id}
                  className={`p-6 hover:bg-slate-50 transition-all duration-300 transform hover:scale-[1.01] ${
                    !notification.isRead ? 'bg-blue-50/30 border-l-4 border-l-vibrant-blue' : ''
                  }`}
                  style={{
                    animationDelay: `${index * 100}ms`,
                    animation: 'slideInRight 0.5s ease-out forwards'
                  }}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getNotificationBg(notification.type)} transition-transform duration-200 hover:scale-110 border border-slate-200`}>
                      {getNotificationIcon(notification.type)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className={`font-semibold ${!notification.isRead ? 'text-slate-900' : 'text-slate-700'} flex items-center space-x-2`}>
                            <span>{notification.title}</span>
                            {!notification.isRead && (
                              <div className="w-2 h-2 bg-vibrant-blue rounded-full animate-pulse"></div>
                            )}
                          </h3>
                          <p className="text-sm text-slate-600 mt-1">{notification.message}</p>
                          <div className="flex items-center space-x-1 mt-2">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <p className="text-xs text-slate-500">{notification.time}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 ml-4">
                          {/* View Details Button */}
                          <button
                            onClick={() => viewNotificationDetails(notification)}
                            className="p-2 text-vibrant-blue hover:text-blue-700 hover:bg-blue-100 rounded-full transition-all duration-200 transform hover:scale-110"
                            title="View details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          
                          {!notification.isRead && (
                            <button
                              onClick={() => markAsRead(notification.id)}
                              className="p-2 text-success hover:text-green-700 hover:bg-green-100 rounded-full transition-all duration-200 transform hover:scale-110"
                              title="Mark as read"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                          )}
                          
                          <button
                            onClick={() => removeNotification(notification.id)}
                            className="p-2 text-slate-400 hover:text-error hover:bg-red-100 rounded-full transition-all duration-200 transform hover:scale-110"
                            title="Remove notification"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      {/* Action Buttons for Booking Requests */}
                      {notification.actionRequired && notification.type === 'booking' && (
                        <div className="flex space-x-3 mt-4 animate-fadeIn">
                          <button
                            onClick={() => handleAcceptBooking(notification.id)}
                            className="flex items-center space-x-2 px-4 py-2 bg-success text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-all duration-200 transform hover:scale-105 shadow-sm hover:shadow-md"
                          >
                            <CheckCircle className="w-4 h-4" />
                            <span>Accept</span>
                          </button>
                          <button
                            onClick={() => handleDeclineBooking(notification.id)}
                            className="flex items-center space-x-2 px-4 py-2 bg-error text-white text-sm font-medium rounded-lg hover:bg-red-600 transition-all duration-200 transform hover:scale-105 shadow-sm hover:shadow-md"
                          >
                            <XCircle className="w-4 h-4" />
                            <span>Decline</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Bell className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-slate-500">No notifications yet</p>
            </div>
          )}
        </div>
      </div>

      {/* Notification Details Modal */}
      {showDetailsModal && selectedNotification && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl transform animate-slideInUp">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getNotificationBg(selectedNotification.type)} border border-slate-200`}>
                    {getNotificationIcon(selectedNotification.type)}
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900">{selectedNotification.title}</h3>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-full transition-all duration-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Modal Content */}
            <div className="p-6">
              <p className="text-slate-600 mb-4">{selectedNotification.message}</p>
              
              {/* Appointment Details for Booking Notifications */}
              {selectedNotification.type === 'booking' && selectedNotification.appointmentData && (
                <div className="bg-slate-50 rounded-xl p-4 mb-4 border border-slate-200">
                  <h4 className="font-semibold text-slate-900 mb-3 flex items-center space-x-2">
                    <Calendar className="w-4 h-4" />
                    <span>Appointment Details</span>
                  </h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <User className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-sm font-medium text-slate-900">Client</p>
                        <p className="text-sm text-slate-600">{selectedNotification.appointmentData.clientName}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Star className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-sm font-medium text-slate-900">Service</p>
                        <p className="text-sm text-slate-600">{selectedNotification.appointmentData.serviceName}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-sm font-medium text-slate-900">Date & Time</p>
                        <p className="text-sm text-slate-600">
                          {new Date(selectedNotification.appointmentData.date).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })} at {selectedNotification.appointmentData.time}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 text-slate-400">€</div>
                      <div>
                        <p className="text-sm font-medium text-slate-900">Price</p>
                        <p className="text-sm text-slate-600">€{selectedNotification.appointmentData.price}</p>
                      </div>
                    </div>
                    
                    {selectedNotification.appointmentData.notes && (
                      <div className="pt-2 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-1">Notes</p>
                        <p className="text-sm text-slate-600">{selectedNotification.appointmentData.notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              <div className="flex items-center space-x-1 text-xs text-slate-500 mb-4">
                <Clock className="w-3 h-3" />
                <span>{selectedNotification.time}</span>
              </div>
              
              {/* Action Buttons */}
              {selectedNotification.actionRequired && selectedNotification.type === 'booking' && (
                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      handleAcceptBooking(selectedNotification.id);
                      setShowDetailsModal(false);
                    }}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-success text-white font-medium rounded-xl hover:bg-green-700 transition-all duration-200 transform hover:scale-105 shadow-sm hover:shadow-md"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Accept Booking</span>
                  </button>
                  <button
                    onClick={() => {
                      handleDeclineBooking(selectedNotification.id);
                      setShowDetailsModal(false);
                    }}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-error text-white font-medium rounded-xl hover:bg-red-600 transition-all duration-200 transform hover:scale-105 shadow-sm hover:shadow-md"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Decline</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        
        .animate-slideInUp {
          animation: slideInUp 0.3s ease-out;
        }
      `}</style>
    </>
  );
};

export default NotificationCenter;