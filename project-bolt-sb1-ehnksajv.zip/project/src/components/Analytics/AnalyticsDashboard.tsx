import React, { useState } from 'react';
import { 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  Users, 
  Clock,
  Star,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react';

interface AnalyticsProps {
  userRole: 'barber' | 'admin';
}

const AnalyticsDashboard: React.FC<AnalyticsProps> = ({ userRole }) => {
  const [timeRange, setTimeRange] = useState('7d');

  const bookingTrends = [
    { day: 'Mon', bookings: 12, revenue: 420 },
    { day: 'Tue', bookings: 15, revenue: 525 },
    { day: 'Wed', bookings: 8, revenue: 280 },
    { day: 'Thu', bookings: 18, revenue: 630 },
    { day: 'Fri', bookings: 22, revenue: 770 },
    { day: 'Sat', bookings: 28, revenue: 980 },
    { day: 'Sun', bookings: 16, revenue: 560 },
  ];

  const maxBookings = Math.max(...bookingTrends.map(d => d.bookings));

  const performanceMetrics = {
    totalBookings: 119,
    totalRevenue: 4165,
    avgRating: 4.8,
    completionRate: 94,
    noShowRate: 6,
    repeatCustomers: 67
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="text-gray-600 mt-2">Track your performance and business insights</p>
        </div>
        <div className="flex space-x-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 3 months</option>
            <option value="1y">Last year</option>
          </select>
          <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200">
            Export Report
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Bookings</p>
              <p className="text-2xl font-bold text-gray-900">{performanceMetrics.totalBookings}</p>
              <p className="text-sm text-green-600 mt-1">+12% vs last period</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${performanceMetrics.totalRevenue}</p>
              <p className="text-sm text-green-600 mt-1">+18% vs last period</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Rating</p>
              <p className="text-2xl font-bold text-gray-900">{performanceMetrics.avgRating}</p>
              <p className="text-sm text-blue-600 mt-1">Based on 47 reviews</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completion Rate</p>
              <p className="text-2xl font-bold text-gray-900">{performanceMetrics.completionRate}%</p>
              <p className="text-sm text-green-600 mt-1">Excellent performance</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Booking Trends Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Booking Trends</h2>
            <BarChart3 className="w-5 h-5 text-gray-400" />
          </div>
          
          <div className="space-y-4">
            {bookingTrends.map((day, index) => (
              <div key={day.day} className="flex items-center space-x-4">
                <div className="w-12 text-sm font-medium text-gray-600">{day.day}</div>
                <div className="flex-1 bg-gray-100 rounded-full h-3 relative overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-full rounded-full transition-all duration-1000 ease-out"
                    style={{ 
                      width: `${(day.bookings / maxBookings) * 100}%`,
                      animationDelay: `${index * 100}ms`
                    }}
                  />
                </div>
                <div className="w-16 text-sm font-semibold text-gray-900 text-right">
                  {day.bookings}
                </div>
                <div className="w-20 text-sm text-gray-600 text-right">
                  ${day.revenue}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Breakdown */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Performance Breakdown</h2>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="font-medium text-gray-900">Completed</span>
              </div>
              <span className="font-bold text-green-700">{performanceMetrics.completionRate}%</span>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-xl">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                <span className="font-medium text-gray-900">No Shows</span>
              </div>
              <span className="font-bold text-red-700">{performanceMetrics.noShowRate}%</span>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                <span className="font-medium text-gray-900">Repeat Customers</span>
              </div>
              <span className="font-bold text-blue-700">{performanceMetrics.repeatCustomers}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
            <Activity className="w-5 h-5 text-gray-400" />
          </div>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {[
              { time: '2 hours ago', action: 'New booking confirmed', client: 'Sarah Johnson', type: 'booking' },
              { time: '4 hours ago', action: 'Review received', client: 'Mike Chen', rating: 5, type: 'review' },
              { time: '6 hours ago', action: 'Appointment completed', client: 'Emma Davis', type: 'completion' },
              { time: '1 day ago', action: 'Service updated', service: 'Premium Haircut', type: 'service' },
            ].map((activity, index) => (
              <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-xl">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  activity.type === 'booking' ? 'bg-blue-100' :
                  activity.type === 'review' ? 'bg-yellow-100' :
                  activity.type === 'completion' ? 'bg-green-100' :
                  'bg-purple-100'
                }`}>
                  {activity.type === 'booking' && <Calendar className="w-5 h-5 text-blue-600" />}
                  {activity.type === 'review' && <Star className="w-5 h-5 text-yellow-600" />}
                  {activity.type === 'completion' && <Clock className="w-5 h-5 text-green-600" />}
                  {activity.type === 'service' && <Activity className="w-5 h-5 text-purple-600" />}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{activity.action}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    {activity.client && `Client: ${activity.client}`}
                    {activity.service && `Service: ${activity.service}`}
                    {activity.rating && ` • ${activity.rating} stars`}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;