import React, { useState } from 'react';
import { Star, MapPin, Phone, Users, Clock, Award, Sparkles, Wifi, Car, Coffee } from 'lucide-react';
import { Salon } from '../../types';
import { getBarbersBySalon } from '../../data/salonData';

interface SalonCardProps {
  salon: Salon;
  onBookNow?: (salonId: string) => void;
  onViewDetails?: (salonId: string) => void;
}

const SalonCard: React.FC<SalonCardProps> = ({ salon, onBookNow, onViewDetails }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const salonBarbers = getBarbersBySalon(salon.id);
  const isOpen = salon.businessHours.monday.isOpen; // Simplified for demo

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi':
        return <Wifi className="w-3 h-3" />;
      case 'parking':
        return <Car className="w-3 h-3" />;
      case 'coffee':
      case 'refreshments':
        return <Coffee className="w-3 h-3" />;
      default:
        return <Award className="w-3 h-3" />;
    }
  };

  const getAmenityColor = (index: number) => {
    const colors = [
      'bg-blue-50 text-vibrant-blue border-blue-200',
      'bg-purple-50 text-indigo-purple border-purple-200',
      'bg-sky-50 text-sky-blue border-sky-200',
      'bg-slate-50 text-slate-700 border-slate-200',
      'bg-slate-50 text-slate-700 border-slate-200'
    ];
    return colors[index % colors.length];
  };

  return (
    <div 
      className={`bg-white rounded-2xl shadow-sm border border-slate-200 p-6 transition-all duration-500 transform relative overflow-hidden ${
        isHovered ? 'shadow-2xl scale-[1.03] border-blue-300' : 'hover:shadow-lg hover:scale-[1.01]'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Animated background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-purple-50/50 transition-opacity duration-500 ${
        isHovered ? 'opacity-100' : 'opacity-0'
      }`}></div>
      
      {/* Content */}
      <div className="relative z-10">
        {/* Header with enhanced animations */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className={`w-16 h-16 bg-gradient-to-br from-steel-gray to-slate-gray rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
                isHovered ? 'scale-110 rotate-3' : ''
              }`}>
                <span className="text-white font-bold text-xl">
                  {salon.name.charAt(0)}
                </span>
              </div>
              {/* Floating sparkle effect */}
              {isHovered && (
                <div className="absolute -top-1 -right-1 animate-bounce">
                  <Sparkles className="w-4 h-4 text-indigo-purple" />
                </div>
              )}
              {/* Verified badge */}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md border border-slate-200">
                <span className="text-sm">✅</span>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg mb-1">{salon.name}</h3>
              <div className="flex items-center space-x-2 mb-2">
                <div className="flex items-center space-x-1 bg-slate-50 px-2 py-1 rounded-full border border-slate-200">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 transition-all duration-300 ${
                        i < Math.floor(salon.rating) 
                          ? 'text-warning fill-current scale-110' 
                          : 'text-slate-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-semibold text-slate-600">
                  {salon.rating} ({salon.totalReviews} reviews)
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-3 bg-gradient-to-r from-blue-500 to-red-500 rounded-sm shadow-sm"></div>
                <span className="text-sm font-semibold text-slate-600">{salon.city}</span>
              </div>
            </div>
          </div>
          
          <div className={`px-3 py-1 rounded-full text-sm font-semibold transition-all duration-300 border ${
            isOpen 
              ? 'bg-success/10 text-success border-success/20' 
              : 'bg-error/10 text-error border-error/20'
          }`}>
            {isOpen ? '🟢 Open' : '🔴 Closed'}
          </div>
        </div>

        {/* Description with enhanced styling */}
        <div className="mb-6">
          <p className="text-slate-600 text-sm leading-relaxed line-clamp-2">{salon.description}</p>
        </div>

        {/* Information cards with animations */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-blue-300">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-vibrant-blue rounded-lg flex items-center justify-center">
                <MapPin className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Location</span>
            </div>
            <p className="text-sm font-medium text-slate-900 truncate">{salon.address}</p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-success/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-success rounded-lg flex items-center justify-center">
                <Phone className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Contact</span>
            </div>
            <p className="text-sm font-medium text-slate-900">{salon.phone}</p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-indigo-purple/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-indigo-purple rounded-lg flex items-center justify-center">
                <Users className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Staff</span>
            </div>
            <p className="text-sm font-medium text-slate-900">
              {salonBarbers.length} professional{salonBarbers.length !== 1 ? 's' : ''}
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-sky-blue/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-sky-blue rounded-lg flex items-center justify-center">
                <Clock className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Hours</span>
            </div>
            <p className="text-sm font-medium text-slate-900">
              {salon.businessHours.monday.isOpen 
                ? `${salon.businessHours.monday.openTime} - ${salon.businessHours.monday.closeTime}`
                : 'Hours vary'
              }
            </p>
          </div>
        </div>

        {/* Amenities section with enhanced design */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <Award className="w-4 h-4 text-indigo-purple" />
            <h4 className="font-semibold text-slate-900">Amenities:</h4>
          </div>
          <div className="flex flex-wrap gap-2">
            {salon.amenities.slice(0, 4).map((amenity, index) => (
              <span
                key={amenity}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all duration-300 transform hover:scale-105 border ${getAmenityColor(index)} flex items-center space-x-1`}
              >
                {getAmenityIcon(amenity)}
                <span>{amenity}</span>
              </span>
            ))}
            {salon.amenities.length > 4 && (
              <span className="px-3 py-1 bg-slate-50 text-slate-600 text-xs font-semibold rounded-full border border-slate-200">
                +{salon.amenities.length - 4} more
              </span>
            )}
          </div>
        </div>

        {/* Action buttons with enhanced animations */}
        <div className="flex space-x-3">
          {onViewDetails && (
            <button 
              onClick={() => onViewDetails(salon.id)}
              className="flex-1 bg-slate-100 text-slate-700 py-3 rounded-xl hover:bg-slate-200 transition-all duration-300 font-semibold transform hover:scale-105 shadow-sm hover:shadow-md border border-slate-200"
            >
              View Details
            </button>
          )}
          {onBookNow && (
            <button
              onClick={() => onBookNow(salon.id)}
              className={`flex-1 bg-gradient-to-r from-vibrant-blue to-indigo-purple text-white py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg ${
                isHovered ? 'from-blue-700 to-purple-700 shadow-xl' : 'hover:from-blue-700 hover:to-purple-700'
              }`}
            >
              Book Now
            </button>
          )}
        </div>

        {/* Floating elements for extra visual appeal */}
        {isHovered && (
          <>
            <div className="absolute top-4 right-4 w-2 h-2 bg-vibrant-blue rounded-full animate-ping"></div>
            <div className="absolute bottom-4 left-4 w-1 h-1 bg-indigo-purple rounded-full animate-pulse"></div>
            <div className="absolute top-1/2 left-2 w-1 h-1 bg-sky-blue rounded-full animate-bounce"></div>
          </>
        )}
      </div>
    </div>
  );
};

export default SalonCard;