import React, { useState, useEffect } from 'react';
import { 
  Store, 
  Clock, 
  Users, 
  Scissors, 
  Calendar, 
  Settings, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X,
  CheckCircle,
  XCircle,
  AlertCircle,
  Coffee,
  Utensils,
  User,
  Star,
  DollarSign,
  MapPin,
  Phone,
  Mail,
  Globe,
  Camera,
  Upload
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { mockSalons, mockBarbers, mockServices } from '../../data/salonData';
import { Salon, Barber, Service, BusinessHours, DaySchedule } from '../../types';

interface SalonManagerProps {
  salonId?: string;
}

const SalonManager: React.FC<SalonManagerProps> = ({ salonId }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [salon, setSalon] = useState<Salon | null>(null);
  const [salonBarbers, setSalonBarbers] = useState<Barber[]>([]);
  const [salonServices, setSalonServices] = useState<Service[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [showAddModal, setShowAddModal] = useState<'barber' | 'service' | null>(null);

  // Form states
  const [editingSalon, setEditingSalon] = useState<Partial<Salon>>({});
  const [newBarber, setNewBarber] = useState<Partial<Barber>>({
    name: '',
    email: '',
    phone: '',
    bio: '',
    specialties: [],
    experience: 1,
    availableServices: []
  });
  const [newService, setNewService] = useState<Partial<Service>>({
    title: '',
    description: '',
    price: 0,
    duration: 30,
    category: '',
    targetGender: 'unisex',
    isActive: true
  });

  useEffect(() => {
    // Load salon data
    const currentSalon = mockSalons.find(s => s.id === salonId) || mockSalons[0];
    setSalon(currentSalon);
    setEditingSalon(currentSalon);
    
    // Load salon barbers and services
    setSalonBarbers(mockBarbers.filter(b => b.salonId === currentSalon.id));
    setSalonServices(mockServices.filter(s => s.salonId === currentSalon.id));
  }, [salonId]);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Store },
    { id: 'schedule', label: 'Schedule & Hours', icon: Clock },
    { id: 'services', label: 'Services', icon: Scissors },
    { id: 'team', label: 'Team Management', icon: Users },
    { id: 'appointments', label: 'Appointments', icon: Calendar },
    { id: 'settings', label: 'Salon Settings', icon: Settings }
  ];

  const serviceCategories = [
    'Haircut', 'Grooming', 'Shaving', 'Coloring', 'Treatment', 
    'Styling', 'Facial', 'Extensions', 'Consultation'
  ];

  const handleSaveSalon = () => {
    if (salon && editingSalon) {
      const updatedSalon = { ...salon, ...editingSalon };
      setSalon(updatedSalon);
      setIsEditing(false);
      alert('Salon information updated successfully!');
    }
  };

  const handleAddBarber = () => {
    if (!newBarber.name || !newBarber.email || !newBarber.phone) {
      alert('Please fill in all required fields');
      return;
    }

    const barber: Barber = {
      id: `barber-${Date.now()}`,
      name: newBarber.name!,
      email: newBarber.email!,
      phone: newBarber.phone!,
      role: 'barber',
      gender: 'male',
      salonId: salon?.id || '',
      bio: newBarber.bio || '',
      specialties: newBarber.specialties || [],
      rating: 4.5,
      totalReviews: 0,
      experience: newBarber.experience || 1,
      isActive: true,
      availableServices: newBarber.availableServices || [],
      createdAt: new Date().toISOString()
    };

    setSalonBarbers(prev => [...prev, barber]);
    setNewBarber({
      name: '',
      email: '',
      phone: '',
      bio: '',
      specialties: [],
      experience: 1,
      availableServices: []
    });
    setShowAddModal(null);
    alert('Barber added successfully!');
  };

  const handleAddService = () => {
    if (!newService.title || !newService.description || !newService.price) {
      alert('Please fill in all required fields');
      return;
    }

    const service: Service = {
      id: `service-${Date.now()}`,
      salonId: salon?.id || '',
      title: newService.title!,
      description: newService.description!,
      price: newService.price!,
      duration: newService.duration!,
      category: newService.category!,
      targetGender: newService.targetGender!,
      isActive: newService.isActive!
    };

    setSalonServices(prev => [...prev, service]);
    setNewService({
      title: '',
      description: '',
      price: 0,
      duration: 30,
      category: '',
      targetGender: 'unisex',
      isActive: true
    });
    setShowAddModal(null);
    alert('Service added successfully!');
  };

  const handleRemoveBarber = (barberId: string) => {
    if (confirm('Are you sure you want to remove this barber?')) {
      setSalonBarbers(prev => prev.filter(b => b.id !== barberId));
      alert('Barber removed successfully!');
    }
  };

  const handleRemoveService = (serviceId: string) => {
    if (confirm('Are you sure you want to remove this service?')) {
      setSalonServices(prev => prev.filter(s => s.id !== serviceId));
      alert('Service removed successfully!');
    }
  };

  const toggleServiceStatus = (serviceId: string) => {
    setSalonServices(prev => prev.map(service => 
      service.id === serviceId ? { ...service, isActive: !service.isActive } : service
    ));
  };

  const updateBusinessHours = (day: keyof BusinessHours, schedule: DaySchedule) => {
    if (editingSalon.businessHours) {
      setEditingSalon(prev => ({
        ...prev,
        businessHours: {
          ...prev.businessHours!,
          [day]: schedule
        }
      }));
    }
  };

  const getGenderIcon = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male': return '👨';
      case 'female': return '👩';
      case 'unisex': return '👥';
      default: return '👤';
    }
  };

  const getGenderColor = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'female': return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'unisex': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (!salon) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Store className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{salon.name}</h1>
              <p className="text-slate-300">Salon Management Dashboard</p>
              <div className="flex items-center space-x-4 mt-2 text-sm">
                <div className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span>{salon.city}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400" />
                  <span>{salon.rating} ({salon.totalReviews} reviews)</span>
                </div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{salonBarbers.length}</div>
            <div className="text-slate-300 text-sm">Team Members</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 bg-gray-50">
        <nav className="flex space-x-8 px-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-600">Total Services</p>
                    <p className="text-2xl font-bold text-blue-900">{salonServices.length}</p>
                  </div>
                  <Scissors className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              
              <div className="bg-green-50 p-6 rounded-xl border border-green-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-600">Team Members</p>
                    <p className="text-2xl font-bold text-green-900">{salonBarbers.length}</p>
                  </div>
                  <Users className="w-8 h-8 text-green-600" />
                </div>
              </div>
              
              <div className="bg-purple-50 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-600">Avg. Service Price</p>
                    <p className="text-2xl font-bold text-purple-900">
                      €{Math.round(salonServices.reduce((sum, s) => sum + s.price, 0) / salonServices.length || 0)}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-purple-600" />
                </div>
              </div>
              
              <div className="bg-orange-50 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-orange-600">Rating</p>
                    <p className="text-2xl font-bold text-orange-900">{salon.rating}</p>
                  </div>
                  <Star className="w-8 h-8 text-orange-600" />
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => setShowAddModal('service')}
                  className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
                >
                  <Plus className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">Add New Service</span>
                </button>
                
                <button
                  onClick={() => setShowAddModal('barber')}
                  className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-all duration-200"
                >
                  <Plus className="w-5 h-5 text-green-600" />
                  <span className="font-medium text-gray-900">Add Team Member</span>
                </button>
                
                <button
                  onClick={() => setActiveTab('schedule')}
                  className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all duration-200"
                >
                  <Clock className="w-5 h-5 text-purple-600" />
                  <span className="font-medium text-gray-900">Manage Schedule</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Schedule Tab */}
        {activeTab === 'schedule' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Schedule & Working Hours</h2>
              <div className="flex space-x-3">
                {isEditing ? (
                  <>
                    <button
                      onClick={handleSaveSalon}
                      className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700 transition-colors duration-200"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-xl hover:bg-gray-700 transition-colors duration-200"
                    >
                      <X className="w-4 h-4" />
                      <span>Cancel</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Edit Schedule</span>
                  </button>
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Weekly Schedule</h3>
              <div className="space-y-4">
                {Object.entries(editingSalon.businessHours || salon.businessHours).map(([day, schedule]) => (
                  <div key={day} className="flex items-center space-x-6 p-4 bg-white rounded-lg border border-gray-200">
                    <div className="w-24">
                      <span className="font-medium text-gray-900 capitalize">{day}</span>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={schedule.isOpen}
                          onChange={(e) => isEditing && updateBusinessHours(day as keyof BusinessHours, {
                            ...schedule,
                            isOpen: e.target.checked
                          })}
                          disabled={!isEditing}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">Open</span>
                      </label>
                      
                      {schedule.isOpen && (
                        <>
                          <input
                            type="time"
                            value={schedule.openTime}
                            onChange={(e) => isEditing && updateBusinessHours(day as keyof BusinessHours, {
                              ...schedule,
                              openTime: e.target.value
                            })}
                            disabled={!isEditing}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                          />
                          <span className="text-gray-500">to</span>
                          <input
                            type="time"
                            value={schedule.closeTime}
                            onChange={(e) => isEditing && updateBusinessHours(day as keyof BusinessHours, {
                              ...schedule,
                              closeTime: e.target.value
                            })}
                            disabled={!isEditing}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                          />
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Services Tab */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Services Management</h2>
              <button
                onClick={() => setShowAddModal('service')}
                className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
              >
                <Plus className="w-4 h-4" />
                <span>Add Service</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {salonServices.map((service) => (
                <div
                  key={service.id}
                  className={`p-6 border rounded-xl transition-all duration-200 ${
                    service.isActive 
                      ? 'border-gray-200 bg-white hover:shadow-md' 
                      : 'border-gray-200 bg-gray-50 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                        <span className={`px-3 py-1 text-xs font-medium rounded-full border ${getGenderColor(service.targetGender)}`}>
                          {getGenderIcon(service.targetGender)} {service.targetGender === 'unisex' ? 'For Everyone' : `For ${service.targetGender}s`}
                        </span>
                        <span className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">
                          {service.category}
                        </span>
                        <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                          service.isActive 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {service.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 mb-3">{service.description}</p>
                      
                      <div className="flex items-center space-x-6 text-sm text-gray-500">
                        <span className="flex items-center space-x-1">
                          <DollarSign className="w-4 h-4" />
                          <span>€{service.price}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{service.duration} minutes</span>
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => toggleServiceStatus(service.id)}
                        className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                          service.isActive
                            ? 'bg-red-100 text-red-700 hover:bg-red-200'
                            : 'bg-green-100 text-green-700 hover:bg-green-200'
                        }`}
                      >
                        {service.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      
                      <button
                        onClick={() => handleRemoveService(service.id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Team Tab */}
        {activeTab === 'team' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
              <button
                onClick={() => setShowAddModal('barber')}
                className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
              >
                <Plus className="w-4 h-4" />
                <span>Add Team Member</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {salonBarbers.map((barber) => (
                <div key={barber.id} className="bg-white p-6 border border-gray-200 rounded-xl hover:shadow-md transition-shadow duration-200">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">{barber.name.charAt(0)}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{barber.name}</h3>
                        <p className="text-sm text-gray-600">{barber.experience} years experience</p>
                        <div className="flex items-center space-x-1 mt-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600">{barber.rating}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveBarber(barber.id)}
                      className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-3">{barber.bio}</p>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{barber.email}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{barber.phone}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Specialties:</p>
                    <div className="flex flex-wrap gap-2">
                      {barber.specialties.map((specialty, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full"
                        >
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Appointments Tab */}
        {activeTab === 'appointments' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Appointment Management</h2>
            
            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Appointment Management</h3>
              <p className="text-gray-600">
                This section will show all salon appointments with filtering and management options.
              </p>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Salon Settings</h2>
              <div className="flex space-x-3">
                {isEditing ? (
                  <>
                    <button
                      onClick={handleSaveSalon}
                      className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700 transition-colors duration-200"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-xl hover:bg-gray-700 transition-colors duration-200"
                    >
                      <X className="w-4 h-4" />
                      <span>Cancel</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Edit Settings</span>
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Basic Information */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Salon Name</label>
                    <input
                      type="text"
                      value={editingSalon.name || ''}
                      onChange={(e) => setEditingSalon(prev => ({ ...prev, name: e.target.value }))}
                      disabled={!isEditing}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                    <textarea
                      value={editingSalon.description || ''}
                      onChange={(e) => setEditingSalon(prev => ({ ...prev, description: e.target.value }))}
                      disabled={!isEditing}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                    <input
                      type="text"
                      value={editingSalon.address || ''}
                      onChange={(e) => setEditingSalon(prev => ({ ...prev, address: e.target.value }))}
                      disabled={!isEditing}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input
                      type="tel"
                      value={editingSalon.phone || ''}
                      onChange={(e) => setEditingSalon(prev => ({ ...prev, phone: e.target.value }))}
                      disabled={!isEditing}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                </div>
              </div>

              {/* Amenities */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Amenities</h3>
                <div className="space-y-3">
                  {['WiFi', 'Air Conditioning', 'Coffee', 'Parking', 'Card Payment', 'Music System', 'Magazines'].map((amenity) => (
                    <label key={amenity} className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={editingSalon.amenities?.includes(amenity) || false}
                        onChange={(e) => {
                          if (isEditing) {
                            const currentAmenities = editingSalon.amenities || [];
                            if (e.target.checked) {
                              setEditingSalon(prev => ({
                                ...prev,
                                amenities: [...currentAmenities, amenity]
                              }));
                            } else {
                              setEditingSalon(prev => ({
                                ...prev,
                                amenities: currentAmenities.filter(a => a !== amenity)
                              }));
                            }
                          }
                        }}
                        disabled={!isEditing}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                      />
                      <span className="text-sm text-gray-700">{amenity}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Barber Modal */}
      {showAddModal === 'barber' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Add New Team Member</h3>
                <button
                  onClick={() => setShowAddModal(null)}
                  className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                  <input
                    type="text"
                    value={newBarber.name}
                    onChange={(e) => setNewBarber(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter full name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                  <input
                    type="email"
                    value={newBarber.email}
                    onChange={(e) => setNewBarber(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter email address"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone *</label>
                  <input
                    type="tel"
                    value={newBarber.phone}
                    onChange={(e) => setNewBarber(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter phone number"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Experience (Years)</label>
                  <input
                    type="number"
                    value={newBarber.experience}
                    onChange={(e) => setNewBarber(prev => ({ ...prev, experience: Number(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                    max="50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
                <textarea
                  value={newBarber.bio}
                  onChange={(e) => setNewBarber(prev => ({ ...prev, bio: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Brief description of experience and specialties"
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowAddModal(null)}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddBarber}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors duration-200"
                >
                  Add Team Member
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Service Modal */}
      {showAddModal === 'service' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Add New Service</h3>
                <button
                  onClick={() => setShowAddModal(null)}
                  className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Service Name *</label>
                  <input
                    type="text"
                    value={newService.title}
                    onChange={(e) => setNewService(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Classic Haircut"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                  <select
                    value={newService.category}
                    onChange={(e) => setNewService(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select Category</option>
                    {serviceCategories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price (€) *</label>
                  <input
                    type="number"
                    value={newService.price}
                    onChange={(e) => setNewService(prev => ({ ...prev, price: Number(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="25"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Duration (minutes)</label>
                  <input
                    type="number"
                    value={newService.duration}
                    onChange={(e) => setNewService(prev => ({ ...prev, duration: Number(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="45"
                    min="15"
                    step="15"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Target Gender</label>
                <div className="flex space-x-4">
                  {(['male', 'female', 'unisex'] as const).map(gender => (
                    <label key={gender} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="targetGender"
                        value={gender}
                        checked={newService.targetGender === gender}
                        onChange={(e) => setNewService(prev => ({ ...prev, targetGender: e.target.value as 'male' | 'female' | 'unisex' }))}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <span className="flex items-center space-x-1">
                        <span>{getGenderIcon(gender)}</span>
                        <span className="capitalize">{gender === 'unisex' ? 'For Everyone' : `For ${gender}s`}</span>
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description *</label>
                <textarea
                  value={newService.description}
                  onChange={(e) => setNewService(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Describe your service in detail..."
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowAddModal(null)}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddService}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors duration-200"
                >
                  Add Service
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalonManager;