import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Plus, Edit, Trash2, Coffee, Utensils, User, AlertTriangle, Save, X } from 'lucide-react';
import { ScheduleManager } from '../../utils/scheduleManager';
import { BarberSchedule, BreakPeriod } from '../../types/scheduling';
import { mockBarbers } from '../../data/mockData';

interface ScheduleManagerProps {
  salonId?: string;
}

const AdminScheduleManager: React.FC<ScheduleManagerProps> = ({ salonId }) => {
  const [selectedBarber, setSelectedBarber] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [schedule, setSchedule] = useState<BarberSchedule | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showAddBreak, setShowAddBreak] = useState(false);
  const [newBreak, setNewBreak] = useState<Partial<BreakPeriod>>({
    start_time: '',
    end_time: '',
    type: 'lunch',
    title: '',
    is_recurring: false
  });

  const barbers = mockBarbers.filter(barber => !salonId || barber.salonId === salonId);

  useEffect(() => {
    if (selectedBarber && selectedDate) {
      loadSchedule();
    }
  }, [selectedBarber, selectedDate]);

  const loadSchedule = () => {
    // In real app, this would fetch from API
    const mockSchedule: BarberSchedule = {
      id: `schedule-${selectedBarber}-${selectedDate}`,
      barber_id: selectedBarber,
      date: selectedDate,
      working_hours: {
        start: '09:00',
        end: '17:00'
      },
      breaks: [
        {
          id: 'break-1',
          start_time: '12:00',
          end_time: '13:00',
          type: 'lunch',
          title: 'Lunch Break',
          is_recurring: true
        }
      ],
      is_working: true,
      time_slots: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    setSchedule(mockSchedule);
  };

  const handleSaveSchedule = () => {
    if (!schedule) return;

    const result = ScheduleManager.updateBarberSchedule(
      selectedBarber,
      selectedDate,
      schedule
    );

    if (result.success) {
      setIsEditing(false);
      alert('Schedule updated successfully!');
    } else {
      alert(`Error: ${result.message}`);
    }
  };

  const handleAddBreak = () => {
    if (!schedule || !newBreak.start_time || !newBreak.end_time || !newBreak.title) {
      alert('Please fill in all break details');
      return;
    }

    const breakToAdd: BreakPeriod = {
      id: `break-${Date.now()}`,
      start_time: newBreak.start_time,
      end_time: newBreak.end_time,
      type: newBreak.type || 'lunch',
      title: newBreak.title,
      is_recurring: newBreak.is_recurring || false
    };

    const result = ScheduleManager.blockTimeSlots(
      selectedBarber,
      selectedDate,
      breakToAdd.start_time,
      breakToAdd.end_time,
      breakToAdd.type,
      breakToAdd.title
    );

    if (result.success) {
      setSchedule({
        ...schedule,
        breaks: [...schedule.breaks, breakToAdd]
      });
      setNewBreak({
        start_time: '',
        end_time: '',
        type: 'lunch',
        title: '',
        is_recurring: false
      });
      setShowAddBreak(false);
      alert('Break added successfully!');
    } else {
      alert(`Error: ${result.message}`);
    }
  };

  const handleRemoveBreak = (breakId: string) => {
    if (!schedule) return;

    if (confirm('Are you sure you want to remove this break?')) {
      setSchedule({
        ...schedule,
        breaks: schedule.breaks.filter(b => b.id !== breakId)
      });
    }
  };

  const getBreakIcon = (type: string) => {
    switch (type) {
      case 'lunch':
        return <Utensils className="w-4 h-4" />;
      case 'coffee':
        return <Coffee className="w-4 h-4" />;
      case 'personal':
        return <User className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getBreakColor = (type: string) => {
    switch (type) {
      case 'lunch':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'coffee':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'personal':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Calendar className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Schedule Management</h2>
              <p className="text-sm text-gray-600">Manage barber schedules, breaks, and availability</p>
            </div>
          </div>
          {schedule && (
            <div className="flex space-x-3">
              {isEditing ? (
                <>
                  <button
                    onClick={handleSaveSchedule}
                    className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700 transition-colors duration-200"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Changes</span>
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-xl hover:bg-gray-700 transition-colors duration-200"
                  >
                    <X className="w-4 h-4" />
                    <span>Cancel</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
                >
                  <Edit className="w-4 h-4" />
                  <span>Edit Schedule</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="p-6">
        {/* Barber and Date Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Barber</label>
            <select
              value={selectedBarber}
              onChange={(e) => setSelectedBarber(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Choose a barber...</option>
              {barbers.map((barber) => (
                <option key={barber.id} value={barber.id}>
                  {barber.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {schedule && (
          <div className="space-y-6">
            {/* Working Hours */}
            <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Working Hours</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={schedule.is_working ? 'working' : 'off'}
                    onChange={(e) => setSchedule({
                      ...schedule,
                      is_working: e.target.value === 'working'
                    })}
                    disabled={!isEditing}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                  >
                    <option value="working">Working</option>
                    <option value="off">Day Off</option>
                  </select>
                </div>

                {schedule.is_working && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                      <input
                        type="time"
                        value={schedule.working_hours.start}
                        onChange={(e) => setSchedule({
                          ...schedule,
                          working_hours: {
                            ...schedule.working_hours,
                            start: e.target.value
                          }
                        })}
                        disabled={!isEditing}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                      <input
                        type="time"
                        value={schedule.working_hours.end}
                        onChange={(e) => setSchedule({
                          ...schedule,
                          working_hours: {
                            ...schedule.working_hours,
                            end: e.target.value
                          }
                        })}
                        disabled={!isEditing}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Breaks */}
            {schedule.is_working && (
              <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Breaks & Blocked Time</h3>
                  {isEditing && (
                    <button
                      onClick={() => setShowAddBreak(true)}
                      className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Break</span>
                    </button>
                  )}
                </div>

                <div className="space-y-3">
                  {schedule.breaks.map((breakPeriod) => (
                    <div
                      key={breakPeriod.id}
                      className={`p-4 rounded-xl border ${getBreakColor(breakPeriod.type)} flex items-center justify-between`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                          {getBreakIcon(breakPeriod.type)}
                        </div>
                        <div>
                          <h4 className="font-semibold">{breakPeriod.title}</h4>
                          <p className="text-sm opacity-75">
                            {breakPeriod.start_time} - {breakPeriod.end_time}
                            {breakPeriod.is_recurring && ' (Daily)'}
                          </p>
                        </div>
                      </div>
                      
                      {isEditing && (
                        <button
                          onClick={() => handleRemoveBreak(breakPeriod.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}

                  {schedule.breaks.length === 0 && (
                    <div className="text-center py-8">
                      <Clock className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500">No breaks scheduled</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Existing Appointments Warning */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-yellow-800 mb-2">Important Notes</h4>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    <li>• Changes to working hours will be checked against existing appointments</li>
                    <li>• Adding breaks that conflict with appointments will be prevented</li>
                    <li>• Clients will be notified of any schedule changes that affect their bookings</li>
                    <li>• Reserved time slots (pending bookings) are protected from conflicts</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {!selectedBarber && (
          <div className="text-center py-12">
            <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Barber</h3>
            <p className="text-gray-600">Choose a barber to view and manage their schedule</p>
          </div>
        )}
      </div>

      {/* Add Break Modal */}
      {showAddBreak && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Add Break</h3>
                <button
                  onClick={() => setShowAddBreak(false)}
                  className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Break Title</label>
                <input
                  type="text"
                  value={newBreak.title}
                  onChange={(e) => setNewBreak({ ...newBreak, title: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Lunch Break"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Break Type</label>
                <select
                  value={newBreak.type}
                  onChange={(e) => setNewBreak({ ...newBreak, type: e.target.value as any })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="lunch">Lunch</option>
                  <option value="coffee">Coffee Break</option>
                  <option value="personal">Personal</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                  <input
                    type="time"
                    value={newBreak.start_time}
                    onChange={(e) => setNewBreak({ ...newBreak, start_time: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                  <input
                    type="time"
                    value={newBreak.end_time}
                    onChange={(e) => setNewBreak({ ...newBreak, end_time: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="recurring"
                  checked={newBreak.is_recurring}
                  onChange={(e) => setNewBreak({ ...newBreak, is_recurring: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="recurring" className="text-sm text-gray-700">
                  Recurring daily break
                </label>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowAddBreak(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddBreak}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors duration-200"
                >
                  Add Break
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminScheduleManager;