import React, { useState } from 'react';
import { Plus, Edit, Trash2, Save, X, Users, Scissors } from 'lucide-react';
import { Service } from '../../types';
import { mockServices } from '../../data/mockData';

interface ServiceManagementProps {
  barberId: string;
}

const ServiceManagement: React.FC<ServiceManagementProps> = ({ barberId }) => {
  const [services, setServices] = useState<Service[]>(
    mockServices.filter(service => service.barberId === barberId)
  );
  const [isAddingService, setIsAddingService] = useState(false);
  const [editingService, setEditingService] = useState<string | null>(null);
  const [newService, setNewService] = useState<Partial<Service>>({
    title: '',
    description: '',
    price: 0,
    duration: 30,
    category: '',
    targetGender: 'unisex',
    isActive: true
  });

  const serviceCategories = [
    'Haircut', 'Grooming', 'Shaving', 'Coloring', 'Treatment', 
    'Styling', 'Facial', 'Extensions', 'Consultation'
  ];

  const handleAddService = () => {
    if (!newService.title || !newService.description || !newService.price) {
      alert('Please fill in all required fields');
      return;
    }

    const service: Service = {
      id: Date.now().toString(),
      barberId,
      title: newService.title!,
      description: newService.description!,
      price: newService.price!,
      duration: newService.duration!,
      category: newService.category!,
      targetGender: newService.targetGender!,
      isActive: newService.isActive!
    };

    setServices(prev => [...prev, service]);
    setNewService({
      title: '',
      description: '',
      price: 0,
      duration: 30,
      category: '',
      targetGender: 'unisex',
      isActive: true
    });
    setIsAddingService(false);
  };

  const handleEditService = (serviceId: string, updatedService: Partial<Service>) => {
    setServices(prev => prev.map(service => 
      service.id === serviceId ? { ...service, ...updatedService } : service
    ));
    setEditingService(null);
  };

  const handleDeleteService = (serviceId: string) => {
    if (confirm('Are you sure you want to delete this service?')) {
      setServices(prev => prev.filter(service => service.id !== serviceId));
    }
  };

  const toggleServiceStatus = (serviceId: string) => {
    setServices(prev => prev.map(service => 
      service.id === serviceId ? { ...service, isActive: !service.isActive } : service
    ));
  };

  const getGenderIcon = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male':
        return '👨';
      case 'female':
        return '👩';
      case 'unisex':
        return '👥';
      default:
        return '👤';
    }
  };

  const getGenderColor = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'female':
        return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'unisex':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Scissors className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Service Management</h2>
              <p className="text-sm text-gray-600">Manage your services and pricing</p>
            </div>
          </div>
          <button
            onClick={() => setIsAddingService(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
          >
            <Plus className="w-4 h-4" />
            <span>Add Service</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        {/* Add New Service Form */}
        {isAddingService && (
          <div className="mb-6 p-6 bg-gray-50 rounded-xl border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Service</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Service Name</label>
                <input
                  type="text"
                  value={newService.title}
                  onChange={(e) => setNewService(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Classic Haircut"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={newService.category}
                  onChange={(e) => setNewService(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Category</option>
                  {serviceCategories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Price (€)</label>
                <input
                  type="number"
                  value={newService.price}
                  onChange={(e) => setNewService(prev => ({ ...prev, price: Number(e.target.value) }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="25"
                  min="0"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Duration (minutes)</label>
                <input
                  type="number"
                  value={newService.duration}
                  onChange={(e) => setNewService(prev => ({ ...prev, duration: Number(e.target.value) }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="45"
                  min="15"
                  step="15"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Target Gender</label>
              <div className="flex space-x-4">
                {(['male', 'female', 'unisex'] as const).map(gender => (
                  <label key={gender} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="targetGender"
                      value={gender}
                      checked={newService.targetGender === gender}
                      onChange={(e) => setNewService(prev => ({ ...prev, targetGender: e.target.value as 'male' | 'female' | 'unisex' }))}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span className="flex items-center space-x-1">
                      <span>{getGenderIcon(gender)}</span>
                      <span className="capitalize">{gender === 'unisex' ? 'For Everyone' : `For ${gender}s`}</span>
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
              <textarea
                value={newService.description}
                onChange={(e) => setNewService(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Describe your service in detail..."
              />
            </div>

            <div className="flex space-x-3">
              <button
                onClick={handleAddService}
                className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700 transition-colors duration-200"
              >
                <Save className="w-4 h-4" />
                <span>Save Service</span>
              </button>
              <button
                onClick={() => setIsAddingService(false)}
                className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-xl hover:bg-gray-700 transition-colors duration-200"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </div>
          </div>
        )}

        {/* Services List */}
        <div className="space-y-4">
          {services.length === 0 ? (
            <div className="text-center py-12">
              <Scissors className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No services yet</h3>
              <p className="text-gray-600 mb-4">Add your first service to start accepting bookings</p>
              <button
                onClick={() => setIsAddingService(true)}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
              >
                Add Your First Service
              </button>
            </div>
          ) : (
            services.map((service) => (
              <div
                key={service.id}
                className={`p-6 border rounded-xl transition-all duration-200 ${
                  service.isActive 
                    ? 'border-gray-200 bg-white hover:shadow-md' 
                    : 'border-gray-200 bg-gray-50 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                      <span className={`px-3 py-1 text-xs font-medium rounded-full border ${getGenderColor(service.targetGender)}`}>
                        {getGenderIcon(service.targetGender)} {service.targetGender === 'unisex' ? 'For Everyone' : `For ${service.targetGender}s`}
                      </span>
                      <span className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">
                        {service.category}
                      </span>
                      <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                        service.isActive 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {service.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    
                    <p className="text-gray-600 mb-3">{service.description}</p>
                    
                    <div className="flex items-center space-x-6 text-sm text-gray-500">
                      <span>€{service.price}</span>
                      <span>{service.duration} minutes</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <button
                      onClick={() => toggleServiceStatus(service.id)}
                      className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                        service.isActive
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    >
                      {service.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                    
                    <button
                      onClick={() => setEditingService(service.id)}
                      className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    
                    <button
                      onClick={() => handleDeleteService(service.id)}
                      className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Service Statistics */}
        {services.length > 0 && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-xl">
              <div className="text-2xl font-bold text-blue-700">{services.length}</div>
              <div className="text-sm text-blue-600">Total Services</div>
            </div>
            <div className="bg-green-50 p-4 rounded-xl">
              <div className="text-2xl font-bold text-green-700">
                {services.filter(s => s.isActive).length}
              </div>
              <div className="text-sm text-green-600">Active Services</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-xl">
              <div className="text-2xl font-bold text-purple-700">
                €{Math.round(services.reduce((sum, s) => sum + s.price, 0) / services.length)}
              </div>
              <div className="text-sm text-purple-600">Average Price</div>
            </div>
            <div className="bg-orange-50 p-4 rounded-xl">
              <div className="text-2xl font-bold text-orange-700">
                {Math.round(services.reduce((sum, s) => sum + s.duration, 0) / services.length)}
              </div>
              <div className="text-sm text-orange-600">Avg Duration (min)</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceManagement;