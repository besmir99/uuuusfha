import React, { useState } from 'react';
import { Star, MapPin, Clock, DollarSign, Phone, Users, Award, Sparkles } from 'lucide-react';
import { Barber } from '../../types';
import { mockServices } from '../../data/mockData';

interface BarberCardProps {
  barber: Barber;
  onBookNow?: (barberId: string) => void;
}

const BarberCard: React.FC<BarberCardProps> = ({ barber, onBookNow }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const barberServices = mockServices.filter(service => service.barberId === barber.id);
  const priceRange = barberServices.length > 0 ? {
    min: Math.min(...barberServices.map(s => s.price)),
    max: Math.max(...barberServices.map(s => s.price))
  } : { min: 0, max: 0 };

  // Extract city from location for display
  const getCity = (location: string) => {
    if (location.includes('Prishtinë')) return 'Prishtina';
    if (location.includes('Prizren')) return 'Prizren';
    if (location.includes('Gjakovë')) return 'Gjakova';
    if (location.includes('Pejë')) return 'Peja';
    if (location.includes('Mitrovicë')) return 'Mitrovica';
    if (location.includes('Ferizaj')) return 'Ferizaj';
    if (location.includes('Gjilan')) return 'Gjilan';
    return location.split(',')[1]?.trim() || 'Kosovo';
  };

  const getGenderIcon = (gender: 'male' | 'female' | 'other') => {
    switch (gender) {
      case 'male': return '👨‍💼';
      case 'female': return '👩‍💼';
      default: return '👤';
    }
  };

  return (
    <div 
      className={`bg-white rounded-2xl shadow-sm border border-slate-200 p-6 transition-all duration-500 transform relative overflow-hidden ${
        isHovered ? 'shadow-2xl scale-[1.03] border-blue-300' : 'hover:shadow-lg hover:scale-[1.01]'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Animated background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-purple-50/50 transition-opacity duration-500 ${
        isHovered ? 'opacity-100' : 'opacity-0'
      }`}></div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header with animated elements */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className={`w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
                isHovered ? 'scale-110 rotate-3' : ''
              }`}>
                <span className="text-white font-bold text-xl">
                  {barber.name.charAt(0)}
                </span>
              </div>
              {/* Floating sparkle effect */}
              {isHovered && (
                <div className="absolute -top-1 -right-1 animate-bounce">
                  <Sparkles className="w-4 h-4 text-indigo-purple" />
                </div>
              )}
              {/* Gender indicator */}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md border border-slate-200">
                <span className="text-sm">{getGenderIcon(barber.gender || 'other')}</span>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg mb-1">{barber.name}</h3>
              <div className="flex items-center space-x-2 mb-2">
                <div className="flex items-center space-x-1 bg-slate-50 px-2 py-1 rounded-full border border-slate-200">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 transition-all duration-300 ${
                        i < Math.floor(barber.rating) 
                          ? 'text-warning fill-current scale-110' 
                          : 'text-slate-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-semibold text-slate-600">
                  {barber.rating} ({barber.totalReviews} reviews)
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-3 bg-gradient-to-r from-blue-500 to-red-500 rounded-sm shadow-sm"></div>
                <span className="text-sm font-semibold text-slate-600">{getCity(barber.location)}</span>
              </div>
            </div>
          </div>
          
          <div className={`px-3 py-1 rounded-full text-sm font-semibold transition-all duration-300 border ${
            barber.isActive 
              ? 'bg-success/10 text-success border-success/20' 
              : 'bg-slate-100 text-slate-600 border-slate-200'
          }`}>
            {barber.isActive ? '🟢 Available' : '🔴 Busy'}
          </div>
        </div>

        {/* Bio with enhanced styling */}
        <div className="mb-6">
          <p className="text-slate-600 text-sm leading-relaxed line-clamp-2">{barber.bio}</p>
        </div>

        {/* Information cards with animations */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-blue-300">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-vibrant-blue rounded-lg flex items-center justify-center">
                <MapPin className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Location</span>
            </div>
            <p className="text-sm font-medium text-slate-900 truncate">{barber.location}</p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-success/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-success rounded-lg flex items-center justify-center">
                <Phone className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Contact</span>
            </div>
            <p className="text-sm font-medium text-slate-900">{barber.phone}</p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-indigo-purple/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-indigo-purple rounded-lg flex items-center justify-center">
                <DollarSign className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Pricing</span>
            </div>
            <p className="text-sm font-medium text-slate-900">
              €{priceRange.min} - €{priceRange.max}
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 transition-all duration-300 hover:shadow-md hover:border-sky-blue/30">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-sky-blue rounded-lg flex items-center justify-center">
                <Clock className="w-3 h-3 text-white" />
              </div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Hours</span>
            </div>
            <p className="text-sm font-medium text-slate-900">
              {barber.businessHours.monday.isOpen 
                ? `${barber.businessHours.monday.openTime} - ${barber.businessHours.monday.closeTime}`
                : 'Hours vary'
              }
            </p>
          </div>
        </div>

        {/* Services section with enhanced design */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <Award className="w-4 h-4 text-indigo-purple" />
            <h4 className="font-semibold text-slate-900">Specialties:</h4>
          </div>
          <div className="flex flex-wrap gap-2">
            {barberServices.slice(0, 3).map((service, index) => (
              <span
                key={service.id}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all duration-300 transform hover:scale-105 border ${
                  index === 0 ? 'bg-blue-50 text-vibrant-blue border-blue-200' :
                  index === 1 ? 'bg-purple-50 text-indigo-purple border-purple-200' :
                  'bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                {service.title}
              </span>
            ))}
            {barberServices.length > 3 && (
              <span className="px-3 py-1 bg-slate-50 text-slate-600 text-xs font-semibold rounded-full border border-slate-200">
                +{barberServices.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* Action buttons with enhanced animations */}
        <div className="flex space-x-3">
          <button className="flex-1 bg-slate-100 text-slate-700 py-3 rounded-xl hover:bg-slate-200 transition-all duration-300 font-semibold transform hover:scale-105 shadow-sm hover:shadow-md border border-slate-200">
            View Profile
          </button>
          <button
            onClick={() => onBookNow && onBookNow(barber.id)}
            className={`flex-1 bg-gradient-to-r from-vibrant-blue to-indigo-purple text-white py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg ${
              isHovered ? 'from-blue-700 to-purple-700 shadow-xl' : 'hover:from-blue-700 hover:to-purple-700'
            }`}
          >
            Book Now
          </button>
        </div>

        {/* Floating elements for extra visual appeal */}
        {isHovered && (
          <>
            <div className="absolute top-4 right-4 w-2 h-2 bg-vibrant-blue rounded-full animate-ping"></div>
            <div className="absolute bottom-4 left-4 w-1 h-1 bg-indigo-purple rounded-full animate-pulse"></div>
          </>
        )}
      </div>
    </div>
  );
};

export default BarberCard;