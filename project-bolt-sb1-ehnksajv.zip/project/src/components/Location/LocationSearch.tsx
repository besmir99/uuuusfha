import React, { useState } from 'react';
import { MapPin, Search, Navigation, Filter } from 'lucide-react';
import { kosovoSalons } from '../../data/kosovoSalonData';

// Extract unique cities from salon data
const getUniqueCities = () => {
  const cities = kosovoSalons.map(salon => ({
    name: salon.city,
    barberShops: kosovoSalons.filter(s => s.city === salon.city)
  }));
  
  // Remove duplicates
  const uniqueCities = cities.filter((city, index, self) => 
    index === self.findIndex(c => c.name === city.name)
  );
  
  return uniqueCities;
};

interface LocationSearchProps {
  onLocationSelect: (location: string) => void;
  currentLocation?: string;
}

const LocationSearch: React.FC<LocationSearchProps> = ({ onLocationSelect, currentLocation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const cities = getUniqueCities();
  
  // Filter cities based on search query
  const filteredCities = cities.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const popularCities = [
    'Prishtina', 'Prizren', 'Gjakova', 'Peja', 
    'Mitrovica', 'Ferizaj', 'Gjilan', 'Vushtrri'
  ];

  const handleCurrentLocation = () => {
    setIsSearching(true);
    // Simulate geolocation API
    setTimeout(() => {
      onLocationSelect('Current Location (Prishtina)');
      setIsSearching(false);
    }, 1500);
  };

  const handleCitySelect = (cityName: string) => {
    onLocationSelect(cityName);
    setSearchQuery('');
    setShowSuggestions(false);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    setShowSuggestions(value.length > 0);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
          <MapPin className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Find Barbers in Kosovo</h2>
          <p className="text-sm text-gray-600">Discover top-rated barbers across Kosovo</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="relative">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            onFocus={() => setShowSuggestions(searchQuery.length > 0)}
            placeholder="Search cities in Kosovo..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          />
          
          {/* Search Suggestions */}
          {showSuggestions && filteredCities.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
              {filteredCities.slice(0, 8).map((city) => (
                <button
                  key={city.id}
                  onClick={() => handleCitySelect(city.name)}
                  className="w-full text-left px-4 py-3 hover:bg-blue-50 transition-colors duration-200 border-b border-gray-100 last:border-b-0"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{city.name}</p>
                      <p className="text-sm text-gray-600">Kosovo</p>
                    </div>
                    <div className="text-xs text-blue-600 font-medium">
                      {city.barberShops.length} barbers
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={handleCurrentLocation}
          disabled={isSearching}
          className="w-full flex items-center justify-center space-x-2 py-3 bg-gradient-to-r from-emerald-500 to-blue-600 text-white rounded-xl hover:from-emerald-600 hover:to-blue-700 transition-all duration-200 disabled:opacity-50"
        >
          <Navigation className={`w-5 h-5 ${isSearching ? 'animate-spin' : ''}`} />
          <span>{isSearching ? 'Getting your location...' : 'Use Current Location'}</span>
        </button>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center space-x-2">
            <span>Popular Cities in Kosovo</span>
            <div className="w-6 h-4 bg-gradient-to-r from-blue-500 to-red-500 rounded-sm"></div>
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {popularCities.map((cityName) => {
              const city = cities.find(c => c.name === cityName);
              return (
                <button
                  key={cityName}
                  onClick={() => handleCitySelect(cityName)}
                  className="p-3 text-left bg-gray-50 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors duration-200 text-sm font-medium group"
                >
                  <div className="flex items-center justify-between">
                    <span>{cityName}</span>
                    <span className="text-xs text-gray-500 group-hover:text-blue-600">
                      {city?.barberShops.length || 0} salons
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Current Selection */}
        {currentLocation && (
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">Selected Location:</span>
            </div>
            <p className="text-blue-800 font-semibold mt-1">{currentLocation}</p>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{cities.length}</div>
            <div className="text-xs text-gray-600">Cities</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">
              {kosovoSalons.length}
            </div>
            <div className="text-xs text-gray-600">Salons</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationSearch;