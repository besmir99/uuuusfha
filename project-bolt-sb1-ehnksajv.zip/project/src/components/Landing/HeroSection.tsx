import React, { useState, useEffect } from 'react';
import { Scissors, Star, Users, Calendar, ArrowRight, Play, CheckCircle, MapPin } from 'lucide-react';
import { kosovoCities } from '../../data/kosovoData';

interface HeroSectionProps {
  onSignUpClient: () => void;
  onSignUpBarber: () => void;
  onLogin: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onSignUpClient, onSignUpBarber, onLogin }) => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: "Ardit Krasniqi",
      role: "Client from Prishtina",
      content: "BarberBook made finding the perfect barber in Prishtina so easy! The booking system is seamless and I love getting reminders.",
      rating: 5,
      avatar: "AK"
    },
    {
      name: "Besart Gashi",
      role: "Professional Barber, Prizren",
      content: "This platform transformed my business in Prizren. I can manage my schedule efficiently and connect with more clients than ever.",
      rating: 5,
      avatar: "BG"
    },
    {
      name: "Driton Berisha",
      role: "Satisfied Customer, Gjakova",
      content: "The quality of barbers on this platform across Kosovo is outstanding. Every appointment has exceeded my expectations!",
      rating: 5,
      avatar: "DB"
    }
  ];

  const features = [
    {
      icon: Calendar,
      title: "Easy Booking",
      description: "Schedule appointments in seconds across all major Kosovo cities"
    },
    {
      icon: Users,
      title: "Verified Barbers",
      description: "Connect with skilled, professional barbers throughout Kosovo"
    },
    {
      icon: Star,
      title: "Quality Guaranteed",
      description: "Read reviews and ratings from real customers across Kosovo"
    }
  ];

  const totalBarberShops = kosovoCities.reduce((total, city) => total + city.barberShops.length, 0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden bg-navy-black">
      {/* Enhanced Animated Background Pattern */}
      <div className="absolute inset-0">
        {/* Primary Background Image with Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-15"
          style={{
            backgroundImage: `url('https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
          }}
        />
        
        {/* Rich Navy Black Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-navy-black/98 via-steel-gray/95 to-navy-black/98" />
        
        {/* Animated Gradient Accents with exact colors */}
        <div className="absolute inset-0 bg-gradient-to-r from-vibrant-blue/8 via-transparent to-indigo-purple/8 animate-pulse-slow" />
        
        {/* Enhanced Floating Geometric Elements */}
        <div className="absolute top-20 left-10 w-40 h-40 bg-gradient-to-br from-vibrant-blue/15 to-indigo-purple/15 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-56 h-56 bg-gradient-to-br from-indigo-purple/12 to-sky-blue/12 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-gradient-to-br from-sky-blue/15 to-vibrant-blue/15 rounded-full blur-xl animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/3 right-1/3 w-24 h-24 bg-gradient-to-br from-indigo-purple/20 to-sky-blue/20 rounded-full blur-lg animate-float" style={{ animationDelay: '3s' }}></div>
        
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Enhanced Navigation with exact colors */}
        <nav className="flex items-center justify-between p-6 lg:px-12">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-16 h-16 bg-gradient-to-br from-vibrant-blue to-indigo-purple rounded-3xl flex items-center justify-center shadow-2xl shadow-vibrant-blue/25 animate-glow">
                <Scissors className="w-8 h-8 text-light-gray" />
              </div>
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-success rounded-full border-2 border-navy-black animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-light-gray">BarberBook</h1>
              <p className="text-subtle text-sm flex items-center space-x-1">
                <MapPin className="w-3 h-3" />
                <span>Kosovo's Premier Platform</span>
              </p>
            </div>
          </div>
          
          <button
            onClick={onLogin}
            className="hidden md:flex items-center space-x-2 px-6 py-3 bg-steel-gray/30 backdrop-blur-sm text-light-gray rounded-xl hover:bg-steel-gray/50 transition-all duration-300 border border-muted/20 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <span className="font-medium">Sign In</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </nav>

        {/* Hero Content */}
        <div className="flex-1 flex items-center justify-center px-6 lg:px-12">
          <div className="max-w-6xl mx-auto text-center">
            {/* Main Headline with Enhanced Typography */}
            <div className="mb-8">
              <div className="mb-6">
                <span className="inline-block px-6 py-3 bg-vibrant-blue/20 text-vibrant-blue text-sm font-semibold rounded-full border border-vibrant-blue/30 backdrop-blur-sm animate-slideInUp shadow-lg">
                  🇽🇰 Proudly Serving Kosovo
                </span>
              </div>
              
              <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold text-light-gray mb-8 leading-tight animate-slideInUp" style={{ animationDelay: '0.2s' }}>
                Kosovo's Premier
                <span className="block bg-gradient-to-r from-vibrant-blue via-indigo-purple to-sky-blue bg-clip-text text-transparent animate-gradient bg-300% animate-slideInUp" style={{ animationDelay: '0.4s' }}>
                  Barbering Platform
                </span>
                <span className="block text-5xl md:text-6xl lg:text-7xl mt-4 text-muted animate-slideInUp" style={{ animationDelay: '0.6s' }}>
                  Awaits You
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl text-muted max-w-4xl mx-auto leading-relaxed animate-slideInUp" style={{ animationDelay: '0.8s' }}>
                Connect with skilled barbers across Kosovo, from Prishtina to Prizren. 
                Book appointments instantly and experience premium grooming services with our cutting-edge platform.
              </p>
            </div>

            {/* Enhanced CTA Buttons with exact colors */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16 animate-slideInUp" style={{ animationDelay: '1s' }}>
              <button
                onClick={onSignUpClient}
                className="group w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-vibrant-blue to-indigo-purple text-light-gray rounded-2xl font-semibold text-lg hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-2xl shadow-vibrant-blue/25 hover:shadow-vibrant-blue/40 flex items-center justify-center space-x-3 btn-animate"
              >
                <Users className="w-6 h-6" />
                <span>Book as Client</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              
              <button
                onClick={onSignUpBarber}
                className="group w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-indigo-purple to-sky-blue text-light-gray rounded-2xl font-semibold text-lg hover:from-purple-700 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 shadow-2xl shadow-indigo-purple/25 hover:shadow-indigo-purple/40 flex items-center justify-center space-x-3 btn-animate"
              >
                <Scissors className="w-6 h-6" />
                <span>Join as Barber</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              
              <button
                onClick={onLogin}
                className="group w-full sm:w-auto px-10 py-5 bg-steel-gray/40 backdrop-blur-sm text-light-gray rounded-2xl font-semibold text-lg hover:bg-steel-gray/60 transform hover:scale-105 transition-all duration-300 border border-muted/30 shadow-lg hover:shadow-xl flex items-center justify-center space-x-3"
              >
                <span>Sign In</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
            </div>

            {/* Enhanced Stats with Animations and exact colors */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-20 animate-slideInUp" style={{ animationDelay: '1.2s' }}>
              <div className="text-center group">
                <div className="text-5xl font-bold text-light-gray mb-3 group-hover:scale-110 transition-transform duration-300">2K+</div>
                <div className="text-muted text-lg">Happy Clients</div>
                <div className="w-16 h-1 bg-gradient-to-r from-vibrant-blue to-indigo-purple mx-auto mt-3 rounded-full"></div>
              </div>
              <div className="text-center group">
                <div className="text-5xl font-bold text-light-gray mb-3 group-hover:scale-110 transition-transform duration-300">{totalBarberShops}+</div>
                <div className="text-muted text-lg">Professional Barbers</div>
                <div className="w-16 h-1 bg-gradient-to-r from-indigo-purple to-sky-blue mx-auto mt-3 rounded-full"></div>
              </div>
              <div className="text-center group">
                <div className="text-5xl font-bold text-light-gray mb-3 group-hover:scale-110 transition-transform duration-300">{kosovoCities.length}</div>
                <div className="text-muted text-lg">Cities Covered</div>
                <div className="w-16 h-1 bg-gradient-to-r from-sky-blue to-vibrant-blue mx-auto mt-3 rounded-full"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Features Section with exact colors */}
        <div className="px-6 lg:px-12 pb-16">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="group p-8 bg-steel-gray/25 backdrop-blur-sm rounded-3xl border border-muted/15 hover:bg-steel-gray/40 transition-all duration-300 transform hover:scale-105 hover-lift animate-slideInUp"
                    style={{ animationDelay: `${1.4 + index * 0.2}s` }}
                  >
                    <div className="w-16 h-16 bg-gradient-to-br from-vibrant-blue to-indigo-purple rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-vibrant-blue/20">
                      <Icon className="w-8 h-8 text-light-gray" />
                    </div>
                    <h3 className="text-2xl font-semibold text-light-gray mb-3">{feature.title}</h3>
                    <p className="text-muted text-lg leading-relaxed">{feature.description}</p>
                  </div>
                );
              })}
            </div>

            {/* Kosovo Cities Showcase with Enhanced Design and exact colors */}
            <div className="bg-steel-gray/25 backdrop-blur-sm rounded-3xl border border-muted/15 p-10 mb-10 animate-slideInUp" style={{ animationDelay: '2s' }}>
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-light-gray mb-4 flex items-center justify-center space-x-3">
                  <MapPin className="w-8 h-8 text-vibrant-blue" />
                  <span>Serving All Major Kosovo Cities</span>
                </h3>
                <p className="text-muted text-lg">From Prishtina to Prizren, find quality barbers everywhere</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {kosovoCities.slice(0, 8).map((city, index) => (
                  <div 
                    key={city.id} 
                    className="text-center p-5 bg-slate-gray/25 rounded-2xl hover:bg-slate-gray/40 transition-all duration-200 transform hover:scale-105 border border-muted/10 animate-slideInUp"
                    style={{ animationDelay: `${2.2 + index * 0.1}s` }}
                  >
                    <div className="text-xl font-semibold text-light-gray">{city.name}</div>
                    <div className="text-sm text-muted mt-1">{city.barberShops.length} barbers</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Enhanced Testimonial Slider with exact colors */}
            <div className="bg-steel-gray/25 backdrop-blur-sm rounded-3xl border border-muted/15 p-10 max-w-5xl mx-auto animate-slideInUp" style={{ animationDelay: '2.4s' }}>
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-light-gray mb-4">What Kosovo Says About Us</h3>
                <div className="flex justify-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 text-warning fill-current" />
                  ))}
                </div>
              </div>

              <div className="relative overflow-hidden">
                <div 
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(-${currentTestimonial * 100}%)` }}
                >
                  {testimonials.map((testimonial, index) => (
                    <div key={index} className="w-full flex-shrink-0 text-center px-6">
                      <div className="w-20 h-20 bg-gradient-to-br from-vibrant-blue to-indigo-purple rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-vibrant-blue/20">
                        <span className="text-light-gray font-bold text-xl">{testimonial.avatar}</span>
                      </div>
                      <blockquote className="text-xl text-muted mb-6 italic leading-relaxed">
                        "{testimonial.content}"
                      </blockquote>
                      <div className="text-light-gray font-semibold text-lg">{testimonial.name}</div>
                      <div className="text-muted text-sm mt-1">{testimonial.role}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Enhanced Testimonial Indicators with exact colors */}
              <div className="flex justify-center space-x-3 mt-8">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    className={`w-4 h-4 rounded-full transition-all duration-300 ${
                      index === currentTestimonial 
                        ? 'bg-vibrant-blue scale-125 shadow-lg shadow-vibrant-blue/50' 
                        : 'bg-muted/40 hover:bg-muted/60'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Scroll Indicator with exact colors */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-8 h-12 border-2 border-muted/40 rounded-full flex justify-center">
            <div className="w-1 h-4 bg-vibrant-blue rounded-full mt-3 animate-pulse" />
          </div>
        </div>

        {/* Enhanced Floating Action Elements with exact colors */}
        <div className="absolute top-1/4 right-10 hidden lg:block animate-float">
          <div className="w-4 h-4 bg-vibrant-blue rounded-full shadow-lg shadow-vibrant-blue/50"></div>
        </div>
        <div className="absolute bottom-1/4 left-10 hidden lg:block animate-float" style={{ animationDelay: '1s' }}>
          <div className="w-3 h-3 bg-indigo-purple rounded-full shadow-lg shadow-indigo-purple/50"></div>
        </div>
        <div className="absolute top-1/2 right-1/4 hidden lg:block animate-float" style={{ animationDelay: '2s' }}>
          <div className="w-2 h-2 bg-sky-blue rounded-full shadow-lg shadow-sky-blue/50"></div>
        </div>
        <div className="absolute top-3/4 left-1/3 hidden lg:block animate-float" style={{ animationDelay: '1.5s' }}>
          <div className="w-3 h-3 bg-vibrant-blue rounded-full shadow-lg shadow-vibrant-blue/50"></div>
        </div>

        {/* Additional Decorative Elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-vibrant-blue via-indigo-purple to-sky-blue opacity-60"></div>
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-sky-blue via-vibrant-blue to-indigo-purple opacity-40"></div>
      </div>

      <style jsx>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        .animate-gradient {
          background-size: 300% 300%;
          animation: gradient 3s ease infinite;
        }
        
        .bg-300\\% {
          background-size: 300% 300%;
        }
      `}</style>
    </div>
  );
};

export default HeroSection;