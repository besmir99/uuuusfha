import React, { useState } from 'react';
import HeroSection from './HeroSection';
import LoginForm from '../Auth/LoginForm';
import RegisterForm from '../Auth/RegisterForm';

interface LandingPageProps {
  onLogin: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  const [currentView, setCurrentView] = useState<'hero' | 'login' | 'register-client' | 'register-barber'>('hero');

  const handleSignUpClient = () => {
    setCurrentView('register-client');
  };

  const handleSignUpBarber = () => {
    setCurrentView('register-barber');
  };

  const handleShowLogin = () => {
    setCurrentView('login');
  };

  const handleBackToHero = () => {
    setCurrentView('hero');
  };

  if (currentView === 'login') {
    return (
      <div className="relative">
        <button
          onClick={handleBackToHero}
          className="absolute top-4 left-4 z-50 flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm text-gray-700 rounded-xl hover:bg-white/20 transition-all duration-300"
        >
          ← Back to Home
        </button>
        <LoginForm onToggleMode={handleBackToHero} />
      </div>
    );
  }

  if (currentView === 'register-client' || currentView === 'register-barber') {
    return (
      <div className="relative">
        <button
          onClick={handleBackToHero}
          className="absolute top-4 left-4 z-50 flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm text-gray-700 rounded-xl hover:bg-white/20 transition-all duration-300"
        >
          ← Back to Home
        </button>
        <RegisterForm 
          onToggleMode={handleBackToHero}
          defaultRole={currentView === 'register-barber' ? 'barber' : 'client'}
        />
      </div>
    );
  }

  return (
    <HeroSection
      onSignUpClient={handleSignUpClient}
      onSignUpBarber={handleSignUpBarber}
      onLogin={handleShowLogin}
    />
  );
};

export default LandingPage;