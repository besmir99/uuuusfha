import React from 'react';
import { Users, Calendar, DollarSign, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { mockUsers, mockAppointments, mockBarbers } from '../../data/mockData';

const AdminDashboard: React.FC = () => {
  const totalUsers = mockUsers.length;
  const totalBarbers = mockBarbers.length;
  const totalAppointments = mockAppointments.length;
  const pendingAppointments = mockAppointments.filter(apt => apt.status === 'pending').length;
  const completedAppointments = mockAppointments.filter(apt => apt.status === 'completed').length;
  const monthlyRevenue = 12450;

  const recentActivity = [
    { id: 1, type: 'user_registered', description: 'New client Sarah Johnson registered', time: '2 hours ago' },
    { id: 2, type: 'appointment_booked', description: 'Appointment booked with Mike Johnson', time: '4 hours ago' },
    { id: 3, type: 'barber_joined', description: 'New barber Alex Wilson joined', time: '1 day ago' },
    { id: 4, type: 'review_posted', description: 'New review posted for Sarah Wilson', time: '2 days ago' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Monitor and manage your BarberBook platform</p>
        </div>
        <div className="flex space-x-3">
          <button className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-xl hover:bg-gray-50 transition-colors duration-200">
            Export Data
          </button>
          <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200">
            System Settings
          </button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Users</p>
              <p className="text-2xl font-bold text-gray-900">{totalUsers}</p>
              <p className="text-sm text-green-600 mt-1">+12% from last month</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Barbers</p>
              <p className="text-2xl font-bold text-gray-900">{totalBarbers}</p>
              <p className="text-sm text-green-600 mt-1">+3 new this week</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Bookings</p>
              <p className="text-2xl font-bold text-gray-900">{totalAppointments}</p>
              <p className="text-sm text-blue-600 mt-1">{pendingAppointments} pending</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${monthlyRevenue.toLocaleString()}</p>
              <p className="text-sm text-green-600 mt-1">+18% from last month</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-semibold text-gray-900">System Alerts</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <h3 className="font-medium text-yellow-800">Pending Barber Approval</h3>
                  <p className="text-sm text-yellow-700 mt-1">2 new barber applications require review</p>
                  <button className="text-yellow-800 hover:text-yellow-900 font-medium text-sm mt-2">
                    Review Applications →
                  </button>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h3 className="font-medium text-blue-800">System Maintenance</h3>
                  <p className="text-sm text-blue-700 mt-1">Scheduled maintenance on Jan 25, 2024 at 2:00 AM</p>
                  <button className="text-blue-800 hover:text-blue-900 font-medium text-sm mt-2">
                    View Details →
                  </button>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-4 bg-green-50 border border-green-200 rounded-xl">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h3 className="font-medium text-green-800">Backup Completed</h3>
                  <p className="text-sm text-green-700 mt-1">Daily backup completed successfully at 3:00 AM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-semibold text-gray-900">Quick Actions</h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors duration-200">
                <span className="font-medium text-gray-900">Manage Users</span>
                <Users className="w-5 h-5 text-gray-400" />
              </button>
              
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors duration-200">
                <span className="font-medium text-gray-900">View Reports</span>
                <TrendingUp className="w-5 h-5 text-gray-400" />
              </button>
              
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors duration-200">
                <span className="font-medium text-gray-900">System Settings</span>
                <AlertCircle className="w-5 h-5 text-gray-400" />
              </button>
              
              <button className="w-full flex items-center justify-between p-3 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors duration-200 text-blue-700">
                <span className="font-medium">Send Announcements</span>
                <TrendingUp className="w-5 h-5 text-blue-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              View All Activity
            </button>
          </div>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-xl">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  {activity.type === 'user_registered' && <Users className="w-5 h-5 text-white" />}
                  {activity.type === 'appointment_booked' && <Calendar className="w-5 h-5 text-white" />}
                  {activity.type === 'barber_joined' && <TrendingUp className="w-5 h-5 text-white" />}
                  {activity.type === 'review_posted' && <CheckCircle className="w-5 h-5 text-white" />}
                </div>
                <div className="flex-1">
                  <p className="text-gray-900 font-medium">{activity.description}</p>
                  <p className="text-sm text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;