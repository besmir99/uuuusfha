import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Home, 
  Calendar, 
  User, 
  Settings, 
  LogOut, 
  Scissors, 
  Users,
  BarChart3,
  MapPin,
  Star,
  Bell,
  TrendingUp,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Clock,
  Store
} from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onViewChange }) => {
  const { user, logout } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const getNavItems = () => {
    switch (user?.role) {
      case 'client':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: Home },
          { id: 'book', label: 'Book Service', icon: Calendar },
          { id: 'barbers', label: 'Find Barbers', icon: MapPin },
          { id: 'appointments', label: 'My Appointments', icon: Calendar },
          { id: 'reviews', label: 'My Reviews', icon: Star },
          { id: 'notifications', label: 'Notifications', icon: Bell },
          { id: 'profile', label: 'Profile', icon: User },
        ];
      case 'barber':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: Home },
          { id: 'salon-manager', label: 'Salon Manager', icon: Store },
          { id: 'appointments', label: 'Calendar', icon: Calendar },
          { id: 'services', label: 'My Services', icon: Scissors },
          { id: 'reviews', label: 'Reviews', icon: Star },
          { id: 'analytics', label: 'Analytics', icon: TrendingUp },
          { id: 'notifications', label: 'Notifications', icon: Bell },
          { id: 'profile', label: 'Profile', icon: User },
        ];
      case 'admin':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: Home },
          { id: 'users', label: 'Users', icon: Users },
          { id: 'appointments', label: 'All Appointments', icon: Calendar },
          { id: 'barbers', label: 'Barber Management', icon: Scissors },
          { id: 'schedule', label: 'Schedule Manager', icon: Clock },
          { id: 'analytics', label: 'Analytics', icon: BarChart3 },
          { id: 'reviews', label: 'Review Moderation', icon: Star },
          { id: 'notifications', label: 'System Alerts', icon: Bell },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileOpen(true)}
        className="lg:hidden fixed top-4 left-4 z-50 p-3 bg-slate-800 text-white rounded-xl shadow-lg hover:bg-slate-700 transition-all duration-300"
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <nav className={`
        fixed lg:relative inset-y-0 left-0 z-50 
        bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 
        border-r border-slate-700 shadow-2xl
        transition-all duration-500 ease-in-out transform
        ${isCollapsed ? 'w-20' : 'w-80'}
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        min-h-screen overflow-hidden
      `}>
        {/* Animated Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-purple-500/20 animate-pulse"></div>
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 animate-pulse"></div>
        </div>

        <div className="relative z-10 flex flex-col h-full">
          {/* Header Section */}
          <div className="p-6 border-b border-slate-700/50">
            <div className="flex items-center justify-between">
              {/* Logo and Brand */}
              <div className={`flex items-center space-x-3 transition-all duration-500 ${isCollapsed ? 'justify-center' : ''}`}>
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg transform transition-transform duration-300 hover:scale-110 hover:rotate-3">
                    <Scissors className="w-6 h-6 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-slate-800 animate-pulse"></div>
                </div>
                {!isCollapsed && (
                  <div className="transition-all duration-500 transform">
                    <h1 className="text-xl font-bold text-white bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                      BarberBook
                    </h1>
                    <p className="text-sm text-slate-400 capitalize font-medium">{user?.role} Portal</p>
                  </div>
                )}
              </div>

              {/* Collapse Toggle - Desktop Only */}
              <button
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="hidden lg:flex items-center justify-center w-8 h-8 bg-slate-700 hover:bg-slate-600 rounded-lg transition-all duration-300 transform hover:scale-110"
              >
                {isCollapsed ? (
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                ) : (
                  <ChevronLeft className="w-4 h-4 text-slate-300" />
                )}
              </button>

              {/* Mobile Close Button */}
              <button
                onClick={() => setIsMobileOpen(false)}
                className="lg:hidden w-8 h-8 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition-all duration-300"
              >
                <X className="w-4 h-4 text-slate-300" />
              </button>
            </div>

            {/* Welcome Message */}
            {!isCollapsed && (
              <div className="mt-4 p-4 bg-gradient-to-r from-slate-800/50 to-slate-700/50 rounded-xl border border-slate-600/30 backdrop-blur-sm">
                <p className="text-slate-300 text-sm font-medium">
                  {getGreeting()}, <span className="text-blue-400 font-semibold">{user?.name?.split(' ')[0]}</span>
                </p>
                <p className="text-slate-400 text-xs mt-1">Ready to manage your appointments?</p>
              </div>
            )}
          </div>

          {/* Navigation Items */}
          <div className="flex-1 p-4 space-y-2 overflow-y-auto">
            {navItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id);
                    setIsMobileOpen(false);
                  }}
                  className={`
                    group relative w-full flex items-center space-x-4 px-4 py-4 rounded-2xl 
                    transition-all duration-300 transform hover:scale-105
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/25' 
                      : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
                    }
                    ${isCollapsed ? 'justify-center px-2' : ''}
                  `}
                  style={{
                    animationDelay: `${index * 50}ms`,
                    animation: 'slideInLeft 0.5s ease-out forwards'
                  }}
                >
                  {/* Active Indicator */}
                  {isActive && (
                    <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-8 bg-white rounded-r-full"></div>
                  )}
                  
                  {/* Icon */}
                  <div className={`
                    flex items-center justify-center w-6 h-6 transition-all duration-300
                    ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'}
                  `}>
                    <Icon className="w-5 h-5" />
                  </div>
                  
                  {/* Label */}
                  {!isCollapsed && (
                    <span className="font-semibold text-sm transition-all duration-300">
                      {item.label}
                    </span>
                  )}

                  {/* Hover Effect */}
                  <div className={`
                    absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 
                    bg-gradient-to-r from-blue-500/10 to-purple-500/10 
                    transition-opacity duration-300 pointer-events-none
                    ${isActive ? 'opacity-0' : ''}
                  `}></div>

                  {/* Tooltip for Collapsed State */}
                  {isCollapsed && (
                    <div className="absolute left-full ml-4 px-3 py-2 bg-slate-800 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap z-50 border border-slate-600">
                      {item.label}
                      <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-1 w-2 h-2 bg-slate-800 rotate-45 border-l border-b border-slate-600"></div>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* User Profile Section */}
          <div className="p-4 border-t border-slate-700/50">
            {!isCollapsed ? (
              <div className="space-y-4">
                {/* User Info Card */}
                <div className="p-4 bg-gradient-to-r from-slate-800/50 to-slate-700/50 rounded-2xl border border-slate-600/30 backdrop-blur-sm">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white font-bold text-lg">
                          {user?.name.charAt(0)}
                        </span>
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-slate-800"></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white truncate">
                        {user?.name}
                      </p>
                      <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-400 font-medium">Online</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Logout Button */}
                <button
                  onClick={logout}
                  className="w-full flex items-center space-x-3 px-4 py-3 text-red-400 hover:bg-red-900/20 rounded-2xl transition-all duration-300 transform hover:scale-105 group"
                >
                  <LogOut className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                  <span className="font-semibold text-sm">Sign Out</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Collapsed User Avatar */}
                <div className="flex justify-center">
                  <div className="relative">
                    <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
                      <span className="text-white font-bold text-sm">
                        {user?.name.charAt(0)}
                      </span>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-slate-800"></div>
                  </div>
                </div>

                {/* Collapsed Logout */}
                <button
                  onClick={logout}
                  className="w-full flex justify-center p-3 text-red-400 hover:bg-red-900/20 rounded-xl transition-all duration-300 transform hover:scale-110 group"
                >
                  <LogOut className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-slate-900 to-transparent pointer-events-none"></div>
        <div className="absolute top-20 right-0 w-1 h-20 bg-gradient-to-b from-blue-500 to-purple-500 opacity-50 animate-pulse"></div>
      </nav>

      <style jsx>{`
        @keyframes slideInLeft {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </>
  );
};

export default Navigation;