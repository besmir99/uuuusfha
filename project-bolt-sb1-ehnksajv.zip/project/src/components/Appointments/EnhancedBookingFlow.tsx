import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, CreditCard, Check, ArrowLeft, Users, AlertCircle } from 'lucide-react';
import { mockBarbers, getBarberServicesByGender } from '../../data/mockData';
import { mockSalons, getBarbersBySalon, getServicesByGenderAndSalon } from '../../data/salonData';
import { Barber, Service } from '../../types';
import { Salon } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { ScheduleManager } from '../../utils/scheduleManager';
import { AvailableSlot } from '../../types/scheduling';
import TimeSlotPicker from '../Calendar/TimeSlotPicker';

interface EnhancedBookingFlowProps {
  onBookingComplete?: () => void;
  onCancel?: () => void;
  selectedCity?: string;
  mode: 'salon' | 'individual';
}

const EnhancedBookingFlow: React.FC<EnhancedBookingFlowProps> = ({ 
  onBookingComplete, 
  onCancel, 
  selectedCity,
  mode 
}) => {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSalon, setSelectedSalon] = useState<Salon | null>(null);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState<AvailableSlot | null>(null);
  const [bookingNotes, setBookingNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reservationId, setReservationId] = useState<string | null>(null);

  const steps = mode === 'salon' 
    ? [
        { number: 1, title: 'Choose Salon', icon: Users },
        { number: 2, title: 'Select Barber', icon: User },
        { number: 3, title: 'Pick Service', icon: CreditCard },
        { number: 4, title: 'Date & Time', icon: Calendar },
        { number: 5, title: 'Confirm', icon: Check },
      ]
    : [
        { number: 1, title: 'Choose Barber', icon: User },
        { number: 2, title: 'Select Service', icon: CreditCard },
        { number: 3, title: 'Date & Time', icon: Calendar },
        { number: 4, title: 'Confirm', icon: Check },
      ];

  const nextWeekDates = Array.from({ length: 14 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date;
  });

  // Auto-reserve slot when selected
  useEffect(() => {
    if (selectedSlot && selectedBarber && selectedService && selectedDate && !reservationId) {
      handleSlotReservation();
    }
  }, [selectedSlot, selectedBarber, selectedService, selectedDate]);

  const handleSlotReservation = async () => {
    if (!selectedSlot || !selectedBarber || !selectedService || !user) return;

    try {
      const result = await ScheduleManager.reserveSlot(
        selectedBarber.id,
        selectedDate,
        selectedSlot.start_time,
        selectedSlot.end_time,
        user.id,
        selectedService.id
      );

      if (result.success && result.reservation_id) {
        setReservationId(result.reservation_id);
        // Show user that slot is reserved
        console.log('Slot reserved:', result.message);
      } else {
        alert(result.message);
        setSelectedSlot(null);
      }
    } catch (error) {
      console.error('Error reserving slot:', error);
      alert('Failed to reserve time slot. Please try again.');
      setSelectedSlot(null);
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleConfirmBooking = async () => {
    if (!selectedBarber || !selectedService || !selectedDate || !selectedSlot || !reservationId) {
      alert('Please complete all booking details');
      return;
    }

    setIsSubmitting(true);

    try {
      // Calculate end time
      const startTime = selectedSlot.start_time;
      const endTime = calculateEndTime(startTime, selectedService.duration);

      // Confirm the reservation as an appointment
      const result = await ScheduleManager.confirmReservation(reservationId, {
        salon_id: selectedSalon?.id || 'individual',
        appointment_date: selectedDate,
        appointment_time: startTime,
        end_time: endTime,
        total_price: selectedService.price,
        notes: bookingNotes
      });

      if (result.success) {
        // Store in localStorage for demo
        const existingBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
        const newBooking = {
          id: result.appointment_id,
          clientId: user.id,
          salonId: selectedSalon?.id || 'individual',
          barberId: selectedBarber.id,
          serviceId: selectedService.id,
          date: selectedDate,
          time: startTime,
          endTime: endTime,
          status: 'pending',
          notes: bookingNotes,
          createdAt: new Date().toISOString(),
        };
        existingBookings.push(newBooking);
        localStorage.setItem('userBookings', JSON.stringify(existingBookings));

        alert(`🎉 Booking confirmed! 

Your appointment ${selectedSalon ? `at ${selectedSalon.name}` : ''} with ${selectedBarber.name} for ${selectedService.title} has been scheduled for ${new Date(selectedDate).toLocaleDateString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })} at ${startTime}.

The ${selectedSalon ? 'salon' : 'barber'} will review your request and confirm the appointment.`);

        // Reset form
        resetForm();
        
        if (onBookingComplete) {
          onBookingComplete();
        }
      } else {
        alert(result.message);
      }
    } catch (error) {
      alert('Sorry, there was an error processing your booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setCurrentStep(1);
    setSelectedSalon(null);
    setSelectedBarber(null);
    setSelectedService(null);
    setSelectedDate('');
    setSelectedSlot(null);
    setBookingNotes('');
    setReservationId(null);
  };

  const calculateEndTime = (startTime: string, durationMinutes: number): string => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60);
    const endMins = totalMinutes % 60;
    return `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
  };

  const canProceed = () => {
    if (mode === 'salon') {
      switch (currentStep) {
        case 1: return selectedSalon !== null;
        case 2: return selectedBarber !== null;
        case 3: return selectedService !== null;
        case 4: return selectedDate !== '' && selectedSlot !== null;
        case 5: return true;
        default: return false;
      }
    } else {
      switch (currentStep) {
        case 1: return selectedBarber !== null;
        case 2: return selectedService !== null;
        case 3: return selectedDate !== '' && selectedSlot !== null;
        case 4: return true;
        default: return false;
      }
    }
  };

  const renderStepContent = () => {
    if (mode === 'salon') {
      switch (currentStep) {
        case 1:
          return renderSalonSelection();
        case 2:
          return renderBarberSelection();
        case 3:
          return renderServiceSelection();
        case 4:
          return renderDateTimeSelection();
        case 5:
          return renderConfirmation();
        default:
          return null;
      }
    } else {
      switch (currentStep) {
        case 1:
          return renderIndividualBarberSelection();
        case 2:
          return renderServiceSelection();
        case 3:
          return renderDateTimeSelection();
        case 4:
          return renderConfirmation();
        default:
          return null;
      }
    }
  };

  const renderSalonSelection = () => {
    const filteredSalons = selectedCity 
      ? mockSalons.filter(salon => salon.city.toLowerCase() === selectedCity.toLowerCase())
      : mockSalons;

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Choose Your Salon</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredSalons.map((salon) => (
            <div
              key={salon.id}
              onClick={() => setSelectedSalon(salon)}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 ${
                selectedSalon?.id === salon.id
                  ? 'border-blue-500 bg-blue-50 shadow-lg'
                  : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
              }`}
            >
              <h3 className="font-semibold text-gray-900 text-lg mb-2">{salon.name}</h3>
              <p className="text-gray-600 text-sm mb-3">{salon.description}</p>
              <p className="text-sm text-gray-500 mb-3">📍 {salon.address}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-600 font-medium">
                  {getBarbersBySalon(salon.id).length} barbers available
                </span>
                {selectedSalon?.id === salon.id && (
                  <Check className="w-5 h-5 text-blue-600" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderBarberSelection = () => {
    if (!selectedSalon) return null;
    
    const availableBarbers = getBarbersBySalon(selectedSalon.id);

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Select Your Barber at {selectedSalon.name}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {availableBarbers.map((barber) => (
            <div
              key={barber.id}
              onClick={() => setSelectedBarber(barber)}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 ${
                selectedBarber?.id === barber.id
                  ? 'border-blue-500 bg-blue-50 shadow-lg'
                  : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
              }`}
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">{barber.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{barber.name}</h3>
                  <p className="text-sm text-gray-600">{barber.experience} years experience</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-3">{barber.bio}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-600 font-medium">
                  Rating: {barber.rating} ⭐
                </span>
                {selectedBarber?.id === barber.id && (
                  <Check className="w-5 h-5 text-blue-600" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderIndividualBarberSelection = () => {
    const filteredBarbers = mockBarbers.filter(barber => {
      if (!user?.gender) return true;
      const availableServices = getBarberServicesByGender(barber.id, user.gender);
      return availableServices.length > 0;
    });

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Choose Your Barber</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredBarbers.map((barber) => (
            <div
              key={barber.id}
              onClick={() => setSelectedBarber(barber)}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 ${
                selectedBarber?.id === barber.id
                  ? 'border-blue-500 bg-blue-50 shadow-lg'
                  : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
              }`}
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">{barber.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{barber.name}</h3>
                  <p className="text-sm text-gray-600">⭐ {barber.rating} ({barber.totalReviews} reviews)</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-3">{barber.bio}</p>
              <p className="text-sm text-gray-500 mb-3">📍 {barber.location}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-600 font-medium">
                  {getBarberServicesByGender(barber.id, user?.gender || 'other').length} services available
                </span>
                {selectedBarber?.id === barber.id && (
                  <Check className="w-5 h-5 text-blue-600" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderServiceSelection = () => {
    if (!selectedBarber) return null;

    const availableServices = mode === 'salon' && selectedSalon
      ? getServicesByGenderAndSalon(selectedSalon.id, user?.gender || 'other')
          .filter(service => selectedBarber.availableServices?.includes(service.id))
      : getBarberServicesByGender(selectedBarber.id, user?.gender || 'other');

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Select a Service</h2>
        <div className="space-y-4">
          {availableServices.map((service) => (
            <div
              key={service.id}
              onClick={() => setSelectedService(service)}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 ${
                selectedService?.id === service.id
                  ? 'border-blue-500 bg-blue-50 shadow-lg'
                  : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-lg">{service.title}</h3>
                  <p className="text-gray-600 mt-2">{service.description}</p>
                  <div className="flex items-center space-x-4 mt-3">
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full">
                      {service.category}
                    </span>
                    <span className="flex items-center text-sm text-gray-500">
                      <Clock className="w-4 h-4 mr-1" />
                      {service.duration} min
                    </span>
                  </div>
                </div>
                <div className="text-right ml-6">
                  <p className="text-2xl font-bold text-gray-900">€{service.price}</p>
                  {selectedService?.id === service.id && (
                    <Check className="w-5 h-5 text-blue-600 mt-2" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderDateTimeSelection = () => {
    if (!selectedBarber || !selectedService) return null;

    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Pick Date & Time</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Date Selection */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Select Date</h3>
            <div className="space-y-2">
              {nextWeekDates.map((date) => {
                const dateStr = date.toISOString().split('T')[0];
                const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
                const dayMonth = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                
                return (
                  <button
                    key={dateStr}
                    onClick={() => {
                      setSelectedDate(dateStr);
                      setSelectedSlot(null); // Reset slot when date changes
                      setReservationId(null); // Reset reservation
                    }}
                    className={`w-full p-3 border-2 rounded-xl text-left transition-all duration-200 ${
                      selectedDate === dateStr
                        ? 'border-blue-500 bg-blue-50 shadow-lg'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium text-gray-900">{dayName}</p>
                        <p className="text-sm text-gray-600">{dayMonth}</p>
                      </div>
                      {selectedDate === dateStr && (
                        <Check className="w-4 h-4 text-blue-600" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slot Selection */}
          <div className="lg:col-span-2">
            {selectedDate ? (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900">Available Times</h3>
                  {reservationId && (
                    <div className="flex items-center space-x-2 text-sm text-green-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>Slot reserved for 15 minutes</span>
                    </div>
                  )}
                </div>
                <TimeSlotPicker
                  barberId={selectedBarber.id}
                  selectedDate={selectedDate}
                  serviceDuration={selectedService.duration}
                  onSlotSelect={setSelectedSlot}
                  selectedSlot={selectedSlot}
                  clientGender={user?.gender}
                />
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Please select a date first</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderConfirmation = () => {
    return (
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Confirm Your Booking</h2>
        
        <div className="bg-gray-50 rounded-xl p-6 mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Booking Summary</h3>
          
          <div className="space-y-3">
            {selectedSalon && (
              <div className="flex justify-between">
                <span className="text-gray-600">Salon:</span>
                <span className="font-medium text-gray-900">{selectedSalon.name}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-600">Barber:</span>
              <span className="font-medium text-gray-900">{selectedBarber?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Service:</span>
              <span className="font-medium text-gray-900">{selectedService?.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Date:</span>
              <span className="font-medium text-gray-900">
                {selectedDate && new Date(selectedDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Time:</span>
              <span className="font-medium text-gray-900">
                {selectedSlot?.start_time} - {selectedSlot?.end_time}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duration:</span>
              <span className="font-medium text-gray-900">{selectedService?.duration} minutes</span>
            </div>
            <div className="border-t border-gray-200 pt-3 mt-3">
              <div className="flex justify-between">
                <span className="text-lg font-semibold text-gray-900">Total:</span>
                <span className="text-lg font-bold text-gray-900">€{selectedService?.price}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Special Notes (Optional)
          </label>
          <textarea
            value={bookingNotes}
            onChange={(e) => setBookingNotes(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Any special requests or notes..."
          />
        </div>

        {reservationId && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <div className="flex items-start space-x-3">
              <Check className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Time Slot Reserved</h4>
                <p className="text-sm text-green-700">
                  Your selected time slot is temporarily reserved. Complete your booking to confirm the appointment.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="bg-blue-50 rounded-xl p-6 mb-6">
          <h4 className="font-semibold text-blue-900 mb-2">Booking Policy</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Cancellations must be made at least 3 hours in advance</li>
            <li>• Late arrivals may result in shortened service time</li>
            <li>• Payment is due at the time of service</li>
            <li>• Your booking will be confirmed by the {selectedSalon ? 'salon' : 'barber'}</li>
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          {onCancel && (
            <button
              onClick={onCancel}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Book Appointment</h1>
            <p className="text-gray-600 mt-1">
              {mode === 'salon' ? 'Book at a professional salon' : 'Book with an individual barber'}
            </p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = currentStep === step.number;
            const isCompleted = currentStep > step.number;
            
            return (
              <div key={step.number} className="flex items-center">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-200 ${
                  isActive ? 'border-blue-500 bg-blue-500 text-white scale-110' :
                  isCompleted ? 'border-green-500 bg-green-500 text-white' :
                  'border-gray-300 bg-white text-gray-500'
                }`}>
                  {isCompleted ? <Check className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                </div>
                <div className="ml-3">
                  <p className={`text-sm font-medium transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    Step {step.number}
                  </p>
                  <p className={`text-xs transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-4 transition-colors duration-500 ${
                    isCompleted ? 'bg-green-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        {renderStepContent()}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t border-gray-200 mt-8">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            Back
          </button>
          
          {currentStep < steps.length ? (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleConfirmBooking}
              disabled={isSubmitting || !canProceed() || !reservationId}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl hover:from-green-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Check className="w-5 h-5" />
                  <span>Confirm Booking</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnhancedBookingFlow;