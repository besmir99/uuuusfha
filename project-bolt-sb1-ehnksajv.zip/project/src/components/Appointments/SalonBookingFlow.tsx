import React, { useState } from 'react';
import { Calendar, Clock, User, CreditCard, Check, ArrowLeft, Users, MapPin, Star, Phone } from 'lucide-react';
import { 
  mockSalons, 
  getBarbersBySalon, 
  getServicesByGenderAndSalon, 
  getAvailableBarbers,
  getSalonById,
  getBarberById,
  getServiceById
} from '../../data/salonData';
import { Salon, Barber, Service } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface SalonBookingFlowProps {
  onBookingComplete?: () => void;
  onCancel?: () => void;
  selectedCity?: string;
}

const SalonBookingFlow: React.FC<SalonBookingFlowProps> = ({ 
  onBookingComplete, 
  onCancel, 
  selectedCity 
}) => {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSalon, setSelectedSalon] = useState<Salon | null>(null);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [bookingNotes, setBookingNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const steps = [
    { number: 1, title: 'Choose Salon', icon: MapPin },
    { number: 2, title: 'Select Barber', icon: User },
    { number: 3, title: 'Pick Service', icon: CreditCard },
    { number: 4, title: 'Date & Time', icon: Calendar },
    { number: 5, title: 'Confirm', icon: Check },
  ];

  const availableTimes = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  const nextWeekDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date;
  });

  // Filter salons by city if provided
  const getFilteredSalons = () => {
    if (selectedCity) {
      return mockSalons.filter(salon => 
        salon.city.toLowerCase() === selectedCity.toLowerCase() && salon.isActive
      );
    }
    return mockSalons.filter(salon => salon.isActive);
  };

  const filteredSalons = getFilteredSalons();

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleConfirmBooking = async () => {
    if (!selectedSalon || !selectedBarber || !selectedService || !selectedDate || !selectedTime) {
      alert('Please complete all booking details');
      return;
    }

    setIsSubmitting(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));

      const newBooking = {
        id: Date.now().toString(),
        clientId: user?.id || '',
        salonId: selectedSalon.id,
        barberId: selectedBarber.id,
        serviceId: selectedService.id,
        date: selectedDate,
        time: selectedTime,
        status: 'pending' as const,
        notes: bookingNotes,
        createdAt: new Date().toISOString(),
      };

      const existingBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
      existingBookings.push(newBooking);
      localStorage.setItem('userBookings', JSON.stringify(existingBookings));

      alert(`🎉 Booking confirmed! 

Your appointment at ${selectedSalon.name} with ${selectedBarber.name} for ${selectedService.title} has been scheduled for ${new Date(selectedDate).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      })} at ${selectedTime}.

The salon will review your request and confirm the appointment.`);

      // Reset form
      setCurrentStep(1);
      setSelectedSalon(null);
      setSelectedBarber(null);
      setSelectedService(null);
      setSelectedDate('');
      setSelectedTime('');
      setBookingNotes('');
      
      if (onBookingComplete) {
        onBookingComplete();
      }

    } catch (error) {
      alert('Sorry, there was an error processing your booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1: return selectedSalon !== null;
      case 2: return selectedBarber !== null;
      case 3: return selectedService !== null;
      case 4: return selectedDate !== '' && selectedTime !== '';
      case 5: return true;
      default: return false;
    }
  };

  const getGenderIcon = (gender: 'male' | 'female' | 'other') => {
    switch (gender) {
      case 'male': return '👨';
      case 'female': return '👩';
      default: return '👤';
    }
  };

  const getServiceIcon = (targetGender: 'male' | 'female' | 'unisex') => {
    switch (targetGender) {
      case 'male': return '✂️';
      case 'female': return '💇‍♀️';
      case 'unisex': return '💆';
      default: return '✨';
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          {onCancel && (
            <button
              onClick={onCancel}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Book Appointment</h1>
            <p className="text-gray-600 mt-1">
              Find the perfect salon and barber for your needs
              {selectedCity && (
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-sm rounded-full">
                  📍 {selectedCity}
                </span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = currentStep === step.number;
            const isCompleted = currentStep > step.number;
            
            return (
              <div key={step.number} className="flex items-center">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-200 ${
                  isActive ? 'border-blue-500 bg-blue-500 text-white scale-110' :
                  isCompleted ? 'border-green-500 bg-green-500 text-white' :
                  'border-gray-300 bg-white text-gray-500'
                }`}>
                  {isCompleted ? <Check className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                </div>
                <div className="ml-3">
                  <p className={`text-sm font-medium transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    Step {step.number}
                  </p>
                  <p className={`text-xs transition-colors duration-200 ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-4 transition-colors duration-500 ${
                    isCompleted ? 'bg-green-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        {/* Step 1: Choose Salon */}
        {currentStep === 1 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Choose Your Salon
              {selectedCity && (
                <span className="text-lg font-normal text-gray-600 ml-2">
                  in {selectedCity}
                </span>
              )}
            </h2>
            
            {filteredSalons.length === 0 ? (
              <div className="text-center py-12">
                <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No salons available</h3>
                <p className="text-gray-600">
                  {selectedCity 
                    ? `No salons found in ${selectedCity}. Try selecting a different city.`
                    : 'No salons currently available. Please try again later.'
                  }
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredSalons.map((salon) => (
                  <div
                    key={salon.id}
                    onClick={() => setSelectedSalon(salon)}
                    className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                      selectedSalon?.id === salon.id
                        ? 'border-blue-500 bg-blue-50 shadow-lg'
                        : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                    }`}
                  >
                    <div className="flex items-start space-x-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          {salon.name.charAt(0)}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 text-lg">{salon.name}</h3>
                        <div className="flex items-center space-x-1 mt-1">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < Math.floor(salon.rating) 
                                    ? 'text-yellow-400 fill-current' 
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">
                            {salon.rating} ({salon.totalReviews} reviews)
                          </span>
                        </div>
                        <div className="flex items-center space-x-1 mt-1">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">{salon.address}</span>
                        </div>
                        <div className="flex items-center space-x-1 mt-1">
                          <Phone className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">{salon.phone}</span>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 text-sm mb-4">{salon.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {salon.amenities.slice(0, 4).map((amenity) => (
                        <span
                          key={amenity}
                          className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                        >
                          {amenity}
                        </span>
                      ))}
                      {salon.amenities.length > 4 && (
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                          +{salon.amenities.length - 4} more
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-blue-600 font-medium">
                        {getBarbersBySalon(salon.id).length} barbers available
                      </span>
                      {selectedSalon?.id === salon.id && (
                        <div className="flex items-center space-x-2 text-blue-600">
                          <Check className="w-4 h-4" />
                          <span className="text-sm font-medium">Selected</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Step 2: Select Barber */}
        {currentStep === 2 && selectedSalon && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Select Your Barber
              <span className="text-lg font-normal text-gray-600 ml-2">
                at {selectedSalon.name}
              </span>
            </h2>
            
            {(() => {
              const availableBarbers = getBarbersBySalon(selectedSalon.id);
              
              if (availableBarbers.length === 0) {
                return (
                  <div className="text-center py-12">
                    <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No barbers available</h3>
                    <p className="text-gray-600">
                      This salon doesn't have any available barbers at the moment.
                    </p>
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {availableBarbers.map((barber) => (
                    <div
                      key={barber.id}
                      onClick={() => setSelectedBarber(barber)}
                      className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                        selectedBarber?.id === barber.id
                          ? 'border-blue-500 bg-blue-50 shadow-lg'
                          : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                      }`}
                    >
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-lg">
                            {barber.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900 flex items-center space-x-2">
                            <span>{barber.name}</span>
                            <span className="text-lg">{getGenderIcon(barber.gender || 'other')}</span>
                          </h3>
                          <div className="flex items-center space-x-1 mt-1">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-4 h-4 ${
                                    i < Math.floor(barber.rating) 
                                      ? 'text-yellow-400 fill-current' 
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-600">
                              {barber.rating} ({barber.totalReviews} reviews)
                            </span>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            {barber.experience} years experience
                          </p>
                        </div>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-3">{barber.bio}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {barber.specialties.map((specialty) => (
                          <span
                            key={specialty}
                            className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-blue-600 font-medium">
                          {barber.availableServices.length} services available
                        </span>
                        {selectedBarber?.id === barber.id && (
                          <div className="flex items-center space-x-2 text-blue-600">
                            <Check className="w-4 h-4" />
                            <span className="text-sm font-medium">Selected</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        )}

        {/* Step 3: Select Service */}
        {currentStep === 3 && selectedSalon && selectedBarber && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Select a Service
              <span className="text-lg font-normal text-gray-600 ml-2">
                with {selectedBarber.name}
              </span>
            </h2>
            
            {(() => {
              const availableServices = getServicesByGenderAndSalon(selectedSalon.id, user?.gender || 'other')
                .filter(service => selectedBarber.availableServices.includes(service.id));
              
              if (availableServices.length === 0) {
                return (
                  <div className="text-center py-12">
                    <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No services available</h3>
                    <p className="text-gray-600">
                      This barber doesn't offer services matching your preferences.
                    </p>
                  </div>
                );
              }

              return (
                <div className="space-y-4">
                  {availableServices.map((service) => (
                    <div
                      key={service.id}
                      onClick={() => setSelectedService(service)}
                      className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                        selectedService?.id === service.id
                          ? 'border-blue-500 bg-blue-50 shadow-lg'
                          : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 text-lg flex items-center space-x-2">
                            <span>{getServiceIcon(service.targetGender)}</span>
                            <span>{service.title}</span>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              service.targetGender === 'male' ? 'bg-blue-100 text-blue-700' :
                              service.targetGender === 'female' ? 'bg-pink-100 text-pink-700' :
                              'bg-purple-100 text-purple-700'
                            }`}>
                              {service.targetGender === 'unisex' ? 'For Everyone' : `For ${service.targetGender}s`}
                            </span>
                          </h3>
                          <p className="text-gray-600 mt-2">{service.description}</p>
                          <div className="flex items-center space-x-4 mt-3">
                            <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full">
                              {service.category}
                            </span>
                            <span className="flex items-center text-sm text-gray-500">
                              <Clock className="w-4 h-4 mr-1" />
                              {service.duration} min
                            </span>
                            {service.requiredExperience && (
                              <span className="text-sm text-gray-500">
                                Requires {service.requiredExperience}+ years exp.
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right ml-6">
                          <p className="text-2xl font-bold text-gray-900">€{service.price}</p>
                          {selectedService?.id === service.id && (
                            <div className="mt-2 flex items-center space-x-2 text-blue-600">
                              <Check className="w-4 h-4" />
                              <span className="text-sm font-medium">Selected</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        )}

        {/* Step 4: Pick Date & Time */}
        {currentStep === 4 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Pick Date & Time</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="font-semibold text-gray-900 mb-4">Select Date</h3>
                <div className="grid grid-cols-1 gap-3">
                  {nextWeekDates.map((date) => {
                    const dateStr = date.toISOString().split('T')[0];
                    const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
                    const dayMonth = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                    
                    return (
                      <button
                        key={dateStr}
                        onClick={() => setSelectedDate(dateStr)}
                        className={`p-4 border-2 rounded-xl text-left transition-all duration-200 transform hover:scale-105 ${
                          selectedDate === dateStr
                            ? 'border-blue-500 bg-blue-50 shadow-lg'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium text-gray-900">{dayName}</p>
                            <p className="text-sm text-gray-600">{dayMonth}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="text-sm text-green-600">Available</div>
                            {selectedDate === dateStr && (
                              <Check className="w-4 h-4 text-blue-600" />
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-4">Select Time</h3>
                {selectedDate ? (
                  <div className="grid grid-cols-3 gap-3">
                    {availableTimes.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 border-2 rounded-xl text-center transition-all duration-200 transform hover:scale-105 ${
                          selectedTime === time
                            ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-lg'
                            : 'border-gray-200 hover:border-gray-300 text-gray-700'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Please select a date first</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Confirm Booking */}
        {currentStep === 5 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Confirm Your Booking</h2>
            
            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">Booking Summary</h3>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Salon:</span>
                  <span className="font-medium text-gray-900">{selectedSalon?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Address:</span>
                  <span className="font-medium text-gray-900">{selectedSalon?.address}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Barber:</span>
                  <span className="font-medium text-gray-900">{selectedBarber?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service:</span>
                  <span className="font-medium text-gray-900 flex items-center space-x-2">
                    <span>{getServiceIcon(selectedService?.targetGender || 'unisex')}</span>
                    <span>{selectedService?.title}</span>
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date:</span>
                  <span className="font-medium text-gray-900">
                    {selectedDate && new Date(selectedDate).toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time:</span>
                  <span className="font-medium text-gray-900">{selectedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-medium text-gray-900">{selectedService?.duration} minutes</span>
                </div>
                <div className="border-t border-gray-200 pt-3 mt-3">
                  <div className="flex justify-between">
                    <span className="text-lg font-semibold text-gray-900">Total:</span>
                    <span className="text-lg font-bold text-gray-900">€{selectedService?.price}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Special Notes (Optional)
              </label>
              <textarea
                value={bookingNotes}
                onChange={(e) => setBookingNotes(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Any special requests or notes for your barber..."
              />
            </div>

            <div className="bg-blue-50 rounded-xl p-6 mb-6">
              <h4 className="font-semibold text-blue-900 mb-2">Booking Policy</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Cancellations must be made at least 24 hours in advance</li>
                <li>• Late arrivals may result in shortened service time</li>
                <li>• Payment is due at the time of service</li>
                <li>• The salon will confirm this appointment request</li>
              </ul>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t border-gray-200">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            Back
          </button>
          
          {currentStep < 5 ? (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleConfirmBooking}
              disabled={isSubmitting || !canProceed()}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl hover:from-green-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Check className="w-5 h-5" />
                  <span>Confirm Booking</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default SalonBookingFlow;