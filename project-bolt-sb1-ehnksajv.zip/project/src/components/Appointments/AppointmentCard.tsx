import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Phone, AlertCircle, X, Check, Star, Euro } from 'lucide-react';
import { DatabaseAppointment } from '../../types/database';
import { 
  canCancelAppointment, 
  cancelAppointment, 
  formatTimeUntilAppointment,
  getCancellationDeadline,
  getTimeUntilCancellationDeadline,
  isWithinCancellationWindow
} from '../../utils/appointmentUtils';
import { mockBarbers, mockServices } from '../../data/mockData';
import { mockSalons } from '../../data/salonData';

interface AppointmentCardProps {
  appointment: DatabaseAppointment;
  onAppointmentUpdate?: () => void;
  showActions?: boolean;
}

const AppointmentCard: React.FC<AppointmentCardProps> = ({ 
  appointment, 
  onAppointmentUpdate,
  showActions = true 
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancellationReason, setCancellationReason] = useState('');
  const [isHovered, setIsHovered] = useState(false);

  // Get related data (in real app, this would come from the appointment object with joins)
  const barber = mockBarbers.find(b => b.id === appointment.barber_id);
  const service = mockServices.find(s => s.id === appointment.service_id);
  const salon = mockSalons.find(s => s.id === appointment.salon_id);

  const cancellationCheck = canCancelAppointment(appointment);
  const appointmentDate = new Date(`${appointment.appointment_date}T${appointment.appointment_time}:00`);
  const cancellationDeadline = getCancellationDeadline(appointment);
  const isWithinWindow = isWithinCancellationWindow(appointment);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'cancelled_by_client':
      case 'cancelled_by_barber':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'no_show':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return '✅';
      case 'pending':
        return '⏳';
      case 'in_progress':
        return '🔄';
      case 'completed':
        return '✨';
      case 'cancelled_by_client':
      case 'cancelled_by_barber':
        return '❌';
      case 'no_show':
        return '👻';
      default:
        return '📅';
    }
  };

  const handleCancelAppointment = async () => {
    setIsLoading(true);
    
    try {
      const result = await cancelAppointment(
        appointment.id, 
        appointment.client_id, 
        cancellationReason || undefined
      );
      
      if (result.success) {
        setShowCancelModal(false);
        setCancellationReason('');
        if (onAppointmentUpdate) {
          onAppointmentUpdate();
        }
        alert(result.message);
      } else {
        alert(result.message);
      }
    } catch (error) {
      alert('Failed to cancel appointment. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div 
        className={`bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transition-all duration-300 transform ${
          isHovered ? 'shadow-xl scale-[1.02] border-blue-200' : 'hover:shadow-lg hover:scale-[1.01]'
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Header with animated gradient background */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg transform transition-transform duration-300 hover:scale-110">
                <span className="text-white font-bold text-lg">
                  {barber?.name.charAt(0) || 'B'}
                </span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md">
                <span className="text-sm">{getStatusIcon(appointment.status)}</span>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 text-lg mb-1">
                {service?.title || 'Service'}
              </h3>
              <p className="text-gray-600 mb-2">
                with <span className="font-semibold text-blue-600">{barber?.name || 'Barber'}</span> at{' '}
                <span className="font-semibold text-purple-600">{salon?.name || 'Salon'}</span>
              </p>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center space-x-1 bg-gray-50 px-3 py-1 rounded-full">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-gray-700">
                    {appointmentDate.toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex items-center space-x-1 bg-gray-50 px-3 py-1 rounded-full">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <span className="font-medium text-gray-700">{appointment.appointment_time}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end space-y-2">
            <span className={`px-4 py-2 text-sm font-semibold rounded-full border shadow-sm ${getStatusColor(appointment.status)}`}>
              {appointment.status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </span>
            <div className="flex items-center space-x-1 text-lg font-bold text-gray-900">
              <Euro className="w-4 h-4" />
              <span>{appointment.total_price}</span>
            </div>
          </div>
        </div>

        {/* Appointment Details with animated cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 transition-all duration-300 hover:shadow-md">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Location</p>
                  <p className="text-sm font-semibold text-gray-900">{salon?.address || 'Address not available'}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                  <Phone className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Contact</p>
                  <p className="text-sm font-semibold text-gray-900">{salon?.phone || 'Phone not available'}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 transition-all duration-300 hover:shadow-md">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                  <Clock className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Duration</p>
                  <p className="text-sm font-semibold text-gray-900">{service?.duration || 0} minutes</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center">
                  <Star className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Barber Rating</p>
                  <p className="text-sm font-semibold text-gray-900">{barber?.rating || 'N/A'} ⭐</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Notes with enhanced styling */}
        {appointment.notes && (
          <div className="mb-6 p-4 bg-gray-50 rounded-xl border border-gray-200">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-gray-600 rounded-lg flex items-center justify-center mt-0.5">
                <span className="text-white text-xs">📝</span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-800 mb-1">Special Notes</p>
                <p className="text-sm text-gray-700">{appointment.notes}</p>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Cancellation Warning */}
        {!cancellationCheck.canCancel && cancellationCheck.hoursUntilAppointment !== undefined && cancellationCheck.hoursUntilAppointment > 0 && appointment.status !== 'completed' && (
          <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-xl">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="font-semibold text-orange-800 mb-1">Cancellation Policy</p>
                <div className="text-sm text-orange-700 mb-2">
                  <p className="mb-1">This appointment can only be cancelled up to 3 hours in advance.</p>
                  <p className="font-medium">
                    Cancellation deadline: {cancellationDeadline.toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                  <p className="text-sm font-medium text-orange-800">
                    {isWithinWindow 
                      ? `Time remaining to cancel: ${getTimeUntilCancellationDeadline(appointment)}`
                      : 'Cancellation deadline has passed'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Show time until appointment for confirmed appointments */}
        {appointment.status === 'confirmed' && cancellationCheck.hoursUntilAppointment !== undefined && cancellationCheck.hoursUntilAppointment > 0 && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="flex items-center space-x-3">
              <Clock className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-semibold text-blue-800">Upcoming Appointment</p>
                <p className="text-sm text-blue-700">
                  Your appointment is in {formatTimeUntilAppointment(cancellationCheck.hoursUntilAppointment)}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Action Buttons */}
        {showActions && (
          <div className="flex space-x-3">
            {appointment.status === 'pending' && (
              <button className="flex-1 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-all duration-300 font-semibold transform hover:scale-105 shadow-md hover:shadow-lg">
                Reschedule
              </button>
            )}
            
            {cancellationCheck.canCancel && (
              <button
                onClick={() => setShowCancelModal(true)}
                className="flex-1 bg-red-500 text-white py-3 rounded-xl hover:bg-red-600 transition-all duration-300 font-semibold transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                Cancel Appointment
              </button>
            )}
            
            {appointment.status === 'completed' && (
              <button className="flex-1 bg-yellow-500 text-white py-3 rounded-xl hover:bg-yellow-600 transition-all duration-300 font-semibold transform hover:scale-105 shadow-md hover:shadow-lg">
                Leave Review
              </button>
            )}
            
            <button className="flex-1 bg-gray-500 text-white py-3 rounded-xl hover:bg-gray-600 transition-all duration-300 font-semibold transform hover:scale-105 shadow-md hover:shadow-lg">
              View Details
            </button>
          </div>
        )}
      </div>

      {/* Enhanced Cancellation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl transform animate-slideInUp">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-100 bg-gray-50 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center">
                    <AlertCircle className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">Cancel Appointment</h3>
                </div>
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-full transition-all duration-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Modal Content */}
            <div className="p-6">
              <div className="mb-6">
                <p className="text-gray-600 mb-4">
                  Are you sure you want to cancel your appointment with{' '}
                  <span className="font-semibold text-blue-600">{barber?.name}</span> on{' '}
                  <span className="font-semibold">
                    {appointmentDate.toLocaleDateString('en-US', {
                      weekday: 'long',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </span>{' '}
                  at <span className="font-semibold">{appointment.appointment_time}</span>?
                </p>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Reason for cancellation (optional)
                  </label>
                  <textarea
                    value={cancellationReason}
                    onChange={(e) => setCancellationReason(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    placeholder="Let us know why you're cancelling..."
                  />
                </div>
                
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-yellow-500 rounded-lg flex items-center justify-center">
                      <span className="text-white text-xs">⚠️</span>
                    </div>
                    <div>
                      <p className="text-sm text-yellow-800">
                        <strong>Note:</strong> Cancelling within 3 hours of your appointment may result in a cancellation fee.
                      </p>
                      <p className="text-sm text-yellow-700 mt-2">
                        <strong>Cancellation deadline:</strong> {cancellationDeadline.toLocaleDateString('en-US', {
                          weekday: 'long',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowCancelModal(false)}
                  disabled={isLoading}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all duration-200 font-semibold"
                >
                  Keep Appointment
                </button>
                <button
                  onClick={handleCancelAppointment}
                  disabled={isLoading}
                  className="flex-1 px-4 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-200 disabled:opacity-50 flex items-center justify-center space-x-2 font-semibold shadow-md hover:shadow-lg"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Cancelling...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Cancel Appointment</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        
        .animate-slideInUp {
          animation: slideInUp 0.3s ease-out;
        }
      `}</style>
    </>
  );
};

export default AppointmentCard;