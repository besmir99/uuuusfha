export interface KosovoCity {
  id: string;
  name: string;
  nameAlbanian: string;
  region: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  population: number;
  barberShops: BarberShop[];
}

export interface BarberShop {
  id: string;
  name: string;
  address: string;
  rating: number;
  totalReviews: number;
  priceRange: string;
  specialties: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
}

export const kosovoCities: KosovoCity[] = [
  {
    id: 'prishtina',
    name: 'Prishtina',
    nameAlbanian: 'Prishtinë',
    region: 'Central',
    coordinates: { lat: 42.6629, lng: 21.1655 },
    population: 200000,
    barberShops: [
      {
        id: 'elite-cuts-prishtina',
        name: 'Elite Cuts',
        address: 'Rruga Bill Klinton, Prishtinë',
        rating: 4.8,
        totalReviews: 156,
        priceRange: '€15-35',
        specialties: ['Modern Cuts', 'Beard Styling', 'Hair Washing'],
        coordinates: { lat: 42.6629, lng: 21.1655 }
      },
      {
        id: 'barberzone-prishtina',
        name: 'BarberZone',
        address: 'Rruga Nëna Terezë, Prishtinë',
        rating: 4.7,
        totalReviews: 203,
        priceRange: '€12-30',
        specialties: ['Classic Cuts', 'Fade Cuts', 'Mustache Trim'],
        coordinates: { lat: 42.6640, lng: 21.1670 }
      },
      {
        id: 'prishtina-fade',
        name: 'Prishtina Fade',
        address: 'Rruga Agim Ramadani, Prishtinë',
        rating: 4.9,
        totalReviews: 89,
        priceRange: '€18-40',
        specialties: ['Fade Cuts', 'Skin Fade', 'Beard Design'],
        coordinates: { lat: 42.6650, lng: 21.1640 }
      },
      {
        id: 'urban-blades-prishtina',
        name: 'Urban Blades',
        address: 'Rruga Fehmi Agani, Prishtinë',
        rating: 4.6,
        totalReviews: 134,
        priceRange: '€20-45',
        specialties: ['Urban Styles', 'Hair Coloring', 'Styling'],
        coordinates: { lat: 42.6610, lng: 21.1680 }
      }
    ]
  },
  {
    id: 'prizren',
    name: 'Prizren',
    nameAlbanian: 'Prizren',
    region: 'Southern',
    coordinates: { lat: 42.2139, lng: 20.7397 },
    population: 85000,
    barberShops: [
      {
        id: 'royal-trim-prizren',
        name: 'Royal Trim',
        address: 'Rruga Shadervan, Prizren',
        rating: 4.8,
        totalReviews: 112,
        priceRange: '€10-25',
        specialties: ['Royal Treatment', 'Traditional Cuts', 'Hot Towel'],
        coordinates: { lat: 42.2139, lng: 20.7397 }
      },
      {
        id: 'style-lab-prizren',
        name: 'Style Lab',
        address: 'Rruga Remzi Ademaj, Prizren',
        rating: 4.7,
        totalReviews: 98,
        priceRange: '€15-30',
        specialties: ['Experimental Styles', 'Color Lab', 'Texture Work'],
        coordinates: { lat: 42.2150, lng: 20.7410 }
      },
      {
        id: 'fade-house-prizren',
        name: 'The Fade House',
        address: 'Rruga Lidhja e Prizrenit, Prizren',
        rating: 4.9,
        totalReviews: 76,
        priceRange: '€12-28',
        specialties: ['Precision Fades', 'Line-ups', 'Beard Sculpting'],
        coordinates: { lat: 42.2130, lng: 20.7380 }
      }
    ]
  },
  {
    id: 'gjakova',
    name: 'Gjakova',
    nameAlbanian: 'Gjakovë',
    region: 'Western',
    coordinates: { lat: 42.3803, lng: 20.4314 },
    population: 55000,
    barberShops: [
      {
        id: 'sharp-line-gjakova',
        name: 'Sharp Line',
        address: 'Rruga Çarshia e Madhe, Gjakovë',
        rating: 4.6,
        totalReviews: 87,
        priceRange: '€8-22',
        specialties: ['Sharp Lines', 'Precision Cuts', 'Traditional'],
        coordinates: { lat: 42.3803, lng: 20.4314 }
      },
      {
        id: 'gjakova-gents',
        name: 'Gjakova Gents',
        address: 'Rruga Ismail Qemali, Gjakovë',
        rating: 4.5,
        totalReviews: 65,
        priceRange: '€10-25',
        specialties: ['Gentleman Cuts', 'Beard Care', 'Grooming'],
        coordinates: { lat: 42.3820, lng: 20.4330 }
      },
      {
        id: 'barber-club-gjakova',
        name: 'Barber Club',
        address: 'Rruga Emin Duraku, Gjakovë',
        rating: 4.7,
        totalReviews: 93,
        priceRange: '€12-30',
        specialties: ['Club Atmosphere', 'Modern Cuts', 'Social Hub'],
        coordinates: { lat: 42.3790, lng: 20.4300 }
      }
    ]
  },
  {
    id: 'peja',
    name: 'Peja',
    nameAlbanian: 'Pejë',
    region: 'Western',
    coordinates: { lat: 42.6589, lng: 20.2889 },
    population: 48000,
    barberShops: [
      {
        id: 'peja-styles',
        name: 'Peja Styles',
        address: 'Rruga Mbretëresha Teuta, Pejë',
        rating: 4.8,
        totalReviews: 104,
        priceRange: '€10-28',
        specialties: ['Local Styles', 'Mountain Fresh', 'Natural Look'],
        coordinates: { lat: 42.6589, lng: 20.2889 }
      },
      {
        id: 'scissor-kings-peja',
        name: 'Scissor Kings',
        address: 'Rruga Adem Jashari, Pejë',
        rating: 4.9,
        totalReviews: 78,
        priceRange: '€15-35',
        specialties: ['Scissor Mastery', 'Artistic Cuts', 'Premium Service'],
        coordinates: { lat: 42.6600, lng: 20.2900 }
      },
      {
        id: 'mastercut-peja',
        name: 'MasterCut',
        address: 'Rruga Haxhi Zeka, Pejë',
        rating: 4.7,
        totalReviews: 91,
        priceRange: '€12-30',
        specialties: ['Master Techniques', 'Classic & Modern', 'Expert Care'],
        coordinates: { lat: 42.6570, lng: 20.2870 }
      }
    ]
  },
  {
    id: 'mitrovica',
    name: 'Mitrovica',
    nameAlbanian: 'Mitrovicë',
    region: 'Northern',
    coordinates: { lat: 42.8914, lng: 20.8664 },
    population: 40000,
    barberShops: [
      {
        id: 'northside-barbers',
        name: 'NorthSide Barbers',
        address: 'Rruga Mbretër Nikolla, Mitrovicë',
        rating: 4.6,
        totalReviews: 82,
        priceRange: '€8-20',
        specialties: ['North Style', 'Urban Cuts', 'Street Fashion'],
        coordinates: { lat: 42.8914, lng: 20.8664 }
      },
      {
        id: 'fade-master-mitrovica',
        name: 'Fade Master',
        address: 'Rruga Isa Boletini, Mitrovicë',
        rating: 4.8,
        totalReviews: 96,
        priceRange: '€12-25',
        specialties: ['Fade Expertise', 'Gradient Cuts', 'Precision Work'],
        coordinates: { lat: 42.8930, lng: 20.8680 }
      },
      {
        id: 'classic-cuts-mitrovica',
        name: 'Classic Cuts',
        address: 'Rruga Skënderbeu, Mitrovicë',
        rating: 4.5,
        totalReviews: 67,
        priceRange: '€10-22',
        specialties: ['Timeless Classics', 'Traditional Methods', 'Heritage Cuts'],
        coordinates: { lat: 42.8900, lng: 20.8650 }
      }
    ]
  },
  {
    id: 'ferizaj',
    name: 'Ferizaj',
    nameAlbanian: 'Ferizaj',
    region: 'Central',
    coordinates: { lat: 42.3700, lng: 21.1483 },
    population: 42000,
    barberShops: [
      {
        id: 'gentlemans-den-ferizaj',
        name: "Gentleman's Den",
        address: 'Rruga Liria, Ferizaj',
        rating: 4.7,
        totalReviews: 89,
        priceRange: '€12-30',
        specialties: ['Gentleman Service', 'Luxury Experience', 'Premium Grooming'],
        coordinates: { lat: 42.3700, lng: 21.1483 }
      },
      {
        id: 'truestyle-ferizaj',
        name: 'TrueStyle',
        address: 'Rruga Dëshmorët e Kombit, Ferizaj',
        rating: 4.8,
        totalReviews: 103,
        priceRange: '€10-25',
        specialties: ['Authentic Styles', 'Personal Touch', 'True Craftsmanship'],
        coordinates: { lat: 42.3720, lng: 21.1500 }
      },
      {
        id: 'hq-barbers-ferizaj',
        name: 'HQ Barbers',
        address: 'Rruga Fehmi Lladrovci, Ferizaj',
        rating: 4.6,
        totalReviews: 74,
        priceRange: '€15-35',
        specialties: ['Headquarters Quality', 'Professional Standards', 'Elite Service'],
        coordinates: { lat: 42.3680, lng: 21.1460 }
      }
    ]
  },
  {
    id: 'gjilan',
    name: 'Gjilan',
    nameAlbanian: 'Gjilan',
    region: 'Eastern',
    coordinates: { lat: 42.4608, lng: 21.4694 },
    population: 35000,
    barberShops: [
      {
        id: 'gjilan-barber-spot',
        name: 'Gjilan Barber Spot',
        address: 'Rruga Zahir Pajaziti, Gjilan',
        rating: 4.5,
        totalReviews: 68,
        priceRange: '€8-20',
        specialties: ['Local Favorite', 'Community Hub', 'Friendly Service'],
        coordinates: { lat: 42.4608, lng: 21.4694 }
      },
      {
        id: 'razor-pro-gjilan',
        name: 'Razor Pro',
        address: 'Rruga Drita, Gjilan',
        rating: 4.8,
        totalReviews: 85,
        priceRange: '€12-28',
        specialties: ['Razor Expertise', 'Professional Shaves', 'Sharp Precision'],
        coordinates: { lat: 42.4620, lng: 21.4710 }
      },
      {
        id: 'alpha-cuts-gjilan',
        name: 'Alpha Cuts',
        address: 'Rruga Iliria, Gjilan',
        rating: 4.7,
        totalReviews: 92,
        priceRange: '€10-25',
        specialties: ['Alpha Quality', 'Leadership Styles', 'Confidence Cuts'],
        coordinates: { lat: 42.4590, lng: 21.4680 }
      }
    ]
  },
  {
    id: 'vushtrri',
    name: 'Vushtrri',
    nameAlbanian: 'Vushtrri',
    region: 'Northern',
    coordinates: { lat: 42.8231, lng: 20.9675 },
    population: 28000,
    barberShops: [
      {
        id: 'vushtrri-elite',
        name: 'Vushtrri Elite',
        address: 'Rruga Adem Jashari, Vushtrri',
        rating: 4.6,
        totalReviews: 56,
        priceRange: '€8-22',
        specialties: ['Elite Standards', 'Quality Service', 'Local Pride'],
        coordinates: { lat: 42.8231, lng: 20.9675 }
      },
      {
        id: 'modern-cuts-vushtrri',
        name: 'Modern Cuts',
        address: 'Rruga Skënderbeu, Vushtrri',
        rating: 4.7,
        totalReviews: 71,
        priceRange: '€10-25',
        specialties: ['Contemporary Styles', 'Modern Techniques', 'Fresh Looks'],
        coordinates: { lat: 42.8250, lng: 20.9690 }
      }
    ]
  },
  {
    id: 'podujeva',
    name: 'Podujeva',
    nameAlbanian: 'Podujevë',
    region: 'Northern',
    coordinates: { lat: 42.9111, lng: 21.1936 },
    population: 25000,
    barberShops: [
      {
        id: 'podujeva-style',
        name: 'Podujeva Style',
        address: 'Rruga Adem Jashari, Podujevë',
        rating: 4.5,
        totalReviews: 48,
        priceRange: '€8-20',
        specialties: ['Local Style', 'Traditional Cuts', 'Community Service'],
        coordinates: { lat: 42.9111, lng: 21.1936 }
      },
      {
        id: 'fresh-cuts-podujeva',
        name: 'Fresh Cuts',
        address: 'Rruga Liria, Podujevë',
        rating: 4.6,
        totalReviews: 63,
        priceRange: '€10-24',
        specialties: ['Fresh Styles', 'Clean Cuts', 'Youthful Energy'],
        coordinates: { lat: 42.9130, lng: 21.1950 }
      }
    ]
  },
  {
    id: 'rahovec',
    name: 'Rahovec',
    nameAlbanian: 'Rahovec',
    region: 'Western',
    coordinates: { lat: 42.3964, lng: 20.6536 },
    population: 22000,
    barberShops: [
      {
        id: 'city-style-rahovec',
        name: 'City Style',
        address: 'Rruga Liria, Rahovec',
        rating: 4.7,
        totalReviews: 54,
        priceRange: '€8-22',
        specialties: ['Urban Style', 'City Trends', 'Metropolitan Cuts'],
        coordinates: { lat: 42.3964, lng: 20.6536 }
      },
      {
        id: 'razor-edge-rahovec',
        name: 'Razor Edge',
        address: 'Rruga Dëshmorët, Rahovec',
        rating: 4.8,
        totalReviews: 67,
        priceRange: '€10-25',
        specialties: ['Sharp Edges', 'Precision Work', 'Clean Lines'],
        coordinates: { lat: 42.3980, lng: 20.6550 }
      },
      {
        id: 'studio-gent-rahovec',
        name: 'Studio Gent',
        address: 'Rruga Skënderbeu, Rahovec',
        rating: 4.6,
        totalReviews: 41,
        priceRange: '€12-28',
        specialties: ['Studio Quality', 'Gentleman Service', 'Artistic Approach'],
        coordinates: { lat: 42.3950, lng: 20.6520 }
      }
    ]
  },
  {
    id: 'decan',
    name: 'Deçan',
    nameAlbanian: 'Deçan',
    region: 'Western',
    coordinates: { lat: 42.5361, lng: 20.2931 },
    population: 18000,
    barberShops: [
      {
        id: 'decan-barbers',
        name: 'Deçan Barbers',
        address: 'Rruga Adem Jashari, Deçan',
        rating: 4.5,
        totalReviews: 39,
        priceRange: '€8-20',
        specialties: ['Local Tradition', 'Family Service', 'Heritage Cuts'],
        coordinates: { lat: 42.5361, lng: 20.2931 }
      },
      {
        id: 'fade-station-decan',
        name: 'Fade Station',
        address: 'Rruga Liria, Deçan',
        rating: 4.7,
        totalReviews: 52,
        priceRange: '€10-24',
        specialties: ['Fade Specialists', 'Station Quality', 'Quick Service'],
        coordinates: { lat: 42.5380, lng: 20.2950 }
      },
      {
        id: 'elite-look-decan',
        name: 'Elite Look',
        address: 'Rruga Skënderbeu, Deçan',
        rating: 4.6,
        totalReviews: 45,
        priceRange: '€12-26',
        specialties: ['Elite Appearance', 'Premium Look', 'Sophisticated Style'],
        coordinates: { lat: 42.5340, lng: 20.2910 }
      }
    ]
  }
];

// Helper functions for location-based features
export const getAllCities = (): KosovoCity[] => kosovoCities;

export const getCityById = (cityId: string): KosovoCity | undefined => {
  return kosovoCities.find(city => city.id === cityId);
};

export const getCityByName = (cityName: string): KosovoCity | undefined => {
  return kosovoCities.find(city => 
    city.name.toLowerCase() === cityName.toLowerCase() || 
    city.nameAlbanian.toLowerCase() === cityName.toLowerCase()
  );
};

export const getBarberShopsByCity = (cityId: string): BarberShop[] => {
  const city = getCityById(cityId);
  return city ? city.barberShops : [];
};

export const getAllBarberShops = (): BarberShop[] => {
  return kosovoCities.flatMap(city => city.barberShops);
};

export const searchBarberShops = (query: string): BarberShop[] => {
  const allShops = getAllBarberShops();
  return allShops.filter(shop => 
    shop.name.toLowerCase().includes(query.toLowerCase()) ||
    shop.address.toLowerCase().includes(query.toLowerCase()) ||
    shop.specialties.some(specialty => 
      specialty.toLowerCase().includes(query.toLowerCase())
    )
  );
};

export const getBarberShopsByLocation = (lat: number, lng: number, radiusKm: number = 10): BarberShop[] => {
  const allShops = getAllBarberShops();
  return allShops.filter(shop => {
    const distance = calculateDistance(lat, lng, shop.coordinates.lat, shop.coordinates.lng);
    return distance <= radiusKm;
  });
};

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}