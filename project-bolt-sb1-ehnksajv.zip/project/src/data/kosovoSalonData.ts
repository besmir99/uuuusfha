export interface KosovoSalon {
  id: string;
  name: string;
  city: string;
  address: string;
  coordinates: { lat: number; lng: number };
  rating: number;
  totalReviews: number;
  phone: string;
  description: string;
  amenities: string[];
  businessHours: {
    monday: { isOpen: boolean; openTime: string; closeTime: string };
    tuesday: { isOpen: boolean; openTime: string; closeTime: string };
    wednesday: { isOpen: boolean; openTime: string; closeTime: string };
    thursday: { isOpen: boolean; openTime: string; closeTime: string };
    friday: { isOpen: boolean; openTime: string; closeTime: string };
    saturday: { isOpen: boolean; openTime: string; closeTime: string };
    sunday: { isOpen: boolean; openTime: string; closeTime: string };
  };
  isActive: boolean;
  verified: boolean;
  createdAt: string;
}

export interface KosovoBarber {
  id: string;
  name: string;
  email: string;
  phone: string;
  salonId: string;
  bio: string;
  specialties: string[];
  experience: number;
  rating: number;
  totalReviews: number;
  gender: 'male' | 'female';
  isActive: boolean;
  availableServices: string[];
  workingHours: {
    monday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    tuesday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    wednesday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    thursday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    friday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    saturday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
    sunday: { isWorking: boolean; startTime: string; endTime: string; breaks: BreakPeriod[] };
  };
  vacationDays: string[]; // ['2025-07-04', '2025-07-05']
  createdAt: string;
}

export interface BreakPeriod {
  id: string;
  startTime: string;
  endTime: string;
  title: string;
  type: 'lunch' | 'coffee' | 'personal' | 'maintenance';
  isRecurring: boolean;
}

export interface KosovoService {
  id: string;
  salonId: string;
  name: string;
  description: string;
  price: number;
  duration: number; // minutes
  category: string;
  targetGender: 'male' | 'female' | 'unisex';
  requiredExperience?: number;
  isActive: boolean;
  createdAt: string;
}

// Kosovo Salon Data with authentic names and locations
export const kosovoSalons: KosovoSalon[] = [
  {
    id: 'salon-prishtina-1',
    name: 'Elite Cuts Prishtina',
    city: 'Prishtina',
    address: 'Rruga Bill Klinton 15, Prishtinë 10000',
    coordinates: { lat: 42.6629, lng: 21.1655 },
    rating: 4.8,
    totalReviews: 245,
    phone: '+383 44 123 456',
    description: 'Premier barbering salon in the heart of Prishtina, offering modern cuts and traditional grooming services with a team of expert stylists.',
    amenities: ['WiFi', 'Air Conditioning', 'Coffee', 'Parking', 'Card Payment', 'Music System'],
    businessHours: {
      monday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      tuesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      wednesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      thursday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      friday: { isOpen: true, openTime: '09:00', closeTime: '20:00' },
      saturday: { isOpen: true, openTime: '08:00', closeTime: '19:00' },
      sunday: { isOpen: false, openTime: '10:00', closeTime: '16:00' }
    },
    isActive: true,
    verified: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'salon-prizren-1',
    name: 'Royal Trim Prizren',
    city: 'Prizren',
    address: 'Rruga Shadervan 8, Prizren 20000',
    coordinates: { lat: 42.2139, lng: 20.7397 },
    rating: 4.9,
    totalReviews: 189,
    phone: '+383 44 234 567',
    description: 'Historic city\'s finest salon combining traditional Albanian barbering techniques with modern European styling.',
    amenities: ['WiFi', 'Air Conditioning', 'Traditional Tea', 'Historic Ambiance', 'Card Payment'],
    businessHours: {
      monday: { isOpen: true, openTime: '08:30', closeTime: '17:30' },
      tuesday: { isOpen: true, openTime: '08:30', closeTime: '17:30' },
      wednesday: { isOpen: true, openTime: '08:30', closeTime: '17:30' },
      thursday: { isOpen: true, openTime: '08:30', closeTime: '17:30' },
      friday: { isOpen: true, openTime: '08:30', closeTime: '19:00' },
      saturday: { isOpen: true, openTime: '08:00', closeTime: '18:00' },
      sunday: { isOpen: true, openTime: '10:00', closeTime: '15:00' }
    },
    isActive: true,
    verified: true,
    createdAt: '2024-01-02T10:00:00Z'
  },
  {
    id: 'salon-gjakova-1',
    name: 'Sharp Line Gjakova',
    city: 'Gjakova',
    address: 'Rruga Çarshia e Madhe 12, Gjakovë 50000',
    coordinates: { lat: 42.3803, lng: 20.4314 },
    rating: 4.7,
    totalReviews: 156,
    phone: '+383 44 345 678',
    description: 'Professional grooming services in Gjakova\'s cultural center, specializing in precision cuts and traditional shaving.',
    amenities: ['WiFi', 'Coffee', 'Traditional Shaving', 'Magazines', 'Card Payment'],
    businessHours: {
      monday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      tuesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      wednesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      thursday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      friday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      saturday: { isOpen: true, openTime: '08:30', closeTime: '17:30' },
      sunday: { isOpen: false, openTime: '10:00', closeTime: '14:00' }
    },
    isActive: true,
    verified: true,
    createdAt: '2024-01-03T10:00:00Z'
  },
  {
    id: 'salon-peja-1',
    name: 'Style Studio Peja',
    city: 'Peja',
    address: 'Rruga Mbretëresha Teuta 20, Pejë 30000',
    coordinates: { lat: 42.6589, lng: 20.2889 },
    rating: 4.8,
    totalReviews: 203,
    phone: '+383 44 456 789',
    description: 'Mountain city\'s premier styling destination with expert barbers and stylists, offering both traditional and modern services.',
    amenities: ['WiFi', 'Air Conditioning', 'Mountain View', 'Coffee', 'Parking', 'Music System'],
    businessHours: {
      monday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      tuesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      wednesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      thursday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      friday: { isOpen: true, openTime: '09:00', closeTime: '19:00' },
      saturday: { isOpen: true, openTime: '08:00', closeTime: '18:00' },
      sunday: { isOpen: true, openTime: '10:00', closeTime: '16:00' }
    },
    isActive: true,
    verified: true,
    createdAt: '2024-01-04T10:00:00Z'
  },
  {
    id: 'salon-mitrovica-1',
    name: 'Beauty & Barber Mitrovica',
    city: 'Mitrovica',
    address: 'Rruga Mbretër Nikolla 5, Mitrovicë 40000',
    coordinates: { lat: 42.8914, lng: 20.8664 },
    rating: 4.6,
    totalReviews: 134,
    phone: '+383 44 567 890',
    description: 'Full-service salon offering both men\'s and women\'s grooming services in the heart of Mitrovica.',
    amenities: ['WiFi', 'Unisex Services', 'Refreshments', 'Card Payment', 'Parking'],
    businessHours: {
      monday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      tuesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      wednesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      thursday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      friday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
      saturday: { isOpen: true, openTime: '08:30', closeTime: '17:00' },
      sunday: { isOpen: false, openTime: '10:00', closeTime: '15:00' }
    },
    isActive: true,
    verified: true,
    createdAt: '2024-01-05T10:00:00Z'
  }
];

// Kosovo Barbers with authentic Albanian names
export const kosovoBarbers: KosovoBarber[] = [
  // Elite Cuts Prishtina Staff
  {
    id: 'barber-arben-krasniqi',
    name: 'Arben Krasniqi',
    email: 'arben@elitecuts.com',
    phone: '+383 44 111 222',
    salonId: 'salon-prishtina-1',
    bio: 'Master barber with 12 years of experience specializing in modern cuts and classic Albanian styling traditions.',
    specialties: ['Modern Cuts', 'Traditional Albanian Styles', 'Beard Styling', 'Fade Techniques'],
    experience: 12,
    rating: 4.9,
    totalReviews: 89,
    gender: 'male',
    isActive: true,
    availableServices: ['service-mens-haircut', 'service-beard-trim', 'service-fade-cut', 'service-wet-shave'],
    workingHours: {
      monday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-1', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      tuesday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-1', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      wednesday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-1', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      thursday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-1', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      friday: { isWorking: true, startTime: '09:00', endTime: '20:00', breaks: [{ id: 'lunch-1', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      saturday: { isWorking: true, startTime: '08:00', endTime: '19:00', breaks: [{ id: 'lunch-1', startTime: '13:00', endTime: '14:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      sunday: { isWorking: false, startTime: '10:00', endTime: '16:00', breaks: [] }
    },
    vacationDays: ['2025-07-04', '2025-07-05', '2025-12-25'],
    createdAt: '2024-01-10T10:00:00Z'
  },
  {
    id: 'barber-adelina-krasniqi',
    name: 'Adelina Krasniqi',
    email: 'adelina@elitecuts.com',
    phone: '+383 44 333 444',
    salonId: 'salon-prishtina-1',
    bio: 'Professional hairstylist specializing in women\'s cuts, coloring, and styling with European training and local expertise.',
    specialties: ['Women\'s Cuts', 'Hair Coloring', 'Balayage', 'Wedding Styles', 'Keratin Treatments'],
    experience: 10,
    rating: 4.9,
    totalReviews: 145,
    gender: 'female',
    isActive: true,
    availableServices: ['service-womens-cut', 'service-hair-coloring', 'service-hair-treatment', 'service-styling', 'service-wedding-hair'],
    workingHours: {
      monday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-2', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      tuesday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-2', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      wednesday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-2', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      thursday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-2', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      friday: { isWorking: true, startTime: '09:00', endTime: '20:00', breaks: [{ id: 'lunch-2', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      saturday: { isWorking: true, startTime: '08:00', endTime: '19:00', breaks: [{ id: 'lunch-2', startTime: '13:30', endTime: '14:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      sunday: { isWorking: false, startTime: '10:00', endTime: '16:00', breaks: [] }
    },
    vacationDays: ['2025-08-15', '2025-08-16'],
    createdAt: '2024-01-12T10:00:00Z'
  },
  // Royal Trim Prizren Staff
  {
    id: 'barber-flamur-gashi',
    name: 'Flamur Gashi',
    email: 'flamur@royaltrim.com',
    phone: '+383 44 444 555',
    salonId: 'salon-prizren-1',
    bio: 'Traditional barbering expert with modern techniques, preserving Prizren\'s rich grooming heritage.',
    specialties: ['Traditional Cuts', 'Ottoman-style Shaving', 'Beard Care', 'Mustache Styling'],
    experience: 15,
    rating: 4.8,
    totalReviews: 98,
    gender: 'male',
    isActive: true,
    availableServices: ['service-traditional-cut', 'service-ottoman-shave', 'service-beard-care', 'service-mustache-trim'],
    workingHours: {
      monday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-3', startTime: '12:00', endTime: '13:00', title: 'Lunch & Prayer', type: 'lunch', isRecurring: true }] },
      tuesday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-3', startTime: '12:00', endTime: '13:00', title: 'Lunch & Prayer', type: 'lunch', isRecurring: true }] },
      wednesday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-3', startTime: '12:00', endTime: '13:00', title: 'Lunch & Prayer', type: 'lunch', isRecurring: true }] },
      thursday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-3', startTime: '12:00', endTime: '13:00', title: 'Lunch & Prayer', type: 'lunch', isRecurring: true }] },
      friday: { isWorking: true, startTime: '08:30', endTime: '19:00', breaks: [{ id: 'friday-prayer', startTime: '12:30', endTime: '14:00', title: 'Friday Prayer & Lunch', type: 'personal', isRecurring: true }] },
      saturday: { isWorking: true, startTime: '08:00', endTime: '18:00', breaks: [{ id: 'lunch-3', startTime: '13:00', endTime: '14:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      sunday: { isWorking: true, startTime: '10:00', endTime: '15:00', breaks: [] }
    },
    vacationDays: ['2025-06-15', '2025-06-16', '2025-06-17'], // Eid holidays
    createdAt: '2024-01-13T10:00:00Z'
  },
  {
    id: 'barber-blerta-gashi',
    name: 'Blerta Gashi',
    email: 'blerta@royaltrim.com',
    phone: '+383 44 555 666',
    salonId: 'salon-prizren-1',
    bio: 'Creative hair artist with expertise in color transformations and special occasion styling, trained in Istanbul and Tirana.',
    specialties: ['Hair Coloring', 'Ombre & Balayage', 'Braiding', 'Wedding Styles', 'Hair Extensions'],
    experience: 9,
    rating: 4.8,
    totalReviews: 76,
    gender: 'female',
    isActive: true,
    availableServices: ['service-color-transformation', 'service-braiding', 'service-wedding-styling', 'service-extensions'],
    workingHours: {
      monday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-4', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      tuesday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-4', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      wednesday: { isWorking: false, startTime: '08:30', endTime: '17:30', breaks: [] }, // Day off
      thursday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-4', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      friday: { isWorking: true, startTime: '08:30', endTime: '19:00', breaks: [{ id: 'lunch-4', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      saturday: { isWorking: true, startTime: '08:00', endTime: '18:00', breaks: [{ id: 'lunch-4', startTime: '13:30', endTime: '14:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      sunday: { isWorking: true, startTime: '10:00', endTime: '15:00', breaks: [] }
    },
    vacationDays: ['2025-09-10', '2025-09-11'],
    createdAt: '2024-01-14T10:00:00Z'
  },
  // Sharp Line Gjakova Staff
  {
    id: 'barber-besnik-hoxha',
    name: 'Besnik Hoxha',
    email: 'besnik@sharpline.com',
    phone: '+383 44 666 777',
    salonId: 'salon-gjakova-1',
    bio: 'Precision line specialist with attention to detail, known for the sharpest fades and line-ups in Gjakova.',
    specialties: ['Line-ups', 'Precision Fades', 'Beard Trimming', 'Hair Designs'],
    experience: 7,
    rating: 4.7,
    totalReviews: 54,
    gender: 'male',
    isActive: true,
    availableServices: ['service-precision-lineup', 'service-fade-specialist', 'service-beard-design'],
    workingHours: {
      monday: { isWorking: true, startTime: '09:00', endTime: '17:00', breaks: [{ id: 'lunch-5', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      tuesday: { isWorking: true, startTime: '09:00', endTime: '17:00', breaks: [{ id: 'lunch-5', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      wednesday: { isWorking: true, startTime: '09:00', endTime: '17:00', breaks: [{ id: 'lunch-5', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      thursday: { isWorking: true, startTime: '09:00', endTime: '17:00', breaks: [{ id: 'lunch-5', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      friday: { isWorking: true, startTime: '09:00', endTime: '18:00', breaks: [{ id: 'lunch-5', startTime: '12:00', endTime: '13:00', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      saturday: { isWorking: true, startTime: '08:30', endTime: '17:30', breaks: [{ id: 'lunch-5', startTime: '12:30', endTime: '13:30', title: 'Lunch Break', type: 'lunch', isRecurring: true }] },
      sunday: { isWorking: false, startTime: '10:00', endTime: '14:00', breaks: [] }
    },
    vacationDays: [],
    createdAt: '2024-01-15T10:00:00Z'
  }
];

// Kosovo Services with authentic pricing and descriptions
export const kosovoServices: KosovoService[] = [
  // Men's Services
  {
    id: 'service-mens-haircut',
    salonId: 'salon-prishtina-1',
    name: 'Classic Men\'s Haircut',
    description: 'Traditional men\'s haircut with precision cutting, styling, and finishing touches',
    price: 12,
    duration: 45,
    category: 'Haircut',
    targetGender: 'male',
    requiredExperience: 3,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-beard-trim',
    salonId: 'salon-prishtina-1',
    name: 'Premium Beard Trim',
    description: 'Professional beard shaping and trimming with hot towel treatment',
    price: 8,
    duration: 30,
    category: 'Grooming',
    targetGender: 'male',
    requiredExperience: 2,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-fade-cut',
    salonId: 'salon-prishtina-1',
    name: 'Modern Fade Cut',
    description: 'Contemporary fade cuts with sharp lines and modern styling',
    price: 15,
    duration: 50,
    category: 'Haircut',
    targetGender: 'male',
    requiredExperience: 5,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-wet-shave',
    salonId: 'salon-prishtina-1',
    name: 'Traditional Wet Shave',
    description: 'Classic straight razor shave with hot towel and premium aftercare',
    price: 10,
    duration: 40,
    category: 'Shaving',
    targetGender: 'male',
    requiredExperience: 8,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  // Women's Services
  {
    id: 'service-womens-cut',
    salonId: 'salon-prishtina-1',
    name: 'Women\'s Hair Cut & Style',
    description: 'Professional women\'s haircut with modern styling and finishing',
    price: 20,
    duration: 60,
    category: 'Haircut',
    targetGender: 'female',
    requiredExperience: 4,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-hair-coloring',
    salonId: 'salon-prishtina-1',
    name: 'Hair Coloring & Highlights',
    description: 'Complete hair coloring service with highlights and color correction',
    price: 35,
    duration: 120,
    category: 'Coloring',
    targetGender: 'female',
    requiredExperience: 6,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-hair-treatment',
    salonId: 'salon-prishtina-1',
    name: 'Hair Straightening Treatment',
    description: 'Professional keratin treatment for smooth, straight hair',
    price: 45,
    duration: 150,
    category: 'Treatment',
    targetGender: 'female',
    requiredExperience: 7,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-styling',
    salonId: 'salon-prishtina-1',
    name: 'Blow Dry & Styling',
    description: 'Professional blow dry with styling for special occasions',
    price: 15,
    duration: 45,
    category: 'Styling',
    targetGender: 'female',
    requiredExperience: 2,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  {
    id: 'service-wedding-hair',
    salonId: 'salon-prishtina-1',
    name: 'Wedding Hair Styling',
    description: 'Special occasion styling for weddings and formal events',
    price: 40,
    duration: 120,
    category: 'Styling',
    targetGender: 'female',
    requiredExperience: 7,
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z'
  },
  // Traditional Prizren Services
  {
    id: 'service-traditional-cut',
    salonId: 'salon-prizren-1',
    name: 'Traditional Albanian Cut',
    description: 'Classic Albanian men\'s haircut with traditional techniques',
    price: 10,
    duration: 40,
    category: 'Haircut',
    targetGender: 'male',
    requiredExperience: 5,
    isActive: true,
    createdAt: '2024-01-02T10:00:00Z'
  },
  {
    id: 'service-ottoman-shave',
    salonId: 'salon-prizren-1',
    name: 'Ottoman-Style Shave',
    description: 'Traditional Ottoman shaving technique with authentic tools and methods',
    price: 12,
    duration: 50,
    category: 'Shaving',
    targetGender: 'male',
    requiredExperience: 10,
    isActive: true,
    createdAt: '2024-01-02T10:00:00Z'
  },
  {
    id: 'service-color-transformation',
    salonId: 'salon-prizren-1',
    name: 'Color Transformation',
    description: 'Complete hair color makeover with consultation and aftercare',
    price: 40,
    duration: 180,
    category: 'Coloring',
    targetGender: 'female',
    requiredExperience: 8,
    isActive: true,
    createdAt: '2024-01-02T10:00:00Z'
  },
  {
    id: 'service-braiding',
    salonId: 'salon-prizren-1',
    name: 'Traditional Braiding',
    description: 'Artistic braiding styles from simple to complex traditional designs',
    price: 25,
    duration: 90,
    category: 'Styling',
    targetGender: 'female',
    requiredExperience: 5,
    isActive: true,
    createdAt: '2024-01-02T10:00:00Z'
  },
  // Gjakova Precision Services
  {
    id: 'service-precision-lineup',
    salonId: 'salon-gjakova-1',
    name: 'Precision Line-up',
    description: 'Sharp hairline and beard line precision cutting',
    price: 8,
    duration: 35,
    category: 'Grooming',
    targetGender: 'male',
    requiredExperience: 4,
    isActive: true,
    createdAt: '2024-01-03T10:00:00Z'
  },
  {
    id: 'service-fade-specialist',
    salonId: 'salon-gjakova-1',
    name: 'Fade Specialist',
    description: 'Expert fade cutting with multiple fade styles and techniques',
    price: 12,
    duration: 45,
    category: 'Haircut',
    targetGender: 'male',
    requiredExperience: 5,
    isActive: true,
    createdAt: '2024-01-03T10:00:00Z'
  },
  // Unisex Services
  {
    id: 'service-hair-wash',
    salonId: 'salon-mitrovica-1',
    name: 'Hair Wash & Conditioning',
    description: 'Deep cleansing hair wash with premium conditioning treatment',
    price: 6,
    duration: 30,
    category: 'Treatment',
    targetGender: 'unisex',
    requiredExperience: 1,
    isActive: true,
    createdAt: '2024-01-05T10:00:00Z'
  },
  {
    id: 'service-scalp-massage',
    salonId: 'salon-mitrovica-1',
    name: 'Scalp Massage Treatment',
    description: 'Relaxing scalp massage with essential oils for stress relief',
    price: 8,
    duration: 30,
    category: 'Treatment',
    targetGender: 'unisex',
    requiredExperience: 2,
    isActive: true,
    createdAt: '2024-01-05T10:00:00Z'
  }
];

// Helper functions for Kosovo salon data
export const getKosovoSalonsByCity = (city: string): KosovoSalon[] => {
  return kosovoSalons.filter(salon => 
    salon.city.toLowerCase() === city.toLowerCase() && salon.isActive
  );
};

export const getKosovoBarbersBySalon = (salonId: string): KosovoBarber[] => {
  return kosovoBarbers.filter(barber => 
    barber.salonId === salonId && barber.isActive
  );
};

export const getKosovoServicesBySalon = (salonId: string): KosovoService[] => {
  return kosovoServices.filter(service => 
    service.salonId === salonId && service.isActive
  );
};

export const getKosovoServicesByGenderAndSalon = (salonId: string, clientGender: 'male' | 'female' | 'other'): KosovoService[] => {
  const salonServices = getKosovoServicesBySalon(salonId);
  return salonServices.filter(service => {
    if (service.targetGender === 'unisex') return true;
    if (clientGender === 'other') return true; // Show all services for 'other' gender
    return service.targetGender === clientGender;
  });
};

export const getAvailableKosovoBarbers = (salonId: string, serviceId: string): KosovoBarber[] => {
  const salonBarbers = getKosovoBarbersBySalon(salonId);
  const service = kosovoServices.find(s => s.id === serviceId);
  
  if (!service) return [];
  
  return salonBarbers.filter(barber => 
    barber.availableServices.includes(serviceId) &&
    barber.experience >= (service.requiredExperience || 0)
  );
};

export const getKosovoSalonById = (salonId: string): KosovoSalon | undefined => {
  return kosovoSalons.find(salon => salon.id === salonId);
};

export const getKosovoBarberById = (barberId: string): KosovoBarber | undefined => {
  return kosovoBarbers.find(barber => barber.id === barberId);
};

export const getKosovoServiceById = (serviceId: string): KosovoService | undefined => {
  return kosovoServices.find(service => service.id === serviceId);
};