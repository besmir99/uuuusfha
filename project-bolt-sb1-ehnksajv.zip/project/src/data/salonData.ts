import { Salon, Barber, Service, BusinessHours } from '../types';

export const mockBusinessHours: BusinessHours = {
  monday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
  tuesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
  wednesday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
  thursday: { isOpen: true, openTime: '09:00', closeTime: '18:00' },
  friday: { isOpen: true, openTime: '09:00', closeTime: '20:00' },
  saturday: { isOpen: true, openTime: '08:00', closeTime: '19:00' },
  sunday: { isOpen: false, openTime: '10:00', closeTime: '16:00' },
};

export const mockSalons: Salon[] = [
  {
    id: 'salon-1',
    name: 'Elite Cuts Prishtina',
    address: 'Rruga Bill Klinton 15, Prishtinë',
    city: 'Prishtina',
    coordinates: { lat: 42.6629, lng: 21.1655 },
    rating: 4.8,
    totalReviews: 245,
    businessHours: mockBusinessHours,
    amenities: ['WiFi', 'Air Conditioning', 'Coffee', 'Parking', 'Card Payment'],
    images: ['https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg'],
    description: 'Premier barbering salon in the heart of Prishtina, offering modern cuts and traditional grooming services.',
    phone: '+383 44 123 456',
    isActive: true,
    createdAt: '2024-01-01T10:00:00Z',
  },
  {
    id: 'salon-2',
    name: 'Royal Trim Prizren',
    address: 'Rruga Shadervan 8, Prizren',
    city: 'Prizren',
    coordinates: { lat: 42.2139, lng: 20.7397 },
    rating: 4.9,
    totalReviews: 189,
    businessHours: mockBusinessHours,
    amenities: ['WiFi', 'Air Conditioning', 'Refreshments', 'Music System'],
    images: ['https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg'],
    description: 'Historic city\'s finest salon combining traditional techniques with modern styling.',
    phone: '+383 44 234 567',
    isActive: true,
    createdAt: '2024-01-02T10:00:00Z',
  },
  {
    id: 'salon-3',
    name: 'Sharp Line Gjakova',
    address: 'Rruga Çarshia e Madhe 12, Gjakovë',
    city: 'Gjakova',
    coordinates: { lat: 42.3803, lng: 20.4314 },
    rating: 4.7,
    totalReviews: 156,
    businessHours: mockBusinessHours,
    amenities: ['WiFi', 'Coffee', 'Magazines', 'Card Payment'],
    images: ['https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg'],
    description: 'Professional grooming services in Gjakova\'s cultural center.',
    phone: '+383 44 345 678',
    isActive: true,
    createdAt: '2024-01-03T10:00:00Z',
  },
  {
    id: 'salon-4',
    name: 'Style Studio Peja',
    address: 'Rruga Mbretëresha Teuta 20, Pejë',
    city: 'Peja',
    coordinates: { lat: 42.6589, lng: 20.2889 },
    rating: 4.8,
    totalReviews: 203,
    businessHours: mockBusinessHours,
    amenities: ['WiFi', 'Air Conditioning', 'Coffee', 'Parking', 'Music System'],
    images: ['https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg'],
    description: 'Mountain city\'s premier styling destination with expert barbers and stylists.',
    phone: '+383 44 456 789',
    isActive: true,
    createdAt: '2024-01-04T10:00:00Z',
  },
  {
    id: 'salon-5',
    name: 'Beauty & Barber Mitrovica',
    address: 'Rruga Mbretër Nikolla 5, Mitrovicë',
    city: 'Mitrovica',
    coordinates: { lat: 42.8914, lng: 20.8664 },
    rating: 4.6,
    totalReviews: 134,
    businessHours: mockBusinessHours,
    amenities: ['WiFi', 'Refreshments', 'Card Payment', 'Parking'],
    images: ['https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg'],
    description: 'Full-service salon offering both men\'s and women\'s grooming services.',
    phone: '+383 44 567 890',
    isActive: true,
    createdAt: '2024-01-05T10:00:00Z',
  }
];

export const mockBarbers: Barber[] = [
  // Elite Cuts Prishtina Staff
  {
    id: 'barber-1',
    name: 'Arben Krasniqi',
    email: 'arben@elitecuts.com',
    phone: '+383 44 111 222',
    role: 'barber',
    gender: 'male',
    salonId: 'salon-1',
    bio: 'Master barber with 12 years of experience specializing in modern cuts and classic styles.',
    specialties: ['Modern Cuts', 'Beard Styling', 'Fade Techniques'],
    rating: 4.9,
    totalReviews: 89,
    experience: 12,
    isActive: true,
    availableServices: ['service-1', 'service-2', 'service-3', 'service-4'],
    createdAt: '2024-01-10T10:00:00Z',
  },
  {
    id: 'barber-2',
    name: 'Driton Berisha',
    email: 'driton@elitecuts.com',
    phone: '+383 44 222 333',
    role: 'barber',
    gender: 'male',
    salonId: 'salon-1',
    bio: 'Precision cutting specialist with expertise in contemporary styling.',
    specialties: ['Precision Cuts', 'Hair Washing', 'Styling'],
    rating: 4.7,
    totalReviews: 67,
    experience: 8,
    isActive: true,
    availableServices: ['service-1', 'service-3', 'service-21'],
    createdAt: '2024-01-11T10:00:00Z',
  },
  {
    id: 'barber-3',
    name: 'Adelina Krasniqi',
    email: 'adelina@elitecuts.com',
    phone: '+383 44 333 444',
    role: 'barber',
    gender: 'female',
    salonId: 'salon-1',
    bio: 'Professional hairstylist specializing in women\'s cuts, coloring, and styling.',
    specialties: ['Women\'s Cuts', 'Hair Coloring', 'Styling', 'Treatments'],
    rating: 4.9,
    totalReviews: 145,
    experience: 10,
    isActive: true,
    availableServices: ['service-12', 'service-13', 'service-14', 'service-15', 'service-22'],
    createdAt: '2024-01-12T10:00:00Z',
  },

  // Royal Trim Prizren Staff
  {
    id: 'barber-4',
    name: 'Flamur Gashi',
    email: 'flamur@royaltrim.com',
    phone: '+383 44 444 555',
    role: 'barber',
    gender: 'male',
    salonId: 'salon-2',
    bio: 'Traditional barbering expert with modern techniques.',
    specialties: ['Traditional Cuts', 'Wet Shaving', 'Beard Care'],
    rating: 4.8,
    totalReviews: 98,
    experience: 15,
    isActive: true,
    availableServices: ['service-5', 'service-6', 'service-7', 'service-23'],
    createdAt: '2024-01-13T10:00:00Z',
  },
  {
    id: 'barber-5',
    name: 'Blerta Gashi',
    email: 'blerta@royaltrim.com',
    phone: '+383 44 555 666',
    role: 'barber',
    gender: 'female',
    salonId: 'salon-2',
    bio: 'Creative hair artist with expertise in color transformations and special occasion styling.',
    specialties: ['Hair Coloring', 'Braiding', 'Wedding Styles', 'Extensions'],
    rating: 4.8,
    totalReviews: 76,
    experience: 9,
    isActive: true,
    availableServices: ['service-17', 'service-18', 'service-19', 'service-20'],
    createdAt: '2024-01-14T10:00:00Z',
  },

  // Sharp Line Gjakova Staff
  {
    id: 'barber-6',
    name: 'Besnik Hoxha',
    email: 'besnik@sharpline.com',
    phone: '+383 44 666 777',
    role: 'barber',
    gender: 'male',
    salonId: 'salon-3',
    bio: 'Precision line specialist with attention to detail.',
    specialties: ['Line-ups', 'Precision Cuts', 'Beard Trimming'],
    rating: 4.7,
    totalReviews: 54,
    experience: 7,
    isActive: true,
    availableServices: ['service-8', 'service-9'],
    createdAt: '2024-01-15T10:00:00Z',
  },

  // Style Studio Peja Staff
  {
    id: 'barber-7',
    name: 'Valdrin Kelmendi',
    email: 'valdrin@stylestudio.com',
    phone: '+383 44 777 888',
    role: 'barber',
    gender: 'male',
    salonId: 'salon-4',
    bio: 'Mountain-inspired styling with natural techniques.',
    specialties: ['Natural Cuts', 'Beard Styling', 'Hair Care'],
    rating: 4.8,
    totalReviews: 87,
    experience: 11,
    isActive: true,
    availableServices: ['service-10', 'service-11'],
    createdAt: '2024-01-16T10:00:00Z',
  },

  // Beauty & Barber Mitrovica Staff
  {
    id: 'barber-8',
    name: 'Arta Berisha',
    email: 'arta@beautybarber.com',
    phone: '+383 44 888 999',
    role: 'barber',
    gender: 'female',
    salonId: 'salon-5',
    bio: 'Versatile stylist serving both men and women with equal expertise.',
    specialties: ['Unisex Cuts', 'Treatments', 'Consultations'],
    rating: 4.6,
    totalReviews: 92,
    experience: 6,
    isActive: true,
    availableServices: ['service-21', 'service-22', 'service-23'],
    createdAt: '2024-01-17T10:00:00Z',
  }
];

export const mockServices: Service[] = [
  // Elite Cuts Prishtina Services
  {
    id: 'service-1',
    salonId: 'salon-1',
    title: 'Classic Men\'s Haircut',
    description: 'Traditional men\'s haircut with precision cutting and styling',
    price: 25,
    duration: 45,
    category: 'Haircut',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 3,
  },
  {
    id: 'service-2',
    salonId: 'salon-1',
    title: 'Premium Beard Trim',
    description: 'Professional beard shaping and trimming with hot towel treatment',
    price: 15,
    duration: 30,
    category: 'Grooming',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 2,
  },
  {
    id: 'service-3',
    salonId: 'salon-1',
    title: 'Modern Fade Cut',
    description: 'Contemporary fade cuts with sharp lines and modern styling',
    price: 30,
    duration: 50,
    category: 'Haircut',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 5,
  },
  {
    id: 'service-4',
    salonId: 'salon-1',
    title: 'Traditional Wet Shave',
    description: 'Classic straight razor shave with hot towel and premium aftercare',
    price: 20,
    duration: 40,
    category: 'Shaving',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 8,
  },
  {
    id: 'service-12',
    salonId: 'salon-1',
    title: 'Women\'s Hair Cut & Style',
    description: 'Professional women\'s haircut with modern styling and finishing',
    price: 35,
    duration: 60,
    category: 'Haircut',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 4,
  },
  {
    id: 'service-13',
    salonId: 'salon-1',
    title: 'Hair Coloring & Highlights',
    description: 'Complete hair coloring service with highlights and color correction',
    price: 65,
    duration: 120,
    category: 'Coloring',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 6,
  },
  {
    id: 'service-14',
    salonId: 'salon-1',
    title: 'Hair Straightening Treatment',
    description: 'Professional keratin treatment for smooth, straight hair',
    price: 80,
    duration: 150,
    category: 'Treatment',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 7,
  },
  {
    id: 'service-15',
    salonId: 'salon-1',
    title: 'Blow Dry & Styling',
    description: 'Professional blow dry with styling for special occasions',
    price: 25,
    duration: 45,
    category: 'Styling',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 2,
  },

  // Royal Trim Prizren Services
  {
    id: 'service-5',
    salonId: 'salon-2',
    title: 'Royal Men\'s Treatment',
    description: 'Complete men\'s grooming service with wash, cut, and royal styling treatment',
    price: 35,
    duration: 60,
    category: 'Haircut',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 5,
  },
  {
    id: 'service-6',
    salonId: 'salon-2',
    title: 'Men\'s Hair Coloring',
    description: 'Professional men\'s hair coloring service with premium products',
    price: 40,
    duration: 90,
    category: 'Coloring',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 6,
  },
  {
    id: 'service-7',
    salonId: 'salon-2',
    title: 'Gentleman\'s Facial',
    description: 'Relaxing facial treatment designed specifically for men\'s skin',
    price: 25,
    duration: 45,
    category: 'Facial',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 3,
  },
  {
    id: 'service-17',
    salonId: 'salon-2',
    title: 'Creative Hair Braiding',
    description: 'Artistic braiding styles from simple to complex designs',
    price: 40,
    duration: 90,
    category: 'Styling',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 5,
  },
  {
    id: 'service-18',
    salonId: 'salon-2',
    title: 'Color Transformation',
    description: 'Complete hair color makeover with consultation and aftercare',
    price: 75,
    duration: 180,
    category: 'Coloring',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 8,
  },
  {
    id: 'service-19',
    salonId: 'salon-2',
    title: 'Wedding Hair Styling',
    description: 'Special occasion styling for weddings and formal events',
    price: 60,
    duration: 120,
    category: 'Styling',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 7,
  },
  {
    id: 'service-20',
    salonId: 'salon-2',
    title: 'Hair Extensions Application',
    description: 'Professional hair extensions for length and volume',
    price: 90,
    duration: 150,
    category: 'Extensions',
    targetGender: 'female',
    isActive: true,
    requiredExperience: 6,
  },

  // Sharp Line Gjakova Services
  {
    id: 'service-8',
    salonId: 'salon-3',
    title: 'Precision Line-up',
    description: 'Sharp hairline and beard line precision cutting',
    price: 18,
    duration: 35,
    category: 'Grooming',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 4,
  },
  {
    id: 'service-9',
    salonId: 'salon-3',
    title: 'Gjakova Special Cut',
    description: 'Signature haircut style popular in Gjakova region',
    price: 22,
    duration: 45,
    category: 'Haircut',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 5,
  },

  // Style Studio Peja Services
  {
    id: 'service-10',
    salonId: 'salon-4',
    title: 'Mountain Fresh Cut',
    description: 'Natural, fresh haircut style inspired by Peja\'s mountain heritage',
    price: 20,
    duration: 40,
    category: 'Haircut',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 3,
  },
  {
    id: 'service-11',
    salonId: 'salon-4',
    title: 'Alpine Beard Styling',
    description: 'Rugged yet refined beard styling for the modern mountain man',
    price: 16,
    duration: 35,
    category: 'Grooming',
    targetGender: 'male',
    isActive: true,
    requiredExperience: 4,
  },

  // Unisex Services (available at multiple salons)
  {
    id: 'service-21',
    salonId: 'salon-1',
    title: 'Hair Wash & Conditioning',
    description: 'Deep cleansing hair wash with premium conditioning treatment',
    price: 15,
    duration: 30,
    category: 'Treatment',
    targetGender: 'unisex',
    isActive: true,
    requiredExperience: 1,
  },
  {
    id: 'service-22',
    salonId: 'salon-1',
    title: 'Scalp Massage Treatment',
    description: 'Relaxing scalp massage with essential oils for stress relief',
    price: 20,
    duration: 30,
    category: 'Treatment',
    targetGender: 'unisex',
    isActive: true,
    requiredExperience: 2,
  },
  {
    id: 'service-23',
    salonId: 'salon-2',
    title: 'Hair Consultation',
    description: 'Professional consultation for hair care and styling advice',
    price: 10,
    duration: 20,
    category: 'Consultation',
    targetGender: 'unisex',
    isActive: true,
    requiredExperience: 3,
  }
];

// Helper functions
export const getSalonsByCity = (city: string): Salon[] => {
  return mockSalons.filter(salon => salon.city.toLowerCase() === city.toLowerCase());
};

export const getBarbersBySalon = (salonId: string): Barber[] => {
  return mockBarbers.filter(barber => barber.salonId === salonId && barber.isActive);
};

export const getServicesBySalon = (salonId: string): Service[] => {
  return mockServices.filter(service => service.salonId === salonId && service.isActive);
};

export const getServicesByGenderAndSalon = (salonId: string, clientGender: 'male' | 'female' | 'other'): Service[] => {
  const salonServices = getServicesBySalon(salonId);
  return salonServices.filter(service => {
    if (service.targetGender === 'unisex') return true;
    if (clientGender === 'other') return true;
    return service.targetGender === clientGender;
  });
};

export const getAvailableBarbers = (salonId: string, serviceId: string): Barber[] => {
  const salonBarbers = getBarbersBySalon(salonId);
  const service = mockServices.find(s => s.id === serviceId);
  
  if (!service) return [];
  
  return salonBarbers.filter(barber => 
    barber.availableServices.includes(serviceId) &&
    barber.experience >= (service.requiredExperience || 0)
  );
};

export const getSalonById = (salonId: string): Salon | undefined => {
  return mockSalons.find(salon => salon.id === salonId);
};

export const getBarberById = (barberId: string): Barber | undefined => {
  return mockBarbers.find(barber => barber.id === barberId);
};

export const getServiceById = (serviceId: string): Service | undefined => {
  return mockServices.find(service => service.id === serviceId);
};